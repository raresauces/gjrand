/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#ifndef _GJRAND_PSCALE_H
#define _GJRAND_PSCALE_H 1

#include <stdio.h>
#include <math.h>

/* Probability that the smallest of n numbers in [ 0 .. 1 ) is <= x . */
static double
pco_scale(double x, double n)
{
	if (x>=1.0 || x<=0.0) return x;

	/* This is the result we want: */
	/* return 1.0-pow(1.0-x, n); */
	/* except the important cases are with x very small */
	/* so this method gives better accuracy: */

	return -expm1(log1p(-x)*n);
}

#endif /* _GJRAND_PSCALE_H */
