#include <math.h>
#include "nonstd.h"

/* This might or might not meet IEEE standards of accuracy for double */
/* precision and if you have this function available with your vendor's */
/* libraries that version will likely be faster and possibly more accurate. */
/* (If your vendor gave you something worse than this, or nothing at all, */
/* complain very loudly.) */
/* But this should be good enough for gjrand if you've got nothing better. */

static double
expm1_1(const double x)
{
#define SZ 16
	double r=1.0, t;
	int j;

	for (j=SZ-1, t=(double)SZ; j!=0; j--, t--) r = r*x/t + 1.0;
	return r*x;
#undef SZ
}

double
expm1 (const double x)
{
	double y;

	if (x< -0.7 || x>=1.5) return exp(x)-1.0;
	if (x<=0.75) return expm1_1(x);
	y = expm1_1(x * 0.5);
	return (y+2.0) * y;
}
