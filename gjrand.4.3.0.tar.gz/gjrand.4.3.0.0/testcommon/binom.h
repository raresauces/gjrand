/* Miscellaneous stuff for gjrand random numbers version 4.1.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* experimental version using poisson to approximate binomial. */
/* don't trust until heavily tested. */

#ifndef _GJRAND_BINOM_H
#define _GJRAND_BINOM_H 1

#ifndef _GJRAND_INTEG2_H
#include "integ2.h"
#endif

#ifndef _GJRAND_TYPES_H
#include "../src/my_int_types.h"
#endif

#include "lgamma.h"

static double save_ln_t, save_t;

static void
initpois(double t) {save_t = t; save_ln_t = log(t);}

static double
pois(double y) {return exp(save_ln_t*y - logfac(y) - save_t);}

/* what is the probability that throwing x coins (probability p of heads) */
/* you get a result equal or further from expected than y? */
/* Both surprisingly low and high y makes a small P-value. */
/* Not very accurate? */
static double
sumbino(int64_t x, int64_t y, double p)
{
	double r=0.0, z, incr;
	int64_t j;
	int k;

	if (p<=0.0) {if (y<=0) r = 1.0; goto ret;}
	if (p>=1.0) {if (y>=x) r = 1.0; goto ret;}
	if (y<0) goto ret;
	if (y>x) goto ret;

	z = p*x;
	initpois(z);
	incr = sqrt(z)+1.0;

	if (incr<17.0)
	{
		r = pois((double)y);
		incr = r*1.0e-4;
		k = 1;
		if (y<=z) k = -1;
		for (j=y+k; j>=0; j+=k)
		{
			z = pois((double)j); r += z;
			if (z<=incr) break;
		}
	}
	else
	{
		if (y<z) incr = -incr;
		r = gjrt_integ2(pois, y, incr, 3.0e-4, 4);
	}

	ret:
	r *= 2.0;
	if (r>1.0) r = 2.0-r;
	return r;
}

#endif /* _GJRAND_BINOM_H */
