/* Test software for gjrand random numbers version 3.3.2.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#ifndef _GJRAND_CHI2P_H
#define _GJRAND_CHI2P_H 1

#ifndef _GJRAND_INTEG2_H
#include "integ2.h"
#endif

/* Convert chi-squared scores into P-values. */
/* The useful functions to be called from outside are chi2p1() and chi2p2() . */
/* chi2p1() maps chi-squared values on the high side to small p-values. */
/* chi2p2() maps chi-squared values on both sides to small p-values. */

/* I don't make any great claims for this code. It's not thread-safe. */
/* It's slow. Accuracy is not great. */
/* This is supposed to work over a very wide range of (positive, real) chis */
/* and df values, while avoiding overflow and underflow. */

static double chi2p_funoff, chi2p_dfm1;

static double
chi2p_logfun(double x)
{
	if (x<=0.0) return -1.0E35;
	return log(x)*chi2p_dfm1 - 0.5*x*x;
}

static double
chi2p_fun(double x) {return exp(chi2p_logfun(x) - chi2p_funoff);}

static double
chi2p_integrate(double base, double incr)
{
	double lo, inc;
	lo = sqrt(base); inc = incr*2.0/lo;
	return gjrt_integ2(&chi2p_fun, lo, inc, 1.0e-5, 4);
}

/* Used internally. With positive return value, P-value is measured from */
/* the high side, with negative return, from the low side. This avoids */
/* some roundoff errors for extreme results. */
static int
chi2p_val(double chis, int df, double *result)
{
	double mean=df, sdev=sqrt(2.0*mean), tot, fuo;
	int r;

	chi2p_dfm1 = mean-1.0;
	chi2p_funoff = fuo = chi2p_logfun(sqrt(mean));
	tot = chi2p_integrate(mean, -sdev);
	tot += chi2p_integrate(mean, sdev);
	chi2p_funoff = chi2p_logfun(sqrt(chis));
	fuo = exp(chi2p_funoff-fuo);
	r = 1;
	if (chis<mean) {sdev = -sdev; r = -r;}
	*result = chi2p_integrate(chis, sdev) / tot * fuo;

	return r;
}

double
chi2p1(double chis, int df)
{
	double t;
	int j;

	j = chi2p_val(chis, df, &t);
	if (j<0) t = 1.0-t;

	return t;
}

double
chi2p2(double chis, int df)
{
	double t;

	(void)chi2p_val(chis, df, &t);
	if (t>0.5) t = 1.0-t;

	return t*2.0;
}

#endif /* _GJRAND_CHI2P_H */
