/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#ifndef _GJRAND_PCOMBO_H
#define _GJRAND_PCOMBO_H 1

#include "pscale.h"

/* There are n different one-sided P-values in p[]. */
/* Summarise as a single one. */
static double
pcombo(double p[], int n)
{
	double r=1.0;
	int i;

	if (n<=1) return p[0];

	for (i=0; i<n; i++)
	{
		if (p[i]<0.0 || p[i]>1.0) /* basic sanity check */
			fprintf(stderr, "pcombo(): bad P-value %g\n", p[i]);
		if (p[i]<r) r=p[i];
	}

	return pco_scale(r, n);
}

#endif /* _GJRAND_PCOMBO_H */
