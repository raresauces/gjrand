/* Miscellaneous stuff for gjrand random numbers version 3.3.3.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"

/* This one writes a file for use by the tests in testfunif */

/* optional arg is random seed. */

/* This is a lagged fibonacci generator. */
/* This one is a pentanomial with moderately large lags. */

#define LAG1 127
#define LAG2 124
#define LAG3 49
#define LAG4 4
#define BSHIFT 10
#define BSIZE (1<<BSHIFT)
#define BMASK (BSIZE-1)

#if (BSIZE<LAG1 || BSIZE<LAG2 || BSIZE<LAG3 || BSIZE<LAG4)
#error "BSHIFT needs to be bigger."
#endif /* BSIZE */

/* Note that changing BSIZE changes the seeding procedure. */

static double buf[BSIZE];
static uint64_t ibuf[BSIZE];

#define S16 (1.0/65536.0)
#define S64 (S16*S16*S16*S16)

static void
renewbuf(void)
{
	uint64_t t;
	int j;

	for (j=0; j<BSIZE; j++)
	{
		t = ibuf[(j-LAG1)&BMASK] + ibuf[(j-LAG2)&BMASK]
			+ ibuf[(j-LAG3)&BMASK] + ibuf[(j-LAG4)&BMASK];
		ibuf[j] = t; buf[j] = t * S64;
	}
}

static void
doseed(uint32_t seed)
{
	uint64_t t;
	int j;

	t = seed;
	for (j=BSIZE-1; j>=0; j--) {ibuf[j] = t; t = (t<<23)|(t>>41); t++;}
	for (j=4; j>=0; j--) renewbuf();
}

static void
blat(void)
{
	while (1)
	{
		renewbuf();
		if (fwrite(buf, sizeof(double), BSIZE, stdout)!=BSIZE) break;
	}
}

int
main(int argc, char **argv)
{
	unsigned long t;
	uint32_t seed;

	if (argc>1) {sscanf(argv[1], "%lu", &t); seed=t;}
	else seed=time(0);
	doseed(seed);
	blat();

	return 0;
}
