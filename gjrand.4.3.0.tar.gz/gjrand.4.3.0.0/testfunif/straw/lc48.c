/* Miscellaneous stuff for gjrand random numbers version 3.1.0.0 or later. */
/* Copyright (C) 2004-2009 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"

/* This one writes a file for use by the tests in testfunif */

/* optional arg is random seed. */

/* This is a linear congruential generator. */
/* 48 bits is better than 32, but still not good. */

#define S48 (1.0/(((uint64_t)1)<<48))
#define MASK ((((uint64_t)1)<<48)-1)

static void
blat(uint32_t seed)
{
	double buf[1024];
	uint64_t j=seed;

	while (1)
	{
		int i;

		for (i=0; i<1024; i++)
			{j=j*987653421+1; buf[i]=(double)(j&MASK)*S48;}
		if (fwrite(buf, sizeof(double), 1024, stdout)!=1024) break;
	}
}

int
main(int argc, char **argv)
{
	unsigned long t;
	uint32_t seed;

	if (argc>1) {sscanf(argv[1], "%lu", &t); seed=t;}
	else seed=time(0);
	blat(seed);

	return 0;
}
