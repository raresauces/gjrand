/* Miscellaneous stuff for gjrand random numbers version 3.1.0.0 or later. */
/* Copyright (C) 2004-2009 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"

/* This one writes a file for use by the tests in testfunif */

/* optional arg is random seed. */

/* Multiply with carry. Introduced by Marsaglia. */
/* These examples are not very good. */

/* Might be recommended in Numerical Recipes? Fails diff3 diff10 dim3 */
#define MULT 0xffffda61ul
/* This is mine. Appears better. Still fails diff3 diff10 . */
/* #define MULT 2654437434ul */

#define S53 (1.0/(((uint64_t)1)<<53))

static void
blat(uint32_t seed)
{
	double buf[1024];
	uint64_t j=seed;

	j++;
	while (1)
	{
		int i;

		for (i=0; i<1024; i++)
		{
			j = (MULT * (j&0xfffffffful)) + (j>>32);
#if 1
			buf[i] = (((j>>32)&0x1fffff)|((j&0xffffffff)<<21))*S53;
#else
			/* This breaks up the lattice structure. */
			/* Probably an improvement. */
			{
				int64_t k=(j>>35)^(j<<21)^j;
				uint64_t MASK=1;

				MASK <<= 53; MASK -= 1;
				k &= MASK;
				buf[i] = k*S53;
			}
#endif
		}
		if (fwrite(buf, sizeof(double), 1024, stdout)!=1024) break;
	}
}

int
main(int argc, char **argv)
{
	unsigned long t;
	uint32_t seed;

	if (argc>1) {sscanf(argv[1], "%lu", &t); seed=t;}
	else seed=time(0);
	blat(seed);

	return 0;
}
