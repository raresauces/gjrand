/* Miscellaneous stuff for gjrand random numbers version 3.3.5.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* Explicit inversive congruential generator. */

/* March 2010 : I've just noticed diff3 disposes of it quite easily. */
/* The problem maybe is lack of resolution, this is only a 32 bit generator. */
/* Otherwise tests ok, though i haven't gone far (it's slow). */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"

#define MOD ((uint32_t)4294967291UL)
#define ADD 12345

static uint32_t
invert(uint32_t x)
{
	uint32_t d, m, v;

	if (x<2) return x;
	d = MOD / x; m = MOD % x;
	v = MOD-invert(m);
	v = (uint64_t)v * d % MOD;
	return v;
}

static uint32_t
block(double *a, uint32_t s)
{
	int i;

	for (i=0; i<1024; i++)
	{
		if (s<ADD) s += MOD-ADD; else s -= ADD;
		a[i]= (invert((uint32_t)s)+0.5) * (1.0/MOD);
	}

	return s;
}

int
main(int argc, char **argv)
{
	double a[1024];
	unsigned long t;
	uint32_t s;

	if (argc>1) {sscanf(argv[1], "%lu", &t); s=t;}
	else s=time(0);
	s=block(a, s);
	while (1)
	{
		s=block(a, s);
		if (fwrite(a, sizeof(double), 1024, stdout)!=1024) break;
	}

	return 0;
}
