/* Miscellaneous stuff for gjrand random numbers version 3.1.0.0 or later. */
/* Copyright (C) 2004-2009 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"

/* This one writes a file for use by the tests in testfunif */

/* optional arg is random seed. */

/* This is a linear congruential generator. */
/* 96 bits returning the most significant 52 should be quite good */
/* but will still fail the diff tests eventually. */

#define S53 (1.0/(((uint64_t)1)<<53))

static void
blat(uint32_t seed)
{
	double buf[1024];
	uint32_t a=seed, t;
	uint64_t b=seed, c=seed, u, v;

	b++;

	while (1)
	{
		int i;

		for (i=0; i<1024; i++)
		{
			v = c*987653421+1;
			u = b*987653421;
			t = a*987653421;
			c = (uint32_t)v;
			u += v>>32;
			b = (uint32_t)u;
			t += u>>32;
			a = t;
			v = a;
			v = (b>>11) | (v<<21) | 1;

			buf[i]=(double)v*S53;
		}

		if (fwrite(buf, sizeof(double), 1024, stdout)!=1024) break;
	}
}

int
main(int argc, char **argv)
{
	unsigned long t;
	uint32_t seed;
	if (argc>1) {sscanf(argv[1], "%lu", &t); seed=t;}
	else seed=time(0);
	blat(seed);
	return 0;
}
