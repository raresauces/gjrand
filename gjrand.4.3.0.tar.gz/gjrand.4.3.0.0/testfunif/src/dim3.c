/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* This one looks for trouble in 3 dimensions. */

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"
#include "../../testcommon/pcombo.h"

static int errorlevel=0;
static void seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(0);}

#define DIM 2
#define BITS 9
#define AXIS (1<<BITS)
#define DIMSIZE (1<<(BITS*DIM))
#define DIMMASK (DIMSIZE-1)

static struct {uint32_t count; float tot,abs;} stats[DIMSIZE];
static float tstats[DIMSIZE];

static void
init(void)
{
	int i;

	for (i=0; i<DIMSIZE; i++)
		{stats[i].count = 0; stats[i].tot = 0.0; stats[i].abs = 0.0;}
}

static void
butterfly(float *x, float *y)
{
	double a, b;
	int siz=y-x;

	do
	{
		a = *x; b = *y;
		*x = a+b; *y = a-b;
		x++; y++; siz--;
	} while (siz>0);

	siz = y-x; x -= siz; y -= siz; siz >>= 1;
	if (siz) {butterfly(x, x+siz); butterfly(y, y+siz);}
}

static double
transformed(const char *str, int start, double div)
{
	double x, t;
	int j;

	butterfly(tstats, tstats+DIMSIZE/2);
	x = 0.0;
	for (j=start; j<DIMSIZE; j++) {t = fabs(tstats[j]); if (t>x) x = t;}
	x /= sqrt(div);
	t = erfc(M_SQRT1_2*x);
	t = pco_scale(t, DIMSIZE-start);
	printf("%s   = %10.5f sigma (p = %.3g) (transformed)\n", str, x, t);

	return t;
}

static time_t tstart;

static void
doan(int64_t n, int final)
{
	double pval[6];
	double x, t, e;
	int64_t n2;
	time_t tm;
	int j, zeroes=0, doall=n>=9*DIMSIZE;

	if (n<9*DIMSIZE/10+200)
	{
		fprintf(stderr, "warning < %d samples, stats may be wonky.\n",
			9*DIMSIZE/10);
		seterr(1);
	}

	e=((double)n)/((double)DIMSIZE);
	t=0.0;

	n2 = n;
	for (j=0; j<DIMSIZE; j++)
	{
		n2 -= stats[j].count;
		x = stats[j].count-e;
		tstats[j] = x;
		t += x*x;
	}
	t/=e;

	if (n2!=0) printf(
"Overflow in counters. this is seriously non-random.\nP = 0\n\n");

	t -= DIMMASK;
	t /= sqrt(2.0*DIMMASK);
	/* very approx fudge factor to compensate for co-variance. */
	t *= ((double)AXIS*AXIS*AXIS*AXIS)/(AXIS+1.0)/(AXIS*AXIS*AXIS+1.0);

	pval[3]=erfc(fabs(M_SQRT1_2*t));
	if (doall) printf("counts  = %10.5f sigma (p = %.3g)\n", t, pval[3]);

	pval[0] = transformed("count", DIMSIZE/AXIS, (double)n);

	t=0.0;
	for (j=0; j<DIMSIZE; j++)
	{
		e = stats[j].count;
		if (e>0.0)
		{
			x = stats[j].tot * sqrt(12.0/e);
			tstats[j] = x;
			x *= x; t += x;
		}
		else {zeroes++; tstats[j] = 0.0;}
	}

	t-=DIMMASK;
	t/=sqrt(2.0*DIMMASK);

	pval[4]=erfc(fabs(M_SQRT1_2*t));
	if (doall) printf("sums    = %10.5f sigma (p = %.3g)\n", t, pval[4]);

	pval[1] = transformed("sum  ", 0, (double)(DIMSIZE-zeroes));

	t=0.0;
	for (j=0; j<DIMSIZE; j++)
	{
		e = stats[j].count;
		if (e>0.0)
		{
			x = stats[j].abs * sqrt(48.0/e);
			tstats[j] = x;
			x *= x; t += x;
		}
		else tstats[j] = 0.0;
	}

	t-=DIMMASK;
	t/=sqrt(2.0*DIMMASK);

	pval[5]=erfc(fabs(M_SQRT1_2*t));
	if (doall) printf("abs     = %10.5f sigma (p = %.3g)\n", t, pval[5]);

	pval[2] = transformed("abs  ", 0, (double)(DIMSIZE-zeroes));

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		(double)n, (double)(tm-tstart), ctime(&tm));

	if (!final) printf("progress ");

	printf("one sided P value (very small numbers are bad)\n");
	printf("%c = %.3g\n", "pP"[final], pcombo(pval, doall ? 6 : 3));
	if (!final) printf("------\n\n");
}

static int
dobuf(double b[], int index, int s)
{
	double y;
	int j, i=index;

	for (j=0; j<s; j++)
	{
		y=b[j]-0.5;
		stats[i].count++;
		stats[i].tot += y;
		stats[i].abs += fabs(y)-0.25;
		i = (((int)(b[j]*AXIS))+AXIS*i) & DIMMASK;
	}

	return i;
}

static void
readstuff(int64_t n, int progress)
{
	static int64_t progsize[]=
	{
		1500000,
		2000000,
		3000000,
		5000000,
		7000000,
		10000000,
		0
	};
	double buf[1024];
	int64_t p=0, nextp=progsize[0];
	int j, progi=0, index=0;

	while (n<0 || p<n)
	{
		j = 1024;
		if (n>=0 && j>n-p) j = n-p;
		j = fread(buf, sizeof(double), j, stdin);
		if (j<=0) break;
		index = dobuf(buf, index, j);
		p += j;
		if (progress && p>nextp)
		{
			doan(p, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (!nextp) {progi = 0; nextp = progsize[0];}
		}
	}

	if (n>=0 && p<n)
	{
		fprintf(stderr, "warning expected %.0f samples saw only %.0f\n",
			(double)n, (double)p);
		seterr(1);
	}

	doan(p, 1);
}

int
main(int argc, char ** argv)
{
	double dn;
	int64_t n= -1;
	int progress=0, j;

	tstart = time(0);
	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--progress")==0) progress = 1;
		else if (sscanf(argv[j], "%lf", &dn)==1) n = (int64_t)dn;
		else crash("optional arg must be --progress or numeric");
	}
	init();
	readstuff(n, progress);

	return errorlevel;
}
