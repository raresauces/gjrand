/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* This one looks for trouble in 155 dimensions. */

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"
#include "../../testcommon/pcombo.h"

static int errorlevel=0;
static void seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

#define DIM 22
#define BITS 1
#define AXIS (1<<BITS)
#define DIMSIZE (1<<(BITS*DIM))
#define DIMMASK (DIMSIZE-1)

static struct {uint32_t count; float tot,abs;} stats[DIMSIZE];
static float tstats[DIMSIZE];

static void
init(void)
{
	int i;

	for (i=0; i<DIMSIZE; i++)
	{
		stats[i].count = 0;
		stats[i].tot = 0.0;
		stats[i].abs = 0.0;
	}
}

static void
butterfly(float *x, float *y)
{
	double a, b;
	int siz=y-x;

	do
	{
		a = *x; b = *y;
		*x = a+b; *y = a-b;
		x++; y++; siz--;
	} while (siz>0);

	siz = y-x; x -= siz; y -= siz;
	siz >>= 1;
	if (siz) {butterfly(x, x+siz); butterfly(y, y+siz);}
}

static int
bitcount(uint32_t w)
{
	int r;

	w = ((w>>1)&0x55555555) + (w&0x55555555);
	w = ((w>>2)&0x33333333) + (w&0x33333333);
	w = ((w>>4)&0x0f0f0f0f) + (w&0x0f0f0f0f);
	w = ((w>>8)&0x00ff00ff) + (w&0x00ff00ff);
	w = ((w>>16)&0x0000ffff) + (w&0x0000ffff);
	r = w-2;
	if (r<0) r = 0; else if (r>=7) r = 7;
	return r;
}

static double
transformed(const char *str, int start, double div)
{
	double xtr[8], t, pv;
	uint32_t count[8], idx[8], ix;
	int j, weight;

	butterfly(tstats, tstats+DIMSIZE/2);
	for (j=7; j>=0; j--) {count[j] = 0; idx[j] = 0; xtr[j] = 0;}

	for (j=start; j<DIMSIZE; j++)
	{
		weight = bitcount(j);
		t = fabs(tstats[j]);
		count[weight]++;
		if (t>xtr[weight]) {xtr[weight] = t; idx[weight] = j;}
	}

	pv = 2.0; ix = 0;
	for (j=7; j>=0; j--)
	{
		t = xtr[j]/sqrt(div);
		t = erfc(M_SQRT1_2*t);
		t = pco_scale(t, count[j]);
		if (t<pv) {pv = t; ix = idx[j];}
	}
	pv = pco_scale(pv, 8);

	printf("%s  weight = %2d  idx = %06lx  p = %.3g (transformed)\n",
		str, bitcount(ix)+2, (unsigned long)ix, pv);

	return pv;
}

static time_t tstart;

static void
doan(int64_t n, int final)
{
	double pval[6];
	double x, t, e;
	int64_t n2;
	time_t tm;
	int j, zeroes=0, doall=n>=9*DIMSIZE;

	if (n<9*DIMSIZE/10+200)
	{
		fprintf(stderr, "warning < %d samples, stats may be wonky.\n",
			9*DIMSIZE/10);
		seterr(1);
	}

	e=((double)n)/((double)DIMSIZE);
	t=0.0;

	n2 = n;
	for (j=0; j<DIMSIZE; j++)
	{
		n2 -= stats[j].count;
		x = stats[j].count-e;
		tstats[j] = x; t += x*x;
	}
	t/=e;

	if (n2!=0) printf(
"Overflow in counters. this is seriously non-random.\nP = 0\n\n");

	t -= DIMMASK;
	t /= sqrt(2.0*DIMMASK);
	/* very approx fudge factor to compensate for co-variance. */
	t *= ((double)AXIS*AXIS*AXIS*AXIS)/(AXIS+1.0)/(AXIS*AXIS*AXIS+1.0);

	pval[3]=erfc(fabs(M_SQRT1_2*t));
	if (doall) printf("counts  = %10.5f sigma (p = %.3g)\n", t, pval[3]);

	pval[0] = transformed("count", DIMSIZE/AXIS, (double)n);

	t=0.0;
	for (j=0; j<DIMSIZE; j++)
	{
		e = stats[j].count;
		if (e>0.0)
		{
			x = stats[j].tot * sqrt(12.0/e);
			tstats[j] = x;
			x *= x; t += x;
		}
		else {zeroes++; tstats[j] = 0.0;}
	}

	t-=DIMMASK;
	t/=sqrt(2.0*DIMMASK);

	pval[4]=erfc(fabs(M_SQRT1_2*t));
	if (doall) printf("sums    = %10.5f sigma (p = %.3g)\n", t, pval[4]);

	pval[1] = transformed("sum  ", 0, (double)(DIMSIZE-zeroes));

	t=0.0;
	for (j=0; j<DIMSIZE; j++)
	{
		e = stats[j].count;
		if (e>0.0)
		{
			x = stats[j].abs * sqrt(48.0/e);
			tstats[j] = x;
			x *= x; t += x;
		}
		else tstats[j] = 0.0;
	}

	t-=DIMMASK;
	t/=sqrt(2.0*DIMMASK);

	pval[5]=erfc(fabs(M_SQRT1_2*t));
	if (doall) printf("abs     = %10.5f sigma (p = %.3g)\n", t, pval[5]);

	pval[2] = transformed("abs  ", 0, (double)(DIMSIZE-zeroes));

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		(double)n, (double)(tm-tstart), ctime(&tm));

	if (!final) printf("progress ");

	printf("one sided P value (very small numbers are bad)\n");
	printf("%c = %.3g\n", "pP"[final], pcombo(pval, doall ? 6 : 3));
	if (!final) printf("------\n\n");
}

static unsigned
cmp7(const double b[7])
{
	return 0.75*((b[-5]+b[-2])+(b[-1]+b[0])) > (b[-6]+b[-4]+b[-3]);
}

/* s must be divisible by 7 except last call. */
static void
dobuf(double *b, int index[7], int s)
{
	double y;
	unsigned in0=index[0], in1=index[1], in2=index[2], in3=index[3],
		in4=index[4], in5=index[5], in6=index[6];
	int j;

	j = s;

	while (1)
	{
		y = *b-0.5;
		stats[in0].count++;
		stats[in0].tot += y;
		stats[in0].abs += fabs(y)-0.25;

		in1 = (cmp7(b) + 2*in1) & DIMMASK;
		b++; j--; if (j==0) break;
		y = *b-0.5;
		stats[in1].count++;
		stats[in1].tot += y;
		stats[in1].abs += fabs(y)-0.25;

		in2 = (cmp7(b) + 2*in2) & DIMMASK;
		b++; j--; if (j==0) break;
		y = *b-0.5;
		stats[in2].count++;
		stats[in2].tot += y;
		stats[in2].abs += fabs(y)-0.25;

		in3 = (cmp7(b) + 2*in3) & DIMMASK;
		b++; j--; if (j==0) break;
		y = *b-0.5;
		stats[in3].count++;
		stats[in3].tot += y;
		stats[in3].abs += fabs(y)-0.25;

		in4 = (cmp7(b) + 2*in4) & DIMMASK;
		b++; j--; if (j==0) break;
		y = *b-0.5;
		stats[in4].count++;
		stats[in4].tot += y;
		stats[in4].abs += fabs(y)-0.25;

		in5 = (cmp7(b) + 2*in5) & DIMMASK;
		b++; j--; if (j==0) break;
		y = *b-0.5;
		stats[in5].count++;
		stats[in5].tot += y;
		stats[in5].abs += fabs(y)-0.25;

		in6 = (cmp7(b) + 2*in6) & DIMMASK;
		b++; j--; if (j==0) break;
		y = *b-0.5;
		stats[in6].count++;
		stats[in6].tot += y;
		stats[in6].abs += fabs(y)-0.25;

		in0 = (cmp7(b) + 2*in0) & DIMMASK;
		b++; j--; if (j==0) break;
	}

	index[0] = in0; index[1] = in1; index[2] = in2; index[3] = in3;
	index[4] = in4; index[5] = in5; index[6] = in6;
}

static void
readstuff(int64_t n, int progress)
{
	static int64_t progsize[]=
	{
		7000000,
		10000000,
		15000000,
		20000000,
		30000000,
		50000000,
		0
	};
	double buf[6+7*128];
	int64_t p=0, nextp=progsize[0];
	int i, j, progi=0, index[7];

	memset(index, 0, 7*sizeof(int));
	for (j=7*128; j<6+7*128; j++) buf[j] = 0.5;
	j = 7*128;

	while (n<0 || p<n)
	{
		for (i=0; i<6; i++) buf[i] = buf[j+i];
		j = 7*128;
		if (n>=0 && j>n-p) j = n-p;
		j = fread(buf+6, sizeof(double), j, stdin);
		if (j<=0) break;
		dobuf(buf+6, index, j);
		p += j;
		if (j<7*128) break;
		if (progress && p>nextp)
		{
			doan(p, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (!nextp) {progi = 0; nextp = progsize[0];}
		}
	}

	if (n>=0 && p<n)
	{
		fprintf(stderr, "warning expected %.0f samples saw only %.0f\n",
			(double)n, (double)p);
		seterr(1);
	}

	doan(p, 1);
}

int
main(int argc, char ** argv)
{
	double dn;
	int64_t n= -1;
	int progress=0, j;

	tstart = time(0);
	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--progress")==0) progress = 1;
		else if (sscanf(argv[j], "%lf", &dn)==1) n = (int64_t)dn;
		else crash("optional arg must be --progress or numeric");
	}
	init();
	readstuff(n, progress);

	return errorlevel;
}
