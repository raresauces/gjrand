/* Test software for gjrand random numbers version 3.4.1.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"
#include "../../testcommon/pcombo.h"
#include "../../testcommon/chi2p.h"

/* Take the numbers as fixed point and look at groups of 8 bits to the */
/* right of the binary point. Do chi-squared tests. */
/* Not very powerful, but perhaps useful as a basic sanity check. */
/* The randoms need at least 48 bits absolute of precision to pass. */

static int errorlevel=0;
static void seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static int64_t count[6][256];

static time_t tstart;

static void
doan(int64_t n, int final)
{
	double pvs[6];
	double e=n/256.0, t, x;
	time_t tm;
	int i, j;

	for (j=0; j<6; j++)
	{
		t=0.0;
		for (i=0; i<256; i++) {x = count[j][i]-e; t += x*x/e;}
		printf("%15.5f\n", t);
		pvs[j] = chi2p2(t, 255);
	}

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		(double)n, (double)(tm-tstart), ctime(&tm));
	if (!final) printf("progress ");
	printf("one sided P value (very small numbers are bad)\n"
		"%c = %.3g\n", "pP"[final], pcombo(pvs, 6));
	if (!final) printf("------\n\n");
}

static void
readstuff(int64_t n, int progress)
{
	static int64_t progsize[]=
	{
		1500000,
		2000000,
		3000000,
		5000000,
		7000000,
		10000000,
		0
	};
	double buf[1024];
	uint64_t u;
	int64_t p=0, nextp=progsize[0];
	uint32_t s;
	int i, j, progi=0;

	memset(count, 0, sizeof(count));

	while (1)
	{
		i=fread(buf, sizeof(double), 1024, stdin);
		if (i<=0) break;
		if (n>0 && n<p+i) i=n-p;
		p+=i;
		i--;
		do
		{
			u = (int64_t)(buf[i]*(65536.0*65536.0*65536.0));
			j = (u>>40)&255; count[0][j]++;
			j = (u>>32)&255; count[1][j]++;
			s = u;
			j = (s>>24)&255; count[2][j]++;
			j = (s>>16)&255; count[3][j]++;
			j = (s>>8)&255; count[4][j]++;
			j = s&255; count[5][j]++;
			i--;
		} while (i>=0);
		if (n>0 && p>=n) break;
		if (progress && p>nextp)
		{
			doan(p, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (!nextp) {progi = 0; nextp = progsize[0];}
		}
	}

	if (n>0 && p<n)
	{
		fprintf(stderr, "Warning, expected %.0f nums, saw only %.0f\n",
			(double)n, (double)p);
		seterr(1);
	}
	if (p<2560)
	{
		fprintf(stderr, "Warning, < 2560 nums, don't trust result.\n");
		seterr(1);
	}

	doan(p, 1);
}

int
main(int argc, char ** argv)
{
	double dn;
	int64_t n= -1;
	int progress=0, j;

	tstart = time(0);

	printf("expected range [ 191 205 227 284 310 331 ]\n");

	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--progress")==0) progress = 1;
		else if (sscanf(argv[j], "%lf", &dn)==1) n = (int64_t)dn;
		else crash("optional arg must be --progress or numeric");
	}

	readstuff(n, progress);

	return errorlevel;
}
