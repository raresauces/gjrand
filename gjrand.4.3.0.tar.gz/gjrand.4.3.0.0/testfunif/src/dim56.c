/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* This one looks for trouble in 56 dimensions. */

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"
#include "../../testcommon/pcombo.h"

static int errorlevel=0;
static void seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

#define DIM 18
#define BITS 1
#define AXIS (1<<BITS)
#define DIMSIZE (1<<(BITS*DIM))
#define DIMMASK (DIMSIZE-1)

static struct {uint32_t count; float tot1,abs1, tot2,abs2;} stats[DIMSIZE];
static float tstats[DIMSIZE];

static void
init(void)
{
	int i;

	for (i=0; i<DIMSIZE; i++)
	{
		stats[i].count = 0;
		stats[i].tot1 = 0.0;
		stats[i].abs1 = 0.0;
		stats[i].tot2 = 0.0;
		stats[i].abs2 = 0.0;
	}
}

static void
butterfly(float *x, float *y)
{
	double a, b;
	int siz=y-x;

	do
	{
		a = *x; b = *y;
		*x = a+b; *y = a-b;
		x++; y++;
		siz--;
	} while (siz>0);

	siz = y-x; x -= siz; y -= siz;
	siz >>= 1;
	if (siz) {butterfly(x, x+siz); butterfly(y, y+siz);}
}

static double
transformed(const char *str, double div)
{
	double x, t;
	int j;

	butterfly(tstats, tstats+DIMSIZE/2);
	x = 0.0;
	for (j=0; j<DIMSIZE; j++)
	{
		t = fabs(tstats[j]);
		if (t>x) x = t;
	}

	x /= sqrt(div);
	t = erfc(M_SQRT1_2*x);
	t = pco_scale(t, DIMSIZE);

	printf("%s   = %10.5f sigma (p = %.3g) (transformed)\n", str, x, t);

	return t;
}

static time_t tstart;

static void
doan(int64_t n, int final)
{
	double pval[4];
	int64_t n2;
	time_t tm;
	int j, zeroes=0;

	if (n<99*DIMSIZE/100+200)
	{
		fprintf(stderr, "warning < %d samples, stats may be wonky.\n",
			99*DIMSIZE/100);
		seterr(1);
	}

	n2 = n;
	for (j=0; j<DIMSIZE; j++) n2 -= stats[j].count;

	if (n2!=0) printf(
"Overflow in counters. this is seriously non-random.\nP = 0\n\n");

	for (j=0; j<DIMSIZE; j++)
	{
		n2 = stats[j].count;
		if (n2>0) tstats[j] = stats[j].tot1 * sqrt(12.0/n2);
		else {zeroes++; tstats[j] = 0.0;}
	}

	pval[0] = transformed("sum 1 ", (double)(DIMSIZE-zeroes));

	for (j=0; j<DIMSIZE; j++)
	{
		n2 = stats[j].count;
		if (n2>0) tstats[j] = stats[j].abs1 * sqrt(48.0/n2);
		else tstats[j] = 0.0;
	}

	pval[1] = transformed("abs 1 ", (double)(DIMSIZE-zeroes));

	for (j=0; j<DIMSIZE; j++)
	{
		n2 = stats[j].count;
		if (n2>0) tstats[j] = stats[j].tot2 * sqrt(12.0/n2);
		else tstats[j] = 0.0;
	}

	pval[2] = transformed("sum 2 ", (double)(DIMSIZE-zeroes));

	for (j=0; j<DIMSIZE; j++)
	{
		n2 = stats[j].count;
		if (n2>0) tstats[j] = stats[j].abs2 * sqrt(48.0/n2);
		else tstats[j] = 0.0;
	}

	pval[3] = transformed("abs 2 ", (double)(DIMSIZE-zeroes));

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		(double)n, (double)(tm-tstart), ctime(&tm));

	if (!final) printf("progress ");

	printf("one sided P value (very small numbers are bad)\n");
	printf("%c = %.3g\n", "pP"[final], pcombo(pval, 4));
	if (!final) printf("------\n\n");
}

/* s must be divisible by 3 except last call. */
static void
dobuf(const double *b, int index[3], int s)
{
	double y, z, a;
	int j, i0=index[0], i1=index[1], i2=index[2];

	j = s;

	while (1)
	{
		y = b[-1]-0.5;
		z = b[0]-0.5;
		stats[i0].count++;
		stats[i0].tot1 += y;
		stats[i0].abs1 += fabs(y)-0.25;
		a = fabs(z)-0.25;
		stats[i0].tot2 += z;
		stats[i0].abs2 += a;
		i1 = ((b[-3]+b[-2]>2.0*b[-1])+2*i1) & DIMMASK;
		j--; if (j==0) break;

		y = b[1]-0.5;
		stats[i1].count++;
		stats[i1].tot1 += z;
		stats[i1].abs1 += a;
		a = fabs(y)-0.25;
		stats[i1].tot2 += y;
		stats[i1].abs2 += a;
		i2 = ((b[-2]+b[-1]>2.0*b[0])+2*i2) & DIMMASK;
		j--; if (j==0) break;

		z = b[2]-0.5;
		stats[i2].count++;
		stats[i2].tot1 += y;
		stats[i2].abs1 += a;
		a = fabs(z)-0.25;
		stats[i2].tot2 += z;
		stats[i2].abs2 += a;
		i0 = ((b[-1]+b[0]>2.0*b[1])+2*i0) & DIMMASK;
		b += 3;
		j--; if (j==0) break;
	}

	index[0] = i0; index[1] = i1; index[2] = i2;
}

/* must be a multiple of 3 */
#define MYBSIZ 1536

static void
readstuff(int64_t n, int progress)
{
	static int64_t progsize[]=
	{
		1500000,
		2000000,
		3000000,
		5000000,
		7000000,
		10000000,
		0
	};
	double buf[MYBSIZ+5];
	int64_t p=0, nextp=progsize[0];
	int j, progi=0, index[3];

	index[0] = index[1] = index[2] = 0;
	buf[MYBSIZ] = buf[MYBSIZ+1] = buf[MYBSIZ+2] = buf[MYBSIZ+3] = 0.5;
	j = MYBSIZ;

	while (n<0 || p<n)
	{
		buf[0] = buf[j]; buf[1] = buf[j+1];
		buf[2] = buf[j+2]; buf[3] = buf[j+3];
		j = MYBSIZ;
		if (n>=0 && j>n-p) j = n-p;
		j = fread(buf+4, sizeof(double), j, stdin);
		if (j<=0) break;
		dobuf(buf+4, index, j);
		p += j;
		if (j<MYBSIZ) break;
		if (progress && p>nextp)
		{
			doan(p, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (!nextp) {progi = 0; nextp = progsize[0];}
		}
	}

	if (n>=0 && p<n)
	{
		fprintf(stderr, "warning expected %.0f samples saw only %.0f\n",
			(double)n, (double)p);
		seterr(1);
	}

	doan(p, 1);
}

int
main(int argc, char ** argv)
{
	double dn;
	int64_t n= -1;
	int progress=0, j;

	tstart = time(0);

	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--progress")==0) progress = 1;
		else if (sscanf(argv[j], "%lf", &dn)==1) n = (int64_t)dn;
		else crash("optional arg must be --progress or numeric");
	}

	init();

	readstuff(n, progress);

	return errorlevel;
}
