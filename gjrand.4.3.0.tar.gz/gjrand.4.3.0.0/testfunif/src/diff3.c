/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"
#include "../../testcommon/pcombo.h"
#include "../../testcommon/chi2p.h"

static int errorlevel=0;
static void
seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void
crash(const char *s)
{
	fflush(stdout);
	seterr(1); fprintf(stderr, "crash [%s]\n", s); exit(errorlevel);
}

#define ITER 11
#define DIM 3
#define SHIFT 4
#define SIZ1 (1<<SHIFT)
#define SIZ (SIZ1*SIZ1*SIZ1)

struct res {int64_t x[DIM]; uint64_t n;};
static struct res res[ITER][SIZ];

static void
init(void)
{
	int i, j, k;

	for (j=0; j<ITER; j++) for (i=0; i<SIZ; i++)
	{
		struct res *p = &(res[j][i]);
		for (k=0; k<DIM; k++) p->x[k] = -1;
		p->n = 0;
	}
}

static void
dopoint(double v[DIM])
{
	int64_t x[DIM], y[DIM], mask, ti;
	double t, u;
	int i, j, k, shift;
	struct res *ptr;

	shift = 60; mask = (((int64_t)1)<<(shift));
	t = mask;
	for (j=0; j<DIM; j++) x[j] = t*v[j];

	mask--;

	shift -= SHIFT; mask >>= SHIFT;

	i = 0;
	for (j=0; j<DIM; j++)
	{
		i *= SIZ1;
		i += ((int)(x[j]>>shift)) & (SIZ1-1);
		x[j] &= mask;
	}

	k = 0;
	while (1)
	{
		ptr = &(res[k][i]);
		ptr->n++;
		if (k>=ITER-1) break;
		if (ptr->x[0] < 0)
			{for (j=0; j<DIM; j++) ptr->x[j] = x[j]; break;}

		i = 0; shift -= SHIFT; mask >>= SHIFT;
		for (j=0; j<DIM; j++)
		{
			i *= SIZ1;
			ti = x[j] - ptr->x[j];
			y[j] = ti & mask;
			i += ((int)(ti>>shift)) & (SIZ1-1);
		}

		t = 1.0; u = 1.0;
		for (j=0; j<DIM; j++) {t *= x[j]; u *= ptr->x[j];}
		if (t>u) for (j=0; j<DIM; j++) ptr->x[j] = x[j];

		for (j=0; j<DIM; j++) x[j] = y[j];

		k++;
	}
}

static time_t tstart;

static void
doan(int64_t n, int final)
{
	double pval[ITER], p, e, t;
	uint64_t tot;
	time_t tm;
	struct res *ptr;
	int j, k;

	for (j=0; j<ITER; j++)
	{
		tot = 0;
		ptr = &(res[j][0]);
		for (k=0; k<SIZ; k++) tot += ptr[k].n;
		if (tot < 10*SIZ) break;

		e = tot/((double)SIZ);
		p = 0.0;
		for (k=0; k<SIZ; k++) {t = ptr[k].n-e; p += t*t;}
		p /= e;
		printf("chis = %10.0f", p);
		p = chi2p2(p, SIZ-1);
		printf("  (%.6g)\n", p);
		pval[j]=p;
	}

	if (j==0) crash("not enough data, try with more");

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		(double)n*DIM, (double)(tm-tstart), ctime(&tm));

	if (!final) printf("progress ");

	printf("one sided P value (very small numbers are bad)\n");
	printf("%c = %.3g\n", "pP"[final], pcombo(pval, j));
	if (!final) printf("------\n\n");
}

static void
readstuff(int64_t n, int progress)
{
	static int64_t progsize[]=
	{
		300000,
		500000,
		700000,
		1000000,
		1500000,
		2000000,
		0
	};
	double v[DIM];
	int64_t p=0, nextp=progsize[0];
	int progi=0;

	init();

	do
	{
		if (fread(v, sizeof(double), DIM, stdin)!=DIM) break;
		dopoint(v);
		p++;
		if (progress && p*DIM>nextp)
		{
			doan(p, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (!nextp) {progi = 0; nextp = progsize[0];}
		}
	} while (n<0 || p<n);

	if (n>=0 && p<n)
	{
		fprintf(stderr, "warning expected %.0f points, saw only %.0f\n",
			(double)n, (double)p);
		seterr(1);
	}

	doan(p, 1);
}

int
main(int argc, char **argv)
{
	double dn;
	int64_t n= -1;
	int progress=0, j;

	tstart = time(0);

	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--progress")==0) progress = 1;
		else if (sscanf(argv[j], "%lf", &dn)==1) n = (int64_t)dn/DIM;
		else crash("optional arg must be --progress or numeric");
	}

	readstuff(n, progress);

	return errorlevel;
}
