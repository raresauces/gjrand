/* Test software for gjrand random numbers version 3.4.1.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"
#include "../../testcommon/pcombo.h"

#define LO (1.0/3.0)
#define HI (2.0/3.0)

static int errorlevel=0;
static void seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static double histo4k[3][4097];
static double histo1k[3][1025];
static double histo256[3][257];
static double histo64[3][65];
static double buf[4096];

#define MAX 4096
static double expect[MAX+1];

static void
mkexpect(int s, int64_t n)
{
	double ex2[MAX+1], *p1=expect, *p2=ex2, *pt;
	int j, k;

	p1[0] = n*4096/s;
	for (j=1; j<=s; j++) {p1[j] = 0.0; p2[j] = 0.0;}

	for (j=1; j<=s; j++)
	{
		p2[0] = p1[0]*HI;
		for (k=1; k<=j; k++) p2[k] = p1[k-1]*LO + p1[k]*HI;
		pt = p1; p1 = p2; p2 = pt;
	}

	if (p1!=expect) memcpy(expect, p1, sizeof(expect));
}

static void
an1(int s, int64_t n, int dm, double histo[], double *pval)
{
	double mom[6], xmom[6], xsd[6], t, m, s1, s2;
	int j;

	n = n*4096/s;

	m = 0.0;
	for (j=0; j<=s; j++) m += expect[j]*j;
	m /= n;
	xmom[1] = m;

	s1 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; s1 += expect[j]*t*t;}
	s1 /= n;
	xmom[2] = s1;
	xsd[1] = sqrt(s1);

	s2 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; t *= t; t -= s1; s2 += expect[j]*t*t;}
	s2 /= n;
	xsd[2] = sqrt(s2);

	s1 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; s1 += expect[j]*t*t*t;}
	s1 /= n;
	xmom[3] = s1;

	s2 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; t *= t*t; t -= s1; s2 += expect[j]*t*t;}
	s2 /= n;
	xsd[3] = sqrt(s2);

	s1 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; s1 += expect[j]*t*t*t*t*t;}
	s1 /= n;
	xmom[5] = s1;

	s2 = 0.0;
	for (j=0; j<=s; j++)
		{t = j-m; t *= t*t*t*t; t -= s1; s2 += expect[j]*t*t;}
	s2 /= n;
	xsd[5] = sqrt(s2);

	m = xmom[1];

	s1 = 0.0;
	for (j=0; j<=s; j++) s1 += ((double)(histo[j]))*j;
	s1 /= n;
	mom[1] = s1;

	s1 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; s1 += ((double)(histo[j]))*t*t;}
	s1 /= n;
	mom[2] = s1;

	s1 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; s1 += ((double)(histo[j]))*t*t*t;}
	s1 /= n;
	mom[3] = s1;

	s1 = 0.0;
	for (j=0; j<=s; j++) {t = j-m; s1 += ((double)(histo[j]))*t*t*t*t*t;}
	s1 /= n;
	mom[5] = s1;

	s2 = sqrt((double)n);

	s1 = s2*(mom[2]-xmom[2])/xsd[2];
	pval[0] = erfc(fabs(M_SQRT1_2*s1));
	printf("var %11.5g; ", s1);

	s1 = s2*(mom[3]-xmom[3])/xsd[3];
	pval[1] = erfc(fabs(M_SQRT1_2*s1));
	printf("skew %11.5g; ", s1);

	s1 = s2*(mom[5]-xmom[5])/xsd[5];
	pval[2] = erfc(fabs(M_SQRT1_2*s1));
	printf("m5 %11.5g;", s1);

	if (dm)
	{
		s1 = s2*(mom[1]-xmom[1])/xsd[1];
		pval[3] = erfc(fabs(M_SQRT1_2*s1));
		printf("    mean %11.5g;", s1);
	}
	putchar('\n');
}

static time_t tstart;

static void
doan(int64_t n, int final)
{
	double pval[39];
	time_t tm;

	if (n<100)
	{
		fprintf(stderr, "not enough data, try at least 420K numbers\n");
		seterr(1);
		if (n<=0) crash("no data at all?");
	}

	mkexpect(64, n);
	printf("blocksize = 64\nlo  ");
	an1(64, n, 0, &(histo64[0][0]), pval);
	printf("mid ");
	an1(64, n, 0, &(histo64[1][0]), pval+3);
	printf("hi  ");
	an1(64, n, 0, &(histo64[2][0]), pval+6);

	mkexpect(256, n);
	printf("blocksize = 256\nlo  ");
	an1(256, n, 0, &(histo256[0][0]), pval+9);
	printf("mid ");
	an1(256, n, 0, &(histo256[1][0]), pval+12);
	printf("hi  ");
	an1(256, n, 0, &(histo256[2][0]), pval+15);

	mkexpect(1024, n);
	printf("blocksize = 1024\nlo  ");
	an1(1024, n, 0, &(histo1k[0][0]), pval+18);
	printf("mid ");
	an1(1024, n, 0, &(histo1k[1][0]), pval+21);
	printf("hi  ");
	an1(1024, n, 0, &(histo1k[2][0]), pval+24);

	mkexpect(4096, n);
	printf("blocksize = 4096\nlo  ");
	an1(4096, n, 1, &(histo4k[0][0]), pval+27);
	printf("mid ");
	an1(4096, n, 1, &(histo4k[1][0]), pval+31);
	printf("hi  ");
	an1(4096, n, 1, &(histo4k[2][0]), pval+35);

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		n*4096.0, (double)(tm-tstart), ctime(&tm));

	if (!final) printf("progress ");

	printf("one sided P value (very small numbers are bad)\n");
	printf("%c = %.3g\n", "pP"[final], pcombo(pval, 39));
	if (!final) printf("------\n\n");
}

static void
do64(double *bp, int ct[3])
{
	double *b=bp+64, x;
	int i= -64, h=0, l=0, m;

	do {x=b[i]; l += x<LO; h += x>HI; i++;} while (i<0);
	m = 64-l-h;
	ct[0] += l; ct[1] += m; ct[2] += h;
	histo64[0][l]++; histo64[1][m]++; histo64[2][h]++; }

static void
do256(double *bp, int ct[3])
{
	int c[3], l, m, h;

	c[0] = c[1] = c[2] = 0;
	do64(bp, c); do64(bp+64, c); do64(bp+128, c); do64(bp+192, c);
	l = c[0]; m = c[1]; h = c[2];
	ct[0] += l; ct[1] += m; ct[2] += h;
	histo256[0][l]++; histo256[1][m]++; histo256[2][h]++;
}

static void
do1k(double *bp, int ct[3])
{
	int c[3], l, m, h;

	c[0] = c[1] = c[2] = 0;
	do256(bp, c); do256(bp+256, c); do256(bp+512, c); do256(bp+768, c);
	l = c[0]; m = c[1]; h = c[2];
	ct[0] += l; ct[1] += m; ct[2] += h;
	histo1k[0][l]++; histo1k[1][m]++; histo1k[2][h]++;
}

static void
do4k(void)
{
	int c[3], l, m, h;

	c[0] = c[1] = c[2] = 0;
	do1k(buf, c); do1k(buf+1024, c); do1k(buf+2048, c); do1k(buf+3072, c);
	l = c[0]; m = c[1]; h = c[2];
	histo4k[0][l]++; histo4k[1][m]++; histo4k[2][h]++;
}

static void
readstuff(int64_t n, int progress)
{
	static int64_t progsize[]=
	{
		500000,
		700000,
		1000000,
		1500000,
		2000000,
		3000000,
		0
	};
	int64_t p=0, nextp=progsize[0];
	int progi=0;

	memset(histo64, 0, sizeof(histo64));
	memset(histo256, 0, sizeof(histo256));
	memset(histo1k, 0, sizeof(histo1k));
	memset(histo4k, 0, sizeof(histo4k));

	while (n<0 || p<n)
	{
		if (fread(buf, sizeof(double), 4096, stdin)!=4096) break;
		do4k();
		p++;
		if (progress && p*4096>nextp)
		{
			doan(p, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (!nextp) {progi = 0; nextp = progsize[0];}
		}
	}

	if (n>0 && p<n)
	{
		fprintf(stderr, "expected %.0f blocks, saw only %.0f\n",
			(double)n, (double)p );
		seterr(1);
	}

	doan(p, 1);
}


int
main(int argc, char **argv)
{
	double dn;
	int64_t n= -1;
	int progress=0, j;

	tstart = time(0);
	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--progress")==0) progress = 1;
		else if (sscanf(argv[j], "%lf", &dn)==1) n = (int64_t)(dn/4096);
		else crash("optional arg must be --progress or numeric");
	}
	readstuff(n, progress);

	return errorlevel;
}
