/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <string.h>
#include "../../src/gjrand.h"

/* This one writes a file for use by several tests in this directory. */
/* The output consists of binary type double numbers. Note that these */
/* have different formats depending on CPU, OS, and compiler, so try */
/* to generate and use them on the same computer. */
/* They are supposed to be uniformly distributed on [ 0 1 ) */

/* This one uses gjrand_shuffle1(). */
/* Note that shuffle size needs to be above 2 ** 48 for some of the tests. */

/* First arg is the shuffle size. */
/* Optional second arg is number of doubles to write. */
/*	Attempts to write forever if negative or absent. */
/* third optional arg is random seed. */

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static void
blat(struct gjrand *g, uint64_t mod, int64_t s)
{
	struct gjrand_shufstate gsh;
	double buf[256],  scale = 1.0/mod;

	while (s)
	{
		int c, i=255;

		gjrand_shuffleprep(g, mod, &gsh);
		do
		{
			buf[i--] = (gjrand_shuffle1(&gsh) + 0.5) * scale;
		} while (i>=0);
		if ((uint64_t)s>256) c=256; else c=s;
		if (fwrite(buf, sizeof(double), c, stdout)!=(size_t)c)
			crash("fwrite fails");
		if (s>0) s-=c;
	}
}

int
main(int argc, char **argv)
{
	double ds;
	int64_t s= -1;
	uint64_t mod=0;
	unsigned long seed;
	struct gjrand g;

	if (argc>3) {sscanf(argv[3], "%lu", &seed); gjrand_init(&g, seed);}
	else gjrand_initrand(&g);
	if (argc>2 && sscanf(argv[2], "%lf", &ds)==1) s=(int64_t)ds;
	if (argc>1 && sscanf(argv[1], "%lf", &ds)==1) mod = (uint64_t)ds;
	else crash("first argument modulus is compulsory, should be a number");
	blat(&g, mod, s);

	return 0;
}
