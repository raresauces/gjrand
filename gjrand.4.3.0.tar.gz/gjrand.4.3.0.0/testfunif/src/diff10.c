/* Test software for gjrand random numbers version 3.4.1.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../../src/my_int_types.h"
#include "../../testcommon/pcombo.h"
#include "../../testcommon/chi2p.h"

static int errorlevel=0;
static void
seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void
crash(const char *s)
{
	fflush(stdout);
	seterr(1); fprintf(stderr, "crash [%s]\n", s); exit(errorlevel);
}

#define DIM 10
#define SIZ (1<<14)

struct res {uint16_t x[DIM]; uint64_t n;};
static struct res res[DIM][SIZ];

static void
init(void)
{
	int i, j, k;

	for (j=0; j<DIM; j++) for (i=0; i<SIZ; i++)
	{
		struct res *p = &(res[j][i]);
		for (k=0; k<DIM; k++) p->x[k] = SIZ;
		p->n = 0;
	}
}

static void
dopoint(const double v[DIM])
{
	uint16_t x[DIM], y[DIM];
	int i, j, k;
	struct res *ptr;

	for (j=0; j<DIM; j++) x[j] = ((int)(v[j]*SIZ)) & (SIZ-1);

	for (i=0; i<DIM; i++)
	{
		for (j=i; j<DIM; j++) y[j] = x[j];
		ptr = &(res[i][y[i]]);
		ptr->n++;
		for (j=i; j<DIM; j++) x[j] = (x[j] - ptr->x[j]) & (SIZ-1);
		for (j=i; j<DIM; j++)
		{
			k = ((int)(y[j])) - ((int)(ptr->x[j]));
			if (k>0) goto done;
			if (k<0) goto doit;
		}

		doit:
		for (j=i; j<DIM; j++) ptr->x[j] = y[j];

		done: ;
	}
}

static time_t tstart;

static void
doan(int64_t n, int final)
{
	double pval[DIM], p, e, t;
	uint64_t tot;
	time_t tm;
	struct res *ptr;
	int j, k;

	for (j=0; j<DIM; j++)
	{
		tot = 0;
		ptr = &(res[j][0]);
		for (k=0; k<SIZ; k++) tot += ptr[k].n;
		if (tot < 10*SIZ) break;

		e = tot/((double)SIZ);
		p = 0.0;
		for (k=0; k<SIZ; k++) {t = ptr[k].n-e; p += t*t;}
		p /= e;
		printf("order = %d : chis = %10.0f", j, p);
		p = chi2p2(p, SIZ-1);
		printf(" ;  p = %.6g\n", p);
		pval[j]=p;
	}

	if (j==0)
	{
		fprintf(stderr, "blocks = %15.0f ; wanted >= %ld\n",
			(double)tot, 10L*SIZ);
		crash("not enough data, try with more");
	}

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		(double)n*DIM, (double)(tm-tstart), ctime(&tm));

	if (!final) printf("progress ");

	printf("one sided P value (very small numbers are bad)\n");
	printf("%c = %.3g\n", "pP"[final], pcombo(pval, j));
	if (!final) printf("------\n\n");
}

static void
readstuff(int64_t n, int progress)
{
	static int64_t progsize[]=
	{
		2000000,
		3000000,
		5000000,
		7000000,
		10000000,
		15000000,
		0
	};
	double v[DIM];
	int64_t p=0, nextp=progsize[0];
	int progi=0;

	init();

	do
	{
		if (fread(v, sizeof(double), DIM, stdin)!=DIM) break;
		dopoint(v);
		p++;
		if (progress && p*DIM>nextp)
		{
			doan(p, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (!nextp) {progi = 0; nextp = progsize[0];}
		}
	} while (n<0 || p<n);

	if (n>=0 && p<n)
	{
		fprintf(stderr, "warning expected %.0f points, saw only %.0f\n",
			(double)n, (double)p);
		seterr(1);
	}

	doan(p, 1);
}

int
main(int argc, char **argv)
{
	double dn;
	int64_t n= -1;
	int progress=0, j;

	tstart = time(0);

	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--progress")==0) progress = 1;
		else if (sscanf(argv[j], "%lf", &dn)==1) n = (int64_t)dn/DIM;
		else crash("optional arg must be --progress or numeric");
	}
	readstuff(n, progress);

	return errorlevel;
}
