/* Test software for gjrand random numbers version 3.3.1.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>

#include "../../src/my_int_types.h"

/* This one reads uniform random bits on standard input, converts to */
/* uniform binary double in [ 0 , 1 ] and writes on standard output. */

/* No args */

/* eg: */
/* ../testunif/bin/blatil | ./uni2f | ./dim3 10000000 */

void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static uint32_t in[2048];
static double out[1024];

static void
conv(void)
{
#define B2 (0.25)
#define B8 (B2*B2*B2*B2)
#define B32 (B8*B8*B8*B8)
	int i;
	for (i=0; i<1024; i++) out[i]=((in[2*i+1]*B32)+in[2*i])*B32;
}

int
main()
{
	int r;

	do
	{
		r=fread(in, sizeof(uint32_t), 2048, stdin);
		if (r<=0) break;
		conv();
		r/=2;
	} while (fwrite(out, sizeof(double), r, stdout)==(size_t)r);

	return 0;
}
