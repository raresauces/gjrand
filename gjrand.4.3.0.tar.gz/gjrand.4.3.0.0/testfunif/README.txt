Programs to create and test uniform random binary doubles on [ 0 .. 1 ) .

To create random streams:
gen/blatd : uses gjrand_drand to make randoms.
gen/blatdv : uses gjrand_drandv to make randoms (faster).
gen/* : various others.
gen/uni2f : reads uniform random bits, writes random binary doubles on
    [ 0 .. 1 ) .  Use with the progs in ../testunif/gen or ../testunif/straw .
Look in palladiumbell/ . Use blatnorm or the straw
generators piped through tounif. eg.

./gen/blatd | ./bin/chi 1000000
../testunif/bin/blatrand inf | ./gen/uni2f | ./bin/chi 1000000
../palladiumbell/blatnorm | ../palladiumbell/tounif f 1 | ./bin/chi 1000000

There is now a Master Control Program to run several tests, eg:

./mcpf --tiny < somefile.dat
./gen/blatdv | ./mcpf --small

The size args are:
--tiny         1M doubles
--small       10M doubles
--standard   100M doubles (default)
--big          1G doubles
--huge        10G doubles
--even-huger 100G doubles
--tera         1T doubles.

pmcpf is an alternative version that runs in parallel. It is probably
faster on multi core machines, or even on single core machines if the
generator to be tested is very slow.

Individual programs for above:
chi
diff10
diff3
dim155
dim3
dim56
nda4
nda8
rda
tri

The programs take an optional argument, a count of how many doubles to
process (default is to run to end of input file). Also --progress ,
causes progress reports from time to time.
