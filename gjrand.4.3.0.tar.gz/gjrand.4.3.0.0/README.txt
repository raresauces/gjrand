Gjrand random number library.
=============================

The gjrand library and associated test programs, utilities, documentation,
etc, are all licensed under the Gnu General Public License, either version 2
or version 3 at your option. If you distribute gjrand or derived works, this
can be under:
(a) GPL v2 or GPL v3 at the recipient's option, or
(b) just GPL v2, or
(c) just GPL v3.
(However if you got this gjrand from some third party under just one version
of the GPL, that's the only one you can distribute it under.)

See the files COPYING.txt and/or COPYING3.txt for details.

This is yet another "alpha test" release. That means i have tested almost
everything and it seems to work ok. I now know that a few other people have
tested at least some parts of recent versions, but beware, there could still
be bugs, and there almost certainly are portability problems. Documentation
is sparse.  This software is still only for people who know how to use
a C compiler.

The library provides API calls for the following:

seed the generator
save and restore state
generate integer uniform random numbers
generate integer special: coins, biased coins, dice, shuffle, poisson
generate floating point uniform numbers
generate floating point special:
	normal distribution
	t distribution
	chi-square distribution
	exponential distribution
	in a n-dimensional sphere
	on the surface of a n-dimensional sphere
	and a few others.

gjrand should be thread-safe.
It is written in C, but appeared to also compile as C++ last time i tried.

There are also test programs that test all of the above and could also
be used or adapted to test other alleged random sources. Some alternative
(mostly bad) pseudo random generators are also provided so you can amuse
yourself by watching tests fail.

Documentation is scattered throughout the sub-directories, usually
near the relevant source code. Best programmer's documentation for
the library functions is in src/gjrand.h . All other documentation
is hopefully now in files with the .txt extension.

-----

compiler
========
The file compiler in this directory specifies the compiler and flags
used by compile scripts in all subdirectories. Tweak it if you don't
use gcc or you want special flags (eg, profile, debug or extra optimise).
This file and the scripts are written for POSIX or Bourne shell compatibles.
If you don't have one of those, have fun translating to your favourite
scripting language!


src
===
The library source code is in subdirectory  src  . No binaries are
supplied. You need a C compiler. If your setup is very like mine
the script  compile  should build the library. Otherwise you need
to know what you're doing. Limited documentation is in the
files  README.txt  and  gjrand.h  . If you just want a random number
generator library, this subdirectory is all you need. See "Portability"
below if there's trouble.

testmisc
========
This contains kat.c , the Known Answer Test. This is a very useful test
program once you've got the library compiled. It will tell you if the library
is basically working and getting the same sequences as on my development
machine.

Also a couple of miscellaneous tests.

util
====
Subdirectory  util  contains various small programs that i used
to help develop the library. This is not useful to most people.

testunif
========
Subdirectory  testunif  contains programs to generate hopefully random uniform
bitstreams, and programs to perform tests on them. These are now quite
extensive. Note that there is not a huge overlap between tests here and those
in Diehard or NIST although those are for much the same purpose. This is a
feature, not a bug. If you want Diehard or NIST tests, go and get them.
(Or, much better, get Pracrand from SourceForge, or TestU01 by L'Ecuyer
and friends at Montreal. Diehard is of historical interest only.
NIST is possibly useful for some specialist purposes, but can be difficult.)

I wanted to do something different to increase the "genepool" of available
tests for random bits.

testunif/straw contains some dubious uniform pseudo-random generators.

palladiumbell
=============
Subdirectory  palladiumbell  contains tests for the  gjrand_normal()
function. I think these are already quite good, but if you have bug
reports or useful advice for improvements i'd like to hear them.
README expains how to interpret the test program output.  compile  is a
script that compiled all test programs on my machine.
Programmers should find it fairly easy to adapt these programs to test
other sources of alleged normally distributed random numbers.

palladiumbell/straw contains some dubious normal pseudo-random generators.

testfunif
=========
Tests for uniform double precision floating point on [0.0 .. 1.0).

testother
=========
Subdirectory  testother  contains tests for other random generator functions.
These now cover all gjrand generators, but are not as thorough as the
palladiumbell or testunif tests.

-----

Portability issues
------------------

If things don't want to compile, here are some likely trouble areas i can
think of.

gjrand uses a few math features that aren't in the 1989 ANSI C standard, but
are provided by many compilers and libraries. I think these are actually
in the latest versions of the C and C++ standards, but might be missing
in very old systems.

For the gjrand library, log1p() is provided in subdirectory src/nonstd .
Copy it up to the main src directory only if you need it.

Some of the tests might use log1p(), and also expm1() and erfc(). These
last two are provided in directory testcommon, but if you need them,
you'll have to fix the build process yourself. Eventually source for
these functions will be removed.

In older versions, the file src/initrand.c called some POSIX system calls
that might not be available on non-POSIX systems. I have now attempted to
fix this, but don't have a working non-POSIX system to test on. If there are
remaining problems, please complain on the gjrand forums at sourceforge.net .
In addition, src/initrand.c now uses the __thread keyword, which is probably
not an ANSI C keyword, but an extension found in GCC and some other compilers.
Look in the source file for hints on how to fix. If you have some #ifdef's
which you have tested and appear to be solid, let me know on forums.

testunif/src/mcp.c , pmcp.c , testfunif/src/mcpf.c and pmcpf.c
all use open(). Officially this is not standard C. It is required by POSIX.
As far as i can tell, it is implemented by most non-POSIX C compilers too,
including several for MS-DOS and MS-Windows. If open() really doesn't exist
for you, you could edit the code to enable the fake version of open() provided.
Proper open() gives slightly better safety if available.

testunif/src/pmcp.c and testfunif/src/pmcpf.c both make use of popen() and
pclose(). These are not in ANSI C, though POSIX and various other standards
require them. If you don't have them, just don't build these two programs
and use mcp and mcpf instead.

If you find more portability problems, or cleaner or more detailed fixes
for the ones above, please post on the gjrand forums on SourceForge,
and i'll try to (eventually) incorporate suggestions.

-----

Gjrand is not suitable for producing "cryptographic random numbers".
There are several concrete reasons for this, but more obvious, and
hopefully enough to scare you off, is that i gave no thought whatsoever
to achieving cryptographic standard in either the design or programming
stages. Instead, i concentrated on the needs of simulation, computer games,
and "Monte-Carlo algorithms".

In general the requirements of cryptography are somewhat incompatible
with those of other random number uses, and it is probably a good idea
to use different software for these two purposes.

-----

I am not currently aware of any bugs in the current version. If you find some,
check if there is a newer version available which fixes them. If not,
i'd like to hear from you. Try to be clear about your setup and
exactly what you think is wrong. Example source code that demonstrates
the bug would be nice.

I want to hear about portability problems, and especially so if you
have a fix that makes it work on your machine without breaking anything
else.

I am now vaguely interested in getting it to work on MS-Windows but at this
stage haven't actually bothered to obtain a computer and development system
to achieve this. Bug reports and advice will be read with interest.
Carefully tested fixes with more interest. Note there are alternatives for
MS-Windows users. Recent versions include some sort of Linux-in-virtual-machine
thing that is reportedly quite good. There was (maybe still is?) also Cygwin
to do a POSIX environment.

I'm vaguely interested in hearing requests for extra features. I can
think of heaps of extras to add, but i don't know which ones people would
actually use.

Gjrand doesn't conform to any standard API for random number generators
because i was not aware of any such API when i designed it. If you have a
favourite, let me know.

-----

If you want to report bugs or make contact for other reasons, the best
option is to post on the gjrand public forums on SourceForge. I should
eventually read those. I use a very limited dialup account, and am
sometimes out of town without net access. Be patient.
