/* Test software for gjrand random numbers version 4.3.0.0 or later. */
/* Copyright (C) 2004-2019 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdio.h>
#include <string.h>

#include "../src/gjrand.h"

/* Known Answer Tests. */
/* Run many of the API calls in gjrand (the ones that should run predictably) */
/* and check if the answers are as expected. */

int main(int argc, char **argv)
{
	struct gjrand gjr;
	int fail=0, skip=0, succeed=0;

	printf("Version string\n[%s]\n\n",gjrand_version_string);
	printf("Major version     = %d\n", gjrand_version_number[0]);
	printf("Minor version     = %d\n", gjrand_version_number[1]);
	printf("Very minor version= %d\n", gjrand_version_number[2]);
	printf("Patch level       = %d\n\n", gjrand_version_number[3]);
	if (gjrand_version_number[0]!=4 || gjrand_version_number[1]!=3
		|| gjrand_version_number[2]!=0 || gjrand_version_number[3]!=0)
	{
printf("This KAT is for gjrand version 4.3.0.0 but is currently linked\n"
"against a different version. More tests may fail because of this.\n");
		fail++;
	}
	succeed++;

{
	uint32_t x;
	static const uint32_t rands[4] =
		{4215254626u, 1431676280u, 3632405936u, 2096564432u};
	static const uint32_t i4[4] = {123, 456, 789, 987654321ul};
	static const unsigned char buf[] =
		"Random numbers should not be left to chance.\n";

	gjrand_init(&gjr, 42);
	x = gjrand_rand32(&gjr);
	if (x != rands[0])
	{
		fail++;
		printf("init expect %lu got %lu\n",
			(unsigned long)(rands[0]), (unsigned long)x);
	}
	else succeed++;

	gjrand_init64(&gjr, (((uint64_t)123456789ul)<<32)|987654321ul);
	x = gjrand_rand32(&gjr);
	if (x != rands[1])
	{
		fail++;
		printf("init64 expect %lu got %lu\n",
			(unsigned long)(rands[1]), (unsigned long)x);
	}
	else succeed++;

	gjrand_init4(&gjr, i4);
	x = gjrand_rand32(&gjr);
	if (x != rands[2])
	{
		fail++;
		printf("init4 expect %lu got %lu\n",
			(unsigned long)(rands[2]), (unsigned long)x);
	}
	else succeed++;

	gjrand_inits(&gjr, buf, strlen((char *)buf));
	x = gjrand_rand32(&gjr);
	if (x != rands[3])
	{
		fail++;
		printf("inits expect %lu got %lu\n",
			(unsigned long)(rands[3]), (unsigned long)x);
	}
	else succeed++;
}

{
	int x;
	uint32_t u;
#define SZ 40
	static const char xb[SZ] =
	{
		242, 4, 40, 0, 247, 152, 173, 246, 28, 127,
		187, 6, 124, 247, 8, 208, 91, 186, 194, 18,
		55, 43, 148, 13, 102, 249, 38, 1, 93, 205,
		94, 4, 0, 0, 0, 14, 99, 167, 77, 183
	};
	char buf[SZ];

	x = gjrand_statesize();
	if (x!=SZ)
	{
		fail++; skip += 2;
		printf("statesize expect %d got %d\n", SZ, x);
		goto donesave;
	}
	else succeed++;

	gjrand_savestate(&gjr, buf);
	for (x=0; x<SZ; x++) if (buf[x]!=xb[x])
	{
		int j;
		fail++; skip++;
		printf("savestate fails:\n");
		for (j=0; j<SZ; j++)
			printf("%2d %3d %3d\n", j, buf[j]&255, xb[j]&255);
		goto donesave;
	}
	succeed++;

	gjr.a += 12345;

	x = gjrand_restorestate(&gjr, buf);
	if (x!=0)
	{
		fail++; printf("restorestate fails (checksum)\n");
		goto donesave;
	}
	u = gjrand_rand32(&gjr);
	if (u!=3159020158ul)
	{
		fail++;
		printf("restorestate expect %lu got %lu\n",
			3159020158ul, (unsigned long)u);
	}
	else succeed++;

#undef SZ
}
	donesave: ;

{
	static const uint32_t s[3] = {937169276u, 3277836887u, 74333722u};
	static const uint32_t v[5] =
{966482948u, 3055874193u, 2147320621u, 1409842213u, 3867457785u};
	static const uint32_t m[5] =
		{847107313u, 488433957u, 54696407u, 849686253u, 916714364u};
	static const uint64_t s64[2] =
{ (((uint64_t)0xfaa67678)<<32)|0x36a7820e ,
		(((uint64_t)0x280b83f1)<<32)|0x26c7480b};
	static const uint64_t v64[3] =
	{
		(((uint64_t)0xa29e75f6)<<32)|0xa09347b7,
		(((uint64_t)0xdb8a5477)<<32)|0x904f8e0d,
		(((uint64_t)0xa428776a)<<32)|0x00881307
	};
	static const unsigned char b[11] =
		{115, 201, 144, 9, 130, 54, 86, 248, 158, 224, 151};

	int j, k;
	uint32_t x, y[5];
	uint64_t z, t[3];
	unsigned char c[11];

	x = gjrand_rand(&gjr);
	if (x!=s[0])
	{
		fail++;
		printf("rand expect %lu got %lu\n",
			(unsigned long)s[0], (unsigned long)x);
	}
	else succeed++;

	x = gjrand_rand32(&gjr);
	if (x!=s[1])
	{
		fail++;
		printf("rand32 expect %lu got %lu\n",
			(unsigned long)s[1], (unsigned long)x);
	}

	x = gjrand_rand32mod(&gjr, 123456789ul);
	if (x!=s[2])
	{
		fail++;
		printf("rand32mod expect %lu got %lu\n",
			(unsigned long)s[2], (unsigned long)x);
	}
	else succeed++;

	gjrand_rand32v(&gjr, 5, y);
	for (j=0; j<5; j++) if (y[j]!=v[j])
	{
		fail++;
		printf("rand32v [%d] expect %lu got %lu\n",
			j, (unsigned long)v[j], (unsigned long)y[j]);
		goto done32v;
	}
	succeed++;
	done32v: ;

	gjrand_rand32modv(&gjr, 987654321ul, 5, y);
	for (j=0; j<5; j++) if (y[j]!=m[j])
	{
		fail++;
		printf("rand32modv [%d] expect %lu got %lu\n",
			j, (unsigned long)m[j], (unsigned long)y[j]);
		goto donemodv;
	}
	succeed++;
	donemodv: ;

	gjrand_randbytes(&gjr, 11, c);
	for (j=0; j<11; j++) if (c[j]!=b[j])
	{
		fail++;
		printf("randbytes:\n");
		for (k=0; k<11; k++)
			printf("%2d expect %3u got %3u\n", k, b[k], c[k]);
		goto doneb;
	}
	succeed++;
	doneb: ;

	z = gjrand_rand64(&gjr);
	if (z!=s64[0])
	{
		fail++;
		printf("rand64 expect %lx %8.8lx got %lx %8.8lx\n",
			(unsigned long)(s64[0]>>32),
			(unsigned long)(s64[0]&0xffffffff),
			(unsigned long)(z>>32), (unsigned long)(z&0xffffffff));
	}
	else succeed++;

	z = gjrand_rand64mod(&gjr, (((uint64_t)987654321)<<32)|123456789);
	if (z!=s64[1])
	{
		fail++;
		printf("rand64mod expect %lx %8.8lx got %lx %8.8lx\n",
			(unsigned long)(s64[1]>>32),
			(unsigned long)(s64[1]&0xffffffff),
			(unsigned long)(z>>32), (unsigned long)(z&0xffffffff));
	}
	else succeed++;

	gjrand_rand64v(&gjr, 3, t);
	for (j=0; j<3; j++) if (t[j]!=v64[j])
	{
		fail++;
		printf("rand64v [%d] expect %lx %8.8lx got %lx %8.8lx\n", j,
			(unsigned long)(v64[j]>>32),
			(unsigned long)(v64[j]&0xffffffff),
			(unsigned long)(t[j]>>32),
			(unsigned long)(t[j]&0xffffffff));
		goto done64v;
	}
	succeed++;
	done64v: ;
}

{
	struct gjrand_shufstate st;
	int a[5], j, k;

	j = gjrand_coins(&gjr, 500);
	if (j!=237)
	{
		fail++;
		printf("coins expect 237 got %d\n", j);
	}
	else succeed++;

	j = gjrand_dice(&gjr, 6, 3);
	if (j!=13)
	{
		fail++;
		printf("dice expect 13 got %d\n", j);
	}
	else succeed++;

	gjrand_shuffle(&gjr, 5, a);
	j = a[0]; j = a[1]+8*j; j = a[2]+8*j; j = a[3]+8*j; j = a[4]+8*j;
	if (j!=032104)
	{
		fail++;
		printf("shuffle expect 32104 got %o\n", j);
	}
	else succeed++;

	gjrand_shuffleprep(&gjr, 100000000, &st);
	for (k=0; k<1000000; k++) j = (int)(gjrand_shuffle1(&st));
	if (j!=82396504)
	{
		fail++;
		printf("shuffle1 expect 82396504 got %d\n", j);
	}
	else succeed++;

	j = gjrand_hyperg(&gjr, 7, 5, 8);
	if (j!=4)
	{
		fail++;
		printf("hyperg expect 4 got %d\n", j);
	}
	else succeed++;
}

	printf("\nsucceed = %d ; skip = %d ; fail = %d\n", succeed, skip, fail);
	if (fail>0)
	{printf("\nYou've got some failures in the Known Answer Tests.\n"
"gjrand is supposed to produce repeatable results for many of its functions,\n"
"across a wide range of platforms. This failure suggests this was not\n"
"achieved properly.\n"
"There are several possible reasons:\n"
"Using a different library version to the one this test is for (see above).\n"
"You messed with the library source.\n"
"C compiler bug (try again with less optimise?)\n"
"Portability bugs in gjrand.\n"
"If you think it's the last one, i'd like to hear about it on gjrand forums\n"
"on SourceForge. Give details of your CPU, OS and compiler. Also say which\n"
"of the tests failed. And the gjrand version number.\n"
);
	printf("\nsucceed = %d ; skip = %d ; fail = %d\n", succeed, skip, fail);
	}

	return fail>0;
}
