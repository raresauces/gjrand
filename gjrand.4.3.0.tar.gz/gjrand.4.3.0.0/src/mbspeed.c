/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

double
gjrand_mb_speed(struct gjrand *s)
	{return sqrt(gjrand_inte_ge1gamma(s, 1.5, 0.66666666666666666667));}
