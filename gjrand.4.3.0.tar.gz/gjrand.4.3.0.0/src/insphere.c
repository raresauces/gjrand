/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>

#include "gjrand.h"
#include "inte.h"

void
gjrand_insphere(struct gjrand *s, int n, double *a)
{
	double d;

	if (n<=5) {gjrand_inte_smsphere(s, n, a, 0.0, 0); return;}
	d=gjrand_drand(s);
	d=pow(d, 1.0/n);
	gjrand_inte_lgsphere(s, n, a, d);
}
