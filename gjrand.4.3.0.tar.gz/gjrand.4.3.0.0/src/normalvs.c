/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

#define MULT (1017.0/1024.0)

GJRAND_STATIC void
gjrand_inte_normalvs(struct gjrand *g, int n, double *v)
{
	uint64_t a, b, c, d;
	double r, s, t, u;
	uint64_t ir, is, it, iu;
	int j;

	if (n<=0) return;

	GJRAND_INTE_LOADSTATE(g, a, b, c, d);

	if ((n&1)!=0)
	{
		GJRAND_INTE_CRANK(a, b, c, d); ir = a; is = b;
		j = 8; r = s = 0.0;
		goto start1;
		do
		{
			ir >>= 8; is >>= 8;
			r *= MULT; s *= MULT;
			start1:
			r += gjrand_inte_normal_app[ir&255];
			s += gjrand_inte_normal_app[is&255];
			j--;
		} while (j);

		*v++ = (r + s*(MULT*MULT*MULT*MULT*MULT*MULT*MULT*MULT))
			* GJRAND_INTE_NORM_ADJ;
	}

	n >>= 1;

	while (n)
	{
		GJRAND_INTE_CRANK(a, b, c, d); ir = a; it = b;
		GJRAND_INTE_CRANK(a, b, c, d); iu = a; is = b;
		j = 8; r = s = t = u = 0;
		goto start2;
		do
		{
			ir >>= 8; is >>= 8; it >>= 8; iu >>= 8;
			r *= MULT; s *= MULT; t *= MULT; u *= MULT;
			start2:
			r += gjrand_inte_normal_app[ir&255];
			s += gjrand_inte_normal_app[is&255];
			t += gjrand_inte_normal_app[it&255];
			u += gjrand_inte_normal_app[iu&255];
			j--;
		} while (j);

		*v = (r + s*(MULT*MULT*MULT*MULT*MULT*MULT*MULT*MULT))
			* GJRAND_INTE_NORM_ADJ;
		v[1] = (t + u*(MULT*MULT*MULT*MULT*MULT*MULT*MULT*MULT))
			* GJRAND_INTE_NORM_ADJ;
		v += 2;
		n--;
	}

	GJRAND_INTE_STORESTATE(g, a, b, c, d);
}
