/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <math.h>
#include "nonstd.h"

/* x to the power n. n guaranteed to be small strictly positive. */
static double
powdi(double x, int n)
{
	double r=1.0;
	do {if ((n&1)!=0) r *= x; x *= x; n >>= 1;} while (n);
	return r;
}

static int
smallmean(struct gjrand *state, double p, int n)
{
	double px, phi, sam, tiny=S48, t, rathi, q;
	int x, hi;

	sam = gjrand_drand(state);
	t = p*n;
	if (sam+t < 1.0) return 0;
	q = 1.0-p;
	px = powdi(q, n); x = 0;
	sam -= px;
	if (sam <= 0.0) return x;
	hi = x; phi = px;
	rathi = p/q;

	while (1)
	{
		phi *= n-hi;
		hi++;
		if (hi >= n) return n;
		phi *= rathi;
		phi /= hi;
		sam -= phi;
		if (phi < tiny) break;
		if (sam <= 0.0) break;
	}

	return hi;
}

#define SMALLBUF 96

/* A linear time algorithm that mostly avoids floating point. */
/* NB if we get here prob <= 0.5 */
static int
smallbc(struct gjrand *s, double prob, int n)
{
	uint32_t b[SMALLBUF], t;
	int r, i;

	prob *= (65536.0*65536.0);
	t = prob;
	prob -= t;
	prob *= (65536.0*65536.0);
	gjrand_rand32v(s, n+1, b);
	if (b[n]<prob) t++;
	if (t==0) return 0;
	r = 0; i = 0;
	if ((n&1)!=0) {n--; r = (b[n]<t);}
	while (n>0) {n -= 2; i += (b[n+1]<t); r += (b[n]<t);}

	return r+i;
}

static int
biased_coins_2(struct gjrand *s, double p, int n)
{
	if (n <= 0) return n;
	if (p <= 0.0) {if (p < 0.0) return -1; return 0;}
	if (n<SMALLBUF && p>(1.0/16.0)) return smallbc(s, p, n);
	if (n*p<20.0) return smallmean(s, p, n);
	return gjrand_inte_binomial(s, p, (double)n);
}

int
gjrand_biased_coins(struct gjrand *s, double prob, int n)
{
	if (prob <= 0.5) return biased_coins_2(s, prob, n);
	return n-biased_coins_2(s, 1.0-prob, n);
}

#undef SMALLBUF
