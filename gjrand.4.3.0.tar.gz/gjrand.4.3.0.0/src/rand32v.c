/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_rand32v(struct gjrand *s, int n, uint32_t *v)
{
	uint64_t a, b, c, d;
	int j;

	if (n<=0) return;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	j = n>>1;
	while (j)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		v[0] = (uint32_t)a; v[1] = (uint32_t)(a>>32); v+=2; j--;
	}
	if (n&1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		v[0] = (uint32_t)a;
	}

	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
