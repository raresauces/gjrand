/* Part of gjrand random number library version 4.3.0.0 or later. */
/* Copyright (C) 2004-2019 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

const int gjrand_version_number[4]={4,3,0,0};

const char gjrand_version_string[]=
"gjrand library 4.3.0.0\n"
"Written by G. Jones.\n"
"\n"
"Copyright (C) 2004-2019 G. Jones.\n"
"This is free software released under the Gnu General Public License,\n"
"Version 2 or 3. You should have received a copy of the GPL v2 or v3 with\n"
"this software. If not, contact your supplier, or visit the www.fsf.org web\n"
"site.\n"
"There is NO warranty; not even for MERCHANTABILITY or\n"
"FITNESS FOR A PARTICULAR PURPOSE.\n";

GJRAND_STATIC void
gjrand_inte_mixstate(struct gjrand *s)
{
	int j;
	uint64_t a, b, c, d;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	for (j=14; j!=0; j--) GJRAND_INTE_CRANK(a, b, c, d);
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
