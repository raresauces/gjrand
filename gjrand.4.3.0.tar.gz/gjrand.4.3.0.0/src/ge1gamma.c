/* Part of gjrand random number library version 4.0.2.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

/* This method, new in 3.3.0, is closely based on code from gsl-1.9 . */
/* I did hack it a bit, so don't blame them for my ugliness. */
/* Note: contrary to the comment below, the correct copyright date */
/* for gamma.c in gsl-1.9 appears to be 1996 to 2007. */

/* Their copyright: */

/* randist/gamma.c
 *
 * Copyright (C) 1996, 1997, 1998, 1999, 2000 James Theiler, Brian Gough
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/* New version based on Marsaglia and Tsang, "A Simple Method for
 * generating gamma variables", ACM Transactions on Mathematical
 * Software, Vol 26, No 3 (2000), p363-372.
 *
 * Implemented by J.D.Lamb@btinternet.com, minor modifications for GSL
 * by Brian Gough
 */

/* gamma distribution with the restriction shape>=1 . */
GJRAND_STATIC double
gjrand_inte_ge1gamma(struct gjrand *g, double shape, double scale)
{
	double x, v, u;
	double d = shape - 1.0/3.0;
	double c = (1.0/3.0) / sqrt (d);

	while (1)
	{
		do {x = gjrand_normal(g); v = 1.0 + c*x;} while (v <= 0);

		u = gjrand_drand(g);
		x *= x;
		v = v*v*v;

		if (u < 1 - 0.0331 * x * x) break;

		if (log(u) < 0.5 * x + d * (1 - v + log(v))) break;
	}

	return scale * d * v;
}
