/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

#define MULT (1017.0/1024.0)

double
gjrand_exponential(struct gjrand *g)
{
	uint64_t a, b, ir, is;

	{
		uint64_t c, d;

		GJRAND_INTE_LOADSTATE(g, a, b, c, d);
		GJRAND_INTE_CRANK(a, b, c, d); ir = a; is = b;
		GJRAND_INTE_CRANK(a, b, c, d);
		GJRAND_INTE_STORESTATE(g, a, b, c, d);
	}

	{
		double r=0.0, s=0.0, t=0.0, u=0.0;
		unsigned j = 8;

		goto start;
		do
		{
			ir >>= 8; is >>= 8; a >>= 8; b >>= 8;
			r *= MULT; s *= MULT; t *= MULT; u *= MULT;
			start:
			r += gjrand_inte_normal_app[ir&255];
			s += gjrand_inte_normal_app[is&255];
			t += gjrand_inte_normal_app[a&255];
			u += gjrand_inte_normal_app[b&255];
			j--;
		} while (j);

		r += s*(MULT*MULT*MULT*MULT*MULT*MULT*MULT*MULT);
		t += u*(MULT*MULT*MULT*MULT*MULT*MULT*MULT*MULT);
		r *= r; t *= t;

		return (r+t) * (GJRAND_INTE_NORM_ADJ*GJRAND_INTE_NORM_ADJ*0.5);
	}
}
