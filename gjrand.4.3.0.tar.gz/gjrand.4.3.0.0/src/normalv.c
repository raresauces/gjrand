/* Part of gjrand random number library version 4.2.1.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <string.h>

#include "gjrand.h"
#include "inte.h"

/* High speed method for large vectors of normal variates, partly based */
/* on the ideas of Christopher Stewart Wallace as in FastNorm etc. */

static void
startnorm(struct gjrand *g, double *v)
{
	double a, b, c, d, t;
	uint64_t w, x, y, z;
	uint32_t w0, w1;
	int j=16;

	GJRAND_INTE_LOADSTATE(g, w, x, y, z);

	do
	{
		GJRAND_INTE_CRANK(w, x, y, z);
		w0 = (uint32_t)w;
		w1 = (uint32_t)(w>>32);

		v+=8;

		a = gjrand_inte_normal_app[w0&255];
		b = gjrand_inte_normal_app[w1&255];
		c = gjrand_inte_normal_app[(w0>>8)&255];
		d = gjrand_inte_normal_app[(w1>>8)&255];
		t = ((a+b)+(c+d))*0.5;
		a -= t; b -= t; c = t-c; d = t-d;
		v[-8] = a; v[-7] = b; v[-6] = c; v[-5] = d;

		a = gjrand_inte_normal_app[(w0>>16)&255];
		b = gjrand_inte_normal_app[(w1>>16)&255];
		c = gjrand_inte_normal_app[(w0>>24)];
		d = gjrand_inte_normal_app[(w1>>24)];
		t = ((a+b)+(c+d))*0.5;
		a -= t; b -= t; c = t-c; d = t-d;
		v[-4] = a; v[-3] = b; v[-2] = c; v[-1] = d;
		j--;
	} while (j);

	GJRAND_INTE_STORESTATE(g, w, x, y, z);
}

#ifndef GJRAND_VECTOR
#if defined(__GNUC__) && (__GNUC__>=4)
#define GJRAND_VECTOR 1
#else
#define GJRAND_VECTOR 0
#endif
#endif

#if GJRAND_VECTOR
/* This version uses gcc vector extensions. Might not work on */
/* other compilers. No advantage unless the hardware has the right */
/* kind of vector instructions. */

#define GJRAND_ALIGN __attribute__ ((aligned (16)))
typedef double v2d __attribute__ ((vector_size (16)));

static void
impnorm(const v2d *bin, v2d *bout)
{
	static const v2d half={0.5, 0.5};
	v2d t, a, b, c, d;
	int j=16;

	do
	{
		a = bin[0]; b = bin[16]; c = bin[32]; d = bin[48];
		t = ((a+b)+(c+d)) * half;
		bout += 4;
		a -= t; b -= t; c = t-c; d = t-d;
		bin++;
		bout[-4] = a; bout[-3] = b; bout[-2] = c; bout[-1] = d;
		j--;
	} while (j);
}

#else /* not  GJRAND_VECTOR */
/* This version ought to do the same as the vector version */
/* but in standard C. */

#define GJRAND_ALIGN
typedef double v2d;

static void
impnorm(const double *bin, double *bout)
{
	double t0, t1, a0, a1, b0, b1, c0, c1, d0, d1;
	int j=16;

	do
	{
		a0 = bin[0]; a1 = bin[1]; b0 = bin[32]; b1 = bin[33];
		c0 = bin[64]; c1 = bin[65]; d0 = bin[96]; d1 = bin[97];
		t0 = ((a0+b0)+(c0+d0))*0.5; t1 = ((a1+b1)+(c1+d1))*0.5;
		bout += 8;
		a0 -= t0; a1 -= t1; b0 -= t0; b1 -= t1;
		c0 = t0-c0; c1 = t1-c1; d0 = t0-d0; d1 = t1-d1;
		bin += 2;
		bout[-8] = a0; bout[-7] = a1; bout[-6] = b0; bout[-5] = b1;
		bout[-4] = c0; bout[-3] = c1; bout[-2] = d0; bout[-1] = d1;
		j--;
	} while (j);
}

#endif /* GJRAND_VECTOR */

static void
gjrand_inte_normalvb(struct gjrand *g, int n, double *v)
{
	double b[128] GJRAND_ALIGN, t[128] GJRAND_ALIGN, *p GJRAND_ALIGN;

	p = v;
#if GJRAND_VECTOR
	if (((uintptr_t)v)&15) p = t;
#endif

	while (n>0)
	{
		if (n<128) p = t;
		startnorm(g, p);
		impnorm((const v2d *)p, (v2d *)b);
		impnorm((const v2d *)b, (v2d *)p);
		if (p==t) memcpy(v, p, n*sizeof(double));
		else p += 128;
		v += 128; n -= 128;
	}
}

#undef GJRAND_ALIGN
#undef GJRAND_VECTOR

void
gjrand_normalv(struct gjrand *s, int n, double *v)
{
	if (n<=24) gjrand_inte_normalvs(s, n, v);
	else gjrand_inte_normalvb(s, n, v);
}
