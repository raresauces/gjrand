#ifndef _GJRAND_NONSTD_H

#define _GJRAND_NONSTD_H 1

/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* Stuff that wasn't in C89, but is quite widely available. */
/* This gets included in a couple of files in this directory */
/* that might need it. (It appears to be harmless even if you don't need it. */
/* Some tests might need it too, but that's for you to fix :-) */

/* Probably you should #include <math.h> before you do this one, */
/* in case you have some of these but not others. */

double log1p(const double);
double expm1(const double);
double erfc(const double);

#ifndef M_SQRT1_2
#define M_SQRT1_2 0.7071067811865475244
#endif

#ifndef M_PI
#define M_PI 3.141592653589793238
#endif

#ifndef M_LN2
#define M_LN2 0.6931471805599453094
#endif

#endif /* _GJRAND_NONSTD_H */
