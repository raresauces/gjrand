/* Part of gjrand random number library version 4.0.2.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include <string.h>

void
gjrand_sample(struct gjrand *state, int size, unsigned n, const void *src,
		unsigned k, void *a)
{
	uint32_t mb[32];
	const char *c1;
	char *a1;
	unsigned j;
	int i;

	if (k==0 || n==0) return;

	/* The next line is supposed to detect the special cases where */
	/* size is 1, 2, 4, or 8 ; */
	/* and if both src and a are aligned on a size boundary. */
	if (((((int)(intptr_t)src) | ((int)(intptr_t)a) | size | (~7))
		& (size-1))
		== 0)
	{
		if (size==4) gjrand_sample4(state,
			n, (const int32_t *)src, k, (int32_t *)a);
		else if (size==8) gjrand_sample8(state,
			n, (const int64_t *)src, k, (int64_t *)a);
		else if (size==2) gjrand_sample2(state,
			n, (const int16_t *)src, k, (int16_t *)a);
		else /* (size==1) */ gjrand_sample1(state,
			n, (const char *)src, k, (char *)a);
		return;
	}

	if (size<=0) return;

	a1 = (char *)a; c1 = (const char *)src;
	do
	{
		j = k; if (j>32) j = 32;
		gjrand_rand32modv(state, (uint32_t)n, j, mb);
		for (i=(int)j-1; i>=0; i--)
			{memcpy(a1, c1+mb[i]*size, size); a1 += size;}
		k -= j;
	} while (k>0);
}
