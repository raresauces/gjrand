/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

double
gjrand_t(struct gjrand *s, int f)
{
	double ch;

	if (f<=0) return 0.0;
	ch = gjrand_chisquared(s, f) + S126;
	return sqrt(f/ch) * gjrand_normal(s);
}
