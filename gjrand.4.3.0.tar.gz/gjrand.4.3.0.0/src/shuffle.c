/* Part of gjrand random number library version 3.4.1.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include "config.h"

void
gjrand_shuffle(struct gjrand *s, int n, int *v)
{
	int j;

	if (n<=0) return;
	j = n-1; do {v[j] = j; j--;} while (j>=0);

#if GJRAND_SIZEOFINT==2
	gjrand_shuffled2(s, n, v);
#elif GJRAND_SIZEOFINT==4
	gjrand_shuffled4(s, n, v);
#elif GJRAND_SIZEOFINT==8
	gjrand_shuffled8(s, n, v);
#else
	gjrand_shuffledata(s, n, sizeof(int), v);
#endif
}
