/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"

void
gjrand_sample4(struct gjrand *state, unsigned n, const int32_t *src,
		unsigned k, int32_t *a)
{
	uint32_t mb[32];
	unsigned j;
	int i;

	while (k>0)
	{
		j = k; if (j>32) j = 32;
		gjrand_rand32modv(state, (uint32_t)n, j, mb);
		for (i=0; i<(int)j; i++) a[i] = src[mb[i]];
		a += j; k -= j;
	}
}
