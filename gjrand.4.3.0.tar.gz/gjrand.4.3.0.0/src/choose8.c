/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"

void
gjrand_choose8(struct gjrand *state, unsigned n, const int64_t *src,
	unsigned k, int64_t *a)
{
	struct gjrand_shufstate sh;
	unsigned j;

	if (k>n) return;
	gjrand_shuffleprep(state, (int64_t)n, &sh);
	for (j=0; j<k; j++) a[j] = src[gjrand_shuffle1(&sh)];
}
