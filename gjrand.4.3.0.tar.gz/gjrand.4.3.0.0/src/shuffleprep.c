/* Part of gjrand random number library version 4.0.3.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_shuffleprep(struct gjrand *state, int64_t n,
		struct gjrand_shufstate *shuf)
{
	uint64_t m;
	unsigned sh;
	int j;

	if (n<=0) {shuf->mask = 0; return;}

	shuf->mod = n;
	shuf->state = 0;
	m = 1; sh = 1;
	do {m <<= 1; sh++;} while (m<(uint64_t)n);
	m--;
	shuf->mask = m; shuf->sh = (int)(sh>>1);

	shuf->inc = gjrand_rand64(state) & m;
	if (n>32) n = 32;
	j = (int)n-1;
	do {shuf->smallshuf[j] = (unsigned char)j; j--;} while (j>=0);
	gjrand_shuffled1(state, (int)n, (char *)(shuf->smallshuf));
}

#define BIGCON (0x569a76a5UL)
#define SHUFITER 5

int64_t
gjrand_shuffle1(struct gjrand_shufstate *shuf)
{
	if (shuf->mod <= 32)
	{
		int j = (int)(shuf->state);
		if (j>=shuf->mod) return -((int64_t)1);
		shuf->state = j+1;
		return (int64_t)(shuf->smallshuf[j]);
	}
	else
	{
		unsigned char *tab = shuf->smallshuf;
		uint64_t s, mask = shuf->mask;
		unsigned shift = (unsigned)(shuf->sh);
		int j;

		do
		{
			if (shuf->mask == 0) return -((int64_t)1);

			s = (shuf->state+BIGCON) & mask;
			if (s==0) shuf->mask = 0;
			shuf->state = s;

			s ^= shuf->inc;

			j = SHUFITER;
			do
			{
				s ^= s>>shift;
				s = (s&(~31)) | tab[s&31];
				s ^= s>>2;
				s *= BIGCON;
				s += tab[j];
				s &= mask;
				j--;
			} while (j!=0);

		} while (s >= (uint64_t)(shuf->mod));

		return (int64_t)s;
	}
}
