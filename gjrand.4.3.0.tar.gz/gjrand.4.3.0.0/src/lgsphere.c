/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

/* Seen in HAKMEM. */

GJRAND_STATIC void
gjrand_inte_lgsphere(struct gjrand *s, int n, double *a, double r)
{
	double u;
	int j;

	if (n<=0) return;

	do /* usually once only. Protects against large roundoff. */
	{
		gjrand_normalv(s, n, a);
		u = 0.0;
		j = n-1; do {double t=a[j]; u+=t*t; j--;} while (j>=0);
	} while (u<S31);

	u = r/sqrt(u);
	j = n-1; do {a[j] *= u; j--;} while (j>=0);
}
