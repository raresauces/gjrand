/* Part of gjrand random number library version 4.0.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

#if defined(__GNUC__) && __GNUC__>=4
#define EXP(x, c) __builtin_expect(x, c)
#else
#define EXP(x, c) (x)
#endif

void
gjrand_shuffled4(struct gjrand *s, unsigned n, int32_t *v)
{
	uint64_t a, b, c, d, w=0;
	int32_t j;
	unsigned nm1=n-1, t, mask, newmask, shift;
	int k;

	if (nm1==0) return;

	mask = 1; shift = 0;
	do {mask <<= 1; shift++;} while (mask<=nm1);
	mask--; newmask = mask>>1;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	while (1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		w = a; k = 64;
		do
		{
			t = w&mask; w >>= shift; k -= shift;
			if (EXP((t<=nm1), 1))
			{
				j= *v; *v=v[t]; v[t]=j;
				if (EXP((--nm1==0), 0)) goto ret;
				v++;
				if (EXP((newmask>=nm1), 0))
					{shift--; mask=newmask; newmask >>= 1;}
			}
		} while (EXP((k>=(int)shift), 1));
	}

	ret:
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
