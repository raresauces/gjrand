/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_rand64v(struct gjrand *s, int n, uint64_t *v)
{
	uint64_t a, b, c, d;

	if (n<=0) return;
	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	do
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		*v = a; v++; n--;
	} while (n);
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
