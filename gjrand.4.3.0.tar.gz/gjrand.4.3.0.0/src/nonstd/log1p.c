#include <math.h>
#include "nonstd.h"

/* This is straight out of the GSL version 1.9 code, */
/* copyright Gerard Jungman and Brian Gough 1996-2000. */
/* Released by them under GPL version 2 or later. */
/* Emergency copy only. Copy up to the directory above if your */
/* compiler vendor didn't supply a better one. */
double
log1p (const double x)
{
	volatile double y, z;
	y = 1 + x; z = y - 1;
	return log(y) - (z-x)/y ;  /* cancels errors with IEEE arithmetic */
}
