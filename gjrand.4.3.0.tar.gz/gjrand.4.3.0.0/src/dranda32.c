/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_drand_a32(struct gjrand *s, int n, double *v)
{
	uint64_t a, b, c, d;
	int j;

	if (n<=0) return;
	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	j = n>>1;
	while (j)
	{
		double f, g;
		GJRAND_INTE_CRANK(a, b, c, d);
		f = (int32_t)a; g = (int32_t)(a>>32);
		f += 0.5; g += 0.5;
		f *= S31; g *= S31;
		v[0] = f; v[1] = g;
		v += 2; j--;
	}
	if ((n&1)!=0)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		*v = (((int32_t)a)+0.5)*S31;
	}
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
