/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <math.h>

double
gjrand_pareto(struct gjrand *s, double al, double m)
	{return exp(gjrand_exponential(s)/al) * m;}
