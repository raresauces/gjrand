/* Part of gjrand random number library version 4.1.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <math.h>

static const double simple[32]={
0.00000000000000000000,
0.00000000000000000000,
0.69314718055994530943,
1.79175946922805500090,
3.17805383034794561975,
4.78749174278204599415,
6.57925121201010099526,
8.52516136106541429999,
10.60460290274525022892,
12.80182748008146961100,
15.10441257307551529525,
17.50230784587388583977,
19.98721449566188614923,
22.55216385312342288610,
25.19122118273868150135,
27.89927138384089156699,
30.67186010608067280384,
33.50507345013688888583,
36.39544520803305357667,
39.33988418719949403668,
42.33561646075348502971,
45.38013889847690802634,
48.47118135183522388137,
51.60667556776437357030,
54.78472939811231919027,
58.00360522298051994122,
61.26170176100200198688,
64.55753862700633106259,
67.88974313718153498487,
71.25703896716800900962,
74.65823634883016438751,
78.09222355331531063155
};

/* inaccurate for small x. */
static double
stirling(int x)
{
	double y=x, z=1.0/y, s=z*z, r;

#if 0
	r = (-1.0/1680.0)*s;
#else
	r = 0.0;
#endif

	r += (1.0/1260.0);
	r *= s; 
	r -= (1.0/360.0);
	r *= s;
	r += (1.0/12.0);
	r *= z;
	r += 0.9189385332046727418;
	r -= y;
	r += log(y)*(y+0.5);
	return r;
}

/* return log of factorial. Believed accurate to about 1 part in 1e15. */
/* this is not quite IEEE double precision. */
/* To get full double precision, you probably need to enlarge simple[] */
/* to about 80 elements, or enable one more term in stirling() by */
/* changing #if 0 to #if 1 . This is not needed for gjrand purposes. */

GJRAND_STATIC double
gjrand_inte_logfac(int x)
	{if (x<32) return simple[x]; return stirling(x);}
