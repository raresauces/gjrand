/* Part of gjrand random number library version 4.0.2.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

static void
memswap(char *d, char *s, int n)
{
	if (!((((intptr_t)d)|((intptr_t)s))&7)) /* both 8-byte aligned */
	{
		uint64_t t;

		while ((n-=8)>=0)
		{
			t = *((uint64_t *)d);
			*((uint64_t *)d) = *((uint64_t *)s); d += 8;
			*((uint64_t *)s) = t; s += 8;
		}
		n += 8;
	}

	while ((--n)>=0) {char t = *d; *d++ = *s; *s++ = t;}
}

void
gjrand_shuffledata(struct gjrand *s, int size, unsigned n, void *v)
{
	uint64_t a, b, c, d, w;
	char *vp;
	unsigned nm1, t, mask, newmask, shift;
	int k;

	/* The next line is supposed to detect the special cases where */
	/* size is 1, 2, 4, or 8 ; */
	/* and if v is aligned on a size boundary. */
	if (((((int)(intptr_t)v) | size | (~7)) & (size-1)) == 0)
	{
		if (size==4) gjrand_shuffled4(s, n, (int32_t *)v);
		else if (size==8) gjrand_shuffled8(s, n, (int64_t *)v);
		else if (size==2) gjrand_shuffled2(s, n, (int16_t *)v);
		else /* (size==1) */ gjrand_shuffled1(s, n, (char *)v);
		return;
	}

	if (size<=0) return;
	nm1 = n-1;
	if (nm1<=0) return;
	w = 0;

	mask = 1; shift = 0;
	do {mask <<= 1; shift++;} while (mask<=nm1);
	mask--; newmask = mask>>1;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	vp = (char *)v;
	while (1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		w = a; k = 64;
		do
		{
			t = w&mask; w >>= shift; k -= shift;
			if (t<=nm1)
			{
				memswap(vp, vp+t*size, size);
				nm1--;
				if (nm1<=0) goto ret;
				vp += size;
				if (newmask>=nm1)
				{
					shift--; mask = newmask;
					newmask >>= 1;
				}
			}
		} while (k>=(int)shift);
	}

	ret:
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
