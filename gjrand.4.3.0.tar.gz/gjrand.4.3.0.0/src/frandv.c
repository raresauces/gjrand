/* Part of gjrand random number library version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

#define Q ((float)(1.0/4.0))

void
gjrand_frandv(struct gjrand *s, int n, float *v)
{
	float f, g;
	uint64_t a, b, c, d;
	int j;

	if (n<=0) return;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	j = n>>1;
	while (j)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		f = (int32_t)(((uint32_t)a)>>8); g = (int32_t)(a>>40);
		f += Q; g += Q;
		f *= SF24; g *= SF24;
		v[0] = f; v[1] = g;
		v += 2; j--;
	}

	if (n&1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		v[0] = (((float)(((uint32_t)a)>>8)) + Q) * SF24;
	}

	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
