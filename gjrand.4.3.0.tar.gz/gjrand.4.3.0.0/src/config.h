#ifndef _GJRAND_CFG_H
#define _GJRAND_CFG_H 1
/* Contents of this file are made by the mkconf program */
/* and are usually overwritten when running ./compile */
#define GJRAND_SIZEOFINT (4)
#define GJRAND_LITTLE_ENDIAN (1)
#endif /* _GJRAND_CFG_H */
