/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

#define MULT (1017.0/1024.0)

double
gjrand_normal(struct gjrand *g)
{
	uint64_t a, b;

	{
		uint64_t c, d;

		GJRAND_INTE_LOADSTATE(g, a, b, c, d);
		GJRAND_INTE_CRANK(a, b, c, d);
		GJRAND_INTE_STORESTATE(g, a, b, c, d);
	}

	{
		double r=0, s=0;
		unsigned j=8;

		goto start;
		do
		{
			a >>= 8; b >>= 8;
			r *= MULT; s *= MULT;
			start:
			r += gjrand_inte_normal_app[a&255];
			s += gjrand_inte_normal_app[b&255];
			j--;
		} while (j);

		r += s*(MULT*MULT*MULT*MULT*MULT*MULT*MULT*MULT);

		return r * GJRAND_INTE_NORM_ADJ;
	}
}
