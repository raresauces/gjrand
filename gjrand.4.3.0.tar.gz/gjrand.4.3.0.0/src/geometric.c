/* Part of gjrand random number library version 4.2.2.0 or later. */
/* Copyright (C) 2004-2016 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <math.h>
#include <limits.h>
#include "nonstd.h"

int
gjrand_geometric (struct gjrand *s, double p)
{
	double t, u;
	uint64_t a, b, c, d;
	int r;

	if (p<=0.0) return INT_MAX;
	if (p>=1.0) return 1;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	GJRAND_INTE_CRANK(a, b, c, d);
	GJRAND_INTE_STORESTATE(s, a, b, c, d);

	t = ((double)((int64_t)(a>>1)) + S63) * S63;

	if (p+t>0.125 && p>3.0/64)
	{
		p = 1.0-p;
		u = 1.0;
		r = 0;
		do {u *= p; r++;} while (u>t);
		return r;
	}

	u = log(t) / log1p(-p);
	r = (int)u + 1;

	return r;
}
