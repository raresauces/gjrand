/* Part of gjrand random number library version 4.0.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include "config.h"

void
gjrand_randbytes(struct gjrand *s, int n, unsigned char *p)
{
	uint64_t a, b, c, d;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

#if defined(GJRAND_LITTLE_ENDIAN) && GJRAND_LITTLE_ENDIAN>0
	if ((((uintptr_t)p)&7)==0)
		while (n>=8)
		{
			GJRAND_INTE_CRANK(a, b, c, d);
			*((uint64_t *)p) = a;
			p += 8; n -= 8;
		}
	else
#endif

	while (n>=8)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		p[0] = a; p[1] = a>>8; p[2] = a>>16; p[3] = a>>24;
		p[4] = a>>32; p[5] = a>>40; p[6] = a>>48; p[7] = a>>56;
		p += 8; n -= 8;
	}

	if (n>0)
	{
		uint64_t t;
		GJRAND_INTE_CRANK(a, b, c, d);
		t = a;
		do {*p = t; t >>= 8; p++; n--;} while (n);
	}

	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
