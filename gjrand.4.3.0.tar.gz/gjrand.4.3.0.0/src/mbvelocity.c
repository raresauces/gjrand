/* Part of gjrand random number library version 4.0.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_mb_velocity(struct gjrand *s, double v[3])
{
	gjrand_inte_normalvs(s, 3, v);
	v[0] *= GJRAND_INTE_SQRT1_3;
	v[1] *= GJRAND_INTE_SQRT1_3;
	v[2] *= GJRAND_INTE_SQRT1_3;
}
