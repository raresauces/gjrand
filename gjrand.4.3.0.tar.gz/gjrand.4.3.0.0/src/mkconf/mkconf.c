/* Miscellaneous stuff for gjrand random numbers version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdio.h>
#include "../my_int_types.h"

int
main()
{
	uint64_t j = (((uint64_t)0x01020304)<<32) | 0x05060708;
	char *p = (char *)(&j);
	int e=0;

	if (p[0]==8 && p[1]==7 && p[2]==6 && p[3]==5
		&& p[4]==4 && p[5]==3 && p[6]==2 && p[7]==1) e++;

	printf(
"#ifndef _GJRAND_CFG_H\n"
"#define _GJRAND_CFG_H 1\n"
"/* Contents of this file are made by the mkconf program */\n"
"/* and are usually overwritten when running ./compile */\n"
"#define GJRAND_SIZEOFINT (%d)\n"
"#define GJRAND_LITTLE_ENDIAN (%d)\n"
"#endif /* _GJRAND_CFG_H */\n" , (int)(sizeof(int)), e );
	return 0;
}
