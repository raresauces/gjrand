/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"

int
gjrand_polya(struct gjrand *s, double p, double n)
	{return gjrand_poisson(s, gjrand_gamma(s, n, (1.0-p)/p));}
