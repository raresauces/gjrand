/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_drand_array(struct gjrand *s, int n, double *v)
{
	uint64_t a, b, c, d;

	if (n<=0) return;
	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	do
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		*v = ((double)((int64_t)a))*S63;
		v++; n--;
	} while (n);
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
