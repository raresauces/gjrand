/* Part of gjrand random number library version 4.3.0.0 or later. */
/* Copyright (C) 2004-2019 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <time.h>

/* This uses various tricks in an attempt to get highly variable */
/* information out of the operating system. */

/* Also, we use the address of the struct you're seeding. This should */
/* ensure different seeding for different threads, among other things. */
/* (You really shouldn't be using the same struct gjrand in two different */
/* threads.) */

/* In addition, nonce is used, which should give a different seed for */
/* subsequent calls from within the same process, even if the time hasn't */
/* changed. Ideally, nonce should go in thread-local storage. */
/* If your compiler doesn't support __thread , try doing whatever */
/* your compiler does support instead. For some Microsoft compilers */
/* replacing __thread with __declspec(thread) is rumoured to work. */

/* If all else fails just delete the __thread keyword. */
/* This was used in older versions of gjrand. It's definitely ok */
/* for single threaded programs, and almost certainly ok for multithreaded. */
/* The main problem with it is that people who really care about thread */
/* safety will waste time worrying about it. */

void
gjrand_initrand(struct gjrand *s)
{
	static __thread uint32_t nonce=0;

	const uint64_t mul=0x55aa5a5b;
	uint64_t t=clock()*mul + time(0);
	char x;

	if (sizeof(void *) > 4) {t *= mul; t += (uint64_t)(&x);}

	s->a = t;
	s->b = (uint64_t)s;
	if (sizeof(void *) <= 4) s->b |= ((uint64_t)(&x)) << 32;

	nonce += 1397u;
	s->c = (((uint64_t)nonce)<<32)|4000001u;
	s->d = 0;

	gjrand_inte_mixstate(s);
}
