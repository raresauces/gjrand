#ifndef _GJRAND_TYPES_H

#define _GJRAND_TYPES_H 1

#include <stdint.h>

/* This header file is expected to provide typedefs for: */

/* int16_t : must be signed integer of exactly 16 bits. */
/* int32_t : must be signed integer of exactly 32 bits. */
/* uint32_t : must be unsigned integer of exactly 32 bits. */
/* int64_t : must be signed integer of exactly 64 bits. */
/* uint64_t : must be unsigned integer of exactly 64 bits. */
/* intptr_t : signed integer the same size as void * . */
/* uintptr_t : unsigned integer the same size as void * . */

/* If you don't have <stdint.h> , you could try <inttypes.h> */
/* or <sys/int_types.h>, or maybe other system headers. */
/* As a last resort write your own typedefs in this file. */

#endif /* _GJRAND_TYPES_H */
