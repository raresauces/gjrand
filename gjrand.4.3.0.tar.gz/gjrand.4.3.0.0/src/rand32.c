/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

unsigned long
gjrand_rand32(struct gjrand *s)
{
	uint64_t a, b, c, d;
	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	GJRAND_INTE_CRANK(a, b, c, d);
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
	return (unsigned long)(uint32_t)a;
}
