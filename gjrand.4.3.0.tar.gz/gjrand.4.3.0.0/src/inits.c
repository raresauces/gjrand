/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <string.h>

#define L64(b) gjrand_inte_l64(b)

void
gjrand_inits(struct gjrand *s, const unsigned char *buf, size_t len)
{
	unsigned char b2[24];
	size_t l=len;

	s->a = s->b = s->c = s->d = 0;
	while (l>=24)
	{
		s->a ^= L64(buf); s->b ^= L64(buf+8); s->c ^= L64(buf+16);
		l -= 24; buf += 24;
		gjrand_inte_mixstate(s);
	}
	if (l>0)
	{
		memset(b2, 0, 24);
		memcpy(b2, buf, l);
		s->a ^= L64(b2); s->b ^= L64(b2+8); s->c ^= L64(b2+16);
		gjrand_inte_mixstate(s);
	}
	s->a ^= len; s->c = 3000001ul;
	gjrand_inte_mixstate(s);
}

#undef L64
