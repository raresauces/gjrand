/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <math.h>

/* 30 is the largest possible for SMALLBUF, otherwise rewrite count128 */
/* to avoid overflow. */
#define SMALLBUF 30
#define SMALLC (SMALLBUF*64)

#define MASK1 ((((uint64_t)0x55555555)<<32)|0x55555555)
#define MASK2 ((((uint64_t)0x33333333)<<32)|0x33333333)
#define MASK4 ((((uint64_t)0xf0f0f0f)<<32)|0xf0f0f0f)
#define MASK8 ((((uint64_t)0xff00ff)<<32)|0xff00ff)
#define MASK16 (0xffff)

static int
count128(uint64_t *b, int n)
{
	uint64_t x, y, t=0;
	int r;

	do
	{
		x = b[0]; y = b[1];
		x = ((x>>1)&MASK1) + (x&MASK1);
		y = ((y>>1)&MASK1) + (y&MASK1);
		x = ((x>>2)&MASK2) + (x&MASK2);
		y = ((y>>2)&MASK2) + (y&MASK2);
		t += ((x>>4)&MASK4) + (x&MASK4);
		t += ((y>>4)&MASK4) + (y&MASK4);

		b += 2; n--;
	} while (n);

	t = ((t>>8)&MASK8) + (t&MASK8);

	r = ((uint32_t)(t>>32)) + ((uint32_t)t);
	r = ((r>>16)&MASK16) + (r&MASK16);

	return r;
}

static int
smallc(struct gjrand *s, int n)
{
	uint64_t b[SMALLBUF];
	int j;

	j = (n+63)>>6;
	gjrand_rand64v(s, j, b);
	if ((j&1)!=0) b[j] = 0;
	b[0] &= (((int64_t)1)<<63) >> ((n-1)&63);

	return count128(b, (j+1)>>1);
}

int
gjrand_coins(struct gjrand *s, int n)
{
	if (n<=64)
	{
		uint64_t t;
		uint32_t r;
		if (n<=0) return 0;
		t = gjrand_rand64(s);
		t &= (((int64_t)1)<<63) >> (n-1);
		t = ((t>>1)&MASK1) + (t&MASK1);
		t = ((t>>2)&MASK2) + (t&MASK2);
		t = ((t>>4)&MASK4) + (t&MASK4);
		t = ((t>>8)&MASK8) + (t&MASK8);
		r = ((uint32_t)(t>>32)) + ((uint32_t)t);
		return (int)(((r>>16)&MASK16) + (r&MASK16));
	}
	if (n<=SMALLC) return smallc(s, n);
	return gjrand_inte_binomial(s, 0.5, (double)n);
}

#undef MASK1
#undef MASK2
#undef MASK4
#undef MASK8
#undef MASK16

#undef SMALLBUF
#undef SMALLC
