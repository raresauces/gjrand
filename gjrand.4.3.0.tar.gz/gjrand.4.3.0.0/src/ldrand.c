/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

long double
gjrand_ldrand(struct gjrand *s)
{
	uint64_t a, b, c, d;
	long double r;
	int j;

	r = 0.25;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	for (j=2; j; j--)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		r += (long double)(int64_t)(a>>1); r *= S63;
	}

	GJRAND_INTE_STORESTATE(s, a, b, c, d);

	if (r==(long double)1.0) r -= S48;

	return r;
}
