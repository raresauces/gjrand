#ifndef _GJRAND_INTE_H

#define _GJRAND_INTE_H 1

/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* Contains stuff used internally in the library. */
/* Application programmers keep out. */

#ifndef GJRAND_STATIC
#define GJRAND_STATIC
#endif
#ifndef GJRAND_STATICE
#define GJRAND_STATICE 1
#endif

#pragma GCC visibility push(hidden)

#define GJRAND_INTE_LOADSTATE(s, w, x, y, z) \
	( (x) = (s)->b, (y) = (s)->c, (w) = (s)->a, (z) = (s)->d )

#define GJRAND_INTE_STORESTATE(s, w, x, y, z) \
	( (s)->a = (w), (s)->b = (x), (s)->c = (y), (s)->d = (z) )

#define GJRAND_INTE_ROT(x, r) ( (x) = ( ((x)<<r) | ((x)>>(64-r)) ) )

#define GJRAND_INTE_CRANK(a, b, c, d) \
{ \
	(b) += (c); GJRAND_INTE_ROT((a), 32); (c) ^= (b); \
	(d) += 0x55aa96a5; \
	(a) += (b); GJRAND_INTE_ROT((c), 23); (b) ^= (a); \
	(a) += (c); GJRAND_INTE_ROT((b), 19); (c) += (a); \
	(b) += (d); \
}

/* sqrt(1.0/3.0) probably accurate to about 20 places */
/* (more than enough for double) */
#define GJRAND_INTE_SQRT1_3 (0.57735026918962576450651)

GJRAND_STATIC uint64_t gjrand_inte_l64(const unsigned char b[8]);
GJRAND_STATIC void gjrand_inte_s64(const uint64_t i, unsigned char *b);

GJRAND_STATIC void gjrand_inte_hash32_8(const unsigned char in[32], unsigned char out[8]);

GJRAND_STATIC void gjrand_inte_lgsphere(struct gjrand *s, int d, double *r, double x);
GJRAND_STATIC void gjrand_inte_smsphere(struct gjrand *s, int d, double *r, double x, int doscale);

GJRAND_STATIC double gjrand_inte_logfac(int x);

GJRAND_STATIC double gjrand_inte_ge1gamma(struct gjrand *g, double shape, double scale);

GJRAND_STATIC void gjrand_inte_mixstate(struct gjrand *state);

#define GJRAND_INTE_NORM_ADJ (0.262935051139072517)
#if GJRAND_STATICE
extern const double gjrand_inte_normal_app[256];
#endif
GJRAND_STATIC void gjrand_inte_normalvs(struct gjrand *s, int n, double *v);

GJRAND_STATIC int gjrand_inte_binomial(struct gjrand *rng, double p, double n);

#define SF24 ((float)(1.0/(1l<<24)))

#define S31 (1.0/(((uint64_t)1)<<31))
#define S48 (1.0/(((uint64_t)1)<<48))
#define S53 (1.0/(((uint64_t)1)<<53))
#define S63 (S31*S31*0.5)
#define S126 (S63*S63)

#pragma GCC visibility pop

#endif /* _GJRAND_INTE_H */
