/* Part of gjrand random number library version 4.0.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_shuffled8(struct gjrand *s, unsigned n, int64_t *v)
{
	uint64_t a, b, c, d, w=0;
	int64_t j;
	unsigned nm1=n-1, t, mask, newmask, shift;
	int k;

	if (nm1<=0) return;

	mask = 1; shift = 0;
	do {mask <<= 1; shift++;} while (mask<=nm1);
	mask--; newmask = mask>>1;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	while (1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		w = a; k = 64;
		do
		{
			t = w&mask; w >>= shift; k -= shift;
			if (t<=nm1)
			{
				j= *v; *v=v[t]; v[t]=j;
				if (--nm1<=0) goto ret;
				v++;
				if (newmask>=nm1)
					{shift--; mask=newmask; newmask >>= 1;}
			}
		} while (k>=(int)shift);
	}

	ret:
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
