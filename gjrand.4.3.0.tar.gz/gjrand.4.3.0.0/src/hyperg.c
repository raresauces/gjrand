/* Part of gjrand random number library version 4.2.2.0 or later. */
/* Copyright (C) 2004-2016 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

static int
hgs(struct gjrand *g, int n1, int n2, int s)
{
	uint64_t a, b, c, d, bn1=((uint64_t)n1)<<32;
	uint32_t ns=((uint32_t)n1)+n2;
	int r=0;

	GJRAND_INTE_LOADSTATE(g, a, b, c, d);

	while (1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		if ((a&0xffffffffUL)*ns < bn1)
			{r++; bn1 -= ((uint64_t)1)<<32; if (bn1==0) break;}
		ns--;
		s--; if (s==0) break;
		if ((a>>32)*ns < bn1)
			{r++; bn1 -= ((uint64_t)1)<<32; if (bn1==0) break;}
		ns--;
		s--; if (s==0) break;
	}

	GJRAND_INTE_STORESTATE(g, a, b, c, d);

	return r;
}

static int
hgb(struct gjrand *g, int n1, int n2, int s)
{
	int m=((int64_t)s)*n1/((int64_t)n1+n2);
	int ch, cl, dh, dl, min, max;
	double ph, pl, u=gjrand_drand(g), tiny;

	ch = m; dh = s-ch;

#define lf(x) gjrand_inte_logfac(x)
	ph = exp( lf(n1) - lf(ch) - lf(n1-ch)
		+ lf(n2) - lf(dh) - lf(n2-dh)
		- lf(n1+n2) + lf(s) + lf(n1+n2-s) );
#undef lf

	u -= ph;
	if (u<=0) return ch;

	min = s-n2; if (min<0) min = 0;
	max = n1; if (max>s) max = s;

	tiny = ph * S48;
	pl = ph; cl = ch; dl = dh;

	while (1)
	{
		cl--; if (cl<min) goto hionly;
		dl++;
		pl *= ((cl+1)*((double)(n2-dl+1))) / ((n1-cl)*(double)dl);
		u -= pl;
		if (u<=0) return cl;
		if (pl<tiny) goto hionly;

		ch++;
		if (ch<=max) /* HERE should always be true? */
		{
			ph *= dh;
			dh--;
			ph *= n1-ch+1;
			ph /= ((double)ch)*(n2-dh);
			u -= ph;
			if (u<=0) goto retch;
		}
	}

	hionly:
	while (1)
	{
		ch++; if (ch>=max) return max;

		ph *= dh;
		dh--;
		ph *= n1-ch+1;
		ph /= ((double)ch)*(n2-dh);
		u -= ph;
		if (u<=0) break;
		if (ph<tiny) break;
	}

	retch:
	return ch;
}

static int
hg2(struct gjrand *g, int n1, int n2, int s)
{
	if (s<=0) return 0;
	if (n1<=0) return 0;
	if (s<256) return hgs(g, n1, n2, s);
	return hgb(g, n1, n2, s);
}

static int
hg1(struct gjrand *g, int n1, int n2, int s)
{
	if (n2<n1) return s-hg2(g, n2, n1, s);
	return hg2(g, n1, n2, s);
}

int
gjrand_hyperg(struct gjrand *g, int n1, int n2, int s)
{
	if (s-n1>n2-s) return n1-hg1(g, n1, n2, n1+n2-s);
	return hg1(g, n1, n2, s);
}
