/* Part of gjrand random number library version 4.3.0.0 or later. */
/* Copyright (C) 2004-2016 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

double
gjrand_drand_strange(struct gjrand *s)
{
	double r=0.0;
	uint64_t a, b, c, d;
	int j;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	for (j=3; j; j--)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		r += (a>>1); r *= S63;
	}
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
	return r;
}
