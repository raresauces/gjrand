/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* This file is derived from one in GSL version 1.9 (randist/binomial_tpe.c) */
/* which in turn is derived from an academic paper and public domain code */
/* by Kachitvichyanukul and Schmeiser. I (G. Jones) have done more hacks */
/* to make it work with gjrand, for matters of style, and in the hope of */
/* small performance improvements. I have retained the copyright notice and */
/* some of the comments from the GSL version. */


/* randist/binomial_tpe.c
 *
 * Copyright (C) 1996-2003 James Theiler, Brian Gough
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

/* The binomial distribution has the form,

   f(x) =  n!/(x!(n-x)!) * p^x (1-p)^(n-x) for integer 0 <= x <= n
	=  0				   otherwise

   This implementation follows the public domain ranlib function
   "ignbin", the bulk of which is the BTPE (Binomial Triangle
   Parallelogram Exponential) algorithm introduced in
   Kachitvichyanukul and Schmeiser[1].  It has been translated to use
   modern C coding standards.

   [ ... ]

   But for larger problems, the BTPE algorithm takes the form of two
   functions b(x) and t(x) -- "bottom" and "top" -- for which b(x) <
   f(x)/f(M) < t(x), with M = floor(n*p+p).  b(x) defines a triangular
   region, and t(x) includes a parallelogram and two tails.  Details
   (including a nice drawing) are in the paper.

   [1] Kachitvichyanukul, V. and Schmeiser, B. W.  Binomial Random
   Variate Generation.  Communications of the ACM, 31, 2 (February,
   1988) 216.

   [ ... ]

   This implementation by James Theiler, April 2003, after obtaining
   permission -- and some good advice -- from Drs. Kachitvichyanukul
   and Schmeiser to use their code as a starting point, and then doing
   a little bit of tweaking.

   Additional polishing for GSL coding standards by Brian Gough.  */

#define FAR_FROM_MEAN 20     /* If ix-n*p is larger than this, then
				use the "squeeze" algorithm.
				Ranlib used 20, and this seems to
				be the best choice on my machine as
				well */

static double
Stirling(double y1)
{
  double y2;

  y1 = 1.0/y1;
  y2 = y1 * y1;

  return
    (13860.0 - (462.0 - (132.0 - (99.0 - 140.0 * y2) * y2) * y2) * y2) * y1
	* (1.0/166320.0);
}

GJRAND_STATIC int
gjrand_inte_binomial(struct gjrand *rng, double p, double n)
{
  double s, np, q, logv;
  int ix;			/* return value */

  /* GJ : removed flipping code (already done elsewhere). */

  q = 1.0-p;
  s = p / q;
  np = n * p;

  /* GJ : the GSL code had another algorithm called BINV for small mean. */
  /* I have removed it because in gjrand we don't get to this file unless */
  /* the mean is reasonably big. (Something similar to BINV but faster */
  /* is implemented in another file.) */

    {
      /* For n >= SMALL_MEAN, we invoke the BTPE algorithm */

      int k;

      double ffm = np + p;	/* ffm = n*p+p */
      int m = (int) ffm;	/* m = int floor[n*p+p] */
      double fm = m;		/* fm = double m; */
      double xm = fm + 0.5;     /* xm = half integer mean (tip of triangle)  */
      double npq = np * q;      /* npq = n*p*q  */

      /* Compute cumulative area of tri, para, exp tails */

      /* p1: radius of triangle region; since height=1, also: area of region */
      /* p2: p1 + area of parallelogram region */
      /* p3: p2 + area of left tail */
      /* p4: p3 + area of right tail */
      /* pi/p4: probability of i'th area (i=1,2,3,4) */

      /* Note: magic numbers 2.195, 4.6, 0.134, 20.5, 15.3 */
      /* These magic numbers are not adjustable...at least not easily! */

      double p1 = floor (2.195 * sqrt (npq) - 4.6 * q) + 0.5;

      /* xl, xr: left and right edges of triangle */
      double xl = xm - p1;
      double xr = xm + p1;

      /* Parameter of exponential tails */
      /* Left tail:  t(x) = c*exp(-lambda_l*[xl - (x+0.5)]) */
      /* Right tail: t(x) = c*exp(-lambda_r*[(x+0.5) - xr]) */

      double c = 0.134 + 20.5 / (15.3 + fm);
      double p2 = p1 * (1.0 + c + c);

      double al = (ffm - xl) / (ffm - xl * p);
      double lambda_l = al * (1.0 + 0.5 * al);
      double ar = (xr - ffm) / (xr * q);
      double lambda_r = ar * (1.0 + 0.5 * ar);
      double p3 = p2 + c / lambda_l;
      double p4 = p3 + c / lambda_r;

      double var, accept;
      double u, v;		/* random variates */

    TryAgain:

      /* generate random variates, u specifies which region: Tri, Par, Tail */
      u = gjrand_drand(rng) * p4;
      v = gjrand_drand(rng);

      if (u <= p1)
	{
	  /* Triangular region */
	  ix = (int) (xm - p1 * v + u);
	  goto Finish;
	}
      else if (u <= p2)
	{
	  /* Parallelogram region */
	  double x = xl + (u - p1) / c;
	  v = v * c + 1.0 - fabs (x - xm) / p1;
	  if (v > 1.0 || v <= 0.0)
	    goto TryAgain;
	  ix = (int) x;
	}
      else
      {
	logv = log(v);
	if (u <= p3)
	{
	  /* Left tail */
	  ix = (int) (xl + logv / lambda_l);
	  if (ix < 0)
	    goto TryAgain;
	  v *= ((u - p2) * lambda_l);
	}
	else
	{
	  /* Right tail */
	  ix = (int) (xr - logv / lambda_r);
	  if (ix > (double) n)
	    goto TryAgain;
	  v *= ((u - p3) * lambda_r);
	}
      }

      /* At this point, the goal is to test whether v <= f(x)/f(m)
       *
       *  v <= f(x)/f(m) = (m!(n-m)! / (x!(n-x)!)) * (p/q)^{x-m}
       *
       */

#if 0 && defined(DIRECT)

	/* Need to provide LNFACT if you enable this. */

      /* Here is a direct test using logarithms.  It is a little
       * slower than the various "squeezing" computations below, but
       * if things are working, it should give exactly the same answer
       * (given the same random number seed).  */

      var = log(v);

      accept =
	LNFACT (m) + LNFACT (n - m) - LNFACT (ix) - LNFACT (n - ix)
	+ (ix - m) * log (p / q);

#else /* SQUEEZE METHOD */

      /* More efficient determination of whether v < f(x)/f(M) */

      k = ix - m;
      if (k<0) k = -k;

      if (k <= FAR_FROM_MEAN)
      {
	  /*
	   * If ix near m (ie, |ix-m|<FAR_FROM_MEAN), then do
	   * explicit evaluation using recursion relation for f(x)
	   */
	  double g = (n + 1) * s;
	  double f = 1.0;

	  var = v;

	  if (m < ix)
	  {
	      int i;
	      for (i = m + 1; i <= ix; i++) f *= (g / i - s);
	  }
	  else if (m > ix)
	  {
	      int i;
	      for (i = ix + 1; i <= m; i++) f *= (g / i - s);
	      f = 1.0/f;
	  }

	  accept = f;
      }
      else
	{
	  /* If ix is far from the mean m: k=ABS(ix-m) large */

	  double dk = k;

	  var = log(v);

	  if (dk < npq * 0.5 - 1)
	  {
	      /* "Squeeze" using upper and lower bounds on
	       * log(f(x)) The squeeze condition was derived
	       * under the condition k < npq/2-1 */
	      double rnpq = 1.0/npq;
	      double amaxp
= dk * rnpq * ((dk * (dk * (1.0/3.0) + 0.625) + (1.0 / 6.0)) * rnpq + 0.5);
	      double ynorm = rnpq * dk * dk * -0.5;
	      if (var < ynorm - amaxp)
		  goto Finish;
	      if (var > ynorm + amaxp)
		  goto TryAgain;
	  }

	  /* Now, again: do the test log(v) vs. log f(x)/f(M) */

#ifndef USE_EXACT
#define USE_EXACT 0
#endif

#if 0 && USE_EXACT
	/* Provide your own LNFACT if you want to try this. */

	  accept = LNFACT (m) + LNFACT (n - m)
	    - LNFACT (ix) - LNFACT (n - ix) + (ix - m) * log (p / q);

#else /* USE STIRLING */
	  /* The "#define Stirling" above corresponds to the first five
	   * terms in asymptoic formula for
	   * log Gamma (y) - (y-0.5)log(y) + y - 0.5 log(2*pi);
	   * See Abramowitz and Stegun, eq 6.1.40
	   */

	  /* Note below: two Stirling's are added, and two are
	   * subtracted.  In both K+S, and in the ranlib
	   * implementation, all four are added.  I (jt) believe that
	   * is a mistake -- this has been confirmed by personal
	   * correspondence w/ Dr. Kachitvichyanukul.  Note, however,
	   * the corrections are so small, that I couldn't find an
	   * example where it made a difference that could be
	   * observed, let alone tested.  In fact, define'ing Stirling
	   * to be zero gave identical results!!  In practice, alv is
	   * O(1), ranging 0 to -10 or so, while the Stirling
	   * correction is typically O(10^{-5}) ...setting the
	   * correction to zero gives about a 2% performance boost;
	   * might as well keep it just to be pendantic.  */

	  {
	    double x1 = ix + 1.0;
	    double w1 = n - ix + 1.0;
	    double f1 = fm + 1.0;
	    double z1 = n + 1.0 - fm;

	    accept = xm * log (f1 / x1) + (n - m + 0.5) * log (z1 / w1)
	      + (ix - m) * log (w1 * p / (x1 * q))
	      + Stirling (f1) + Stirling (z1) - Stirling (x1) - Stirling (w1);
	  }
#endif
#endif
	}


      if (var <= accept) goto Finish;
      else goto TryAgain;
    }

#undef USE_EXACT

Finish:

  return ix;
}
