/* Part of gjrand random number library version 4.0.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

double
gjrand_chisquared(struct gjrand *s, int f)
{
	if (f<=0) return 0;
	if (f==1) {double x = gjrand_normal(s); return x*x;}
	if (f==2) return gjrand_exponential(s)*2;
	return gjrand_inte_ge1gamma(s, f*0.5, 2.0);
}
