/* Part of gjrand random number library version 4.3.0.0 or later. */
/* Copyright (C) 2004-2016 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

/* This method, new in 3.3.0, is closely based on code from gsl-1.9 . */
/* I did hack it a bit, so don't blame them for my ugliness. */
/* Note: contrary to the comment below, the correct copyright date */
/* for gamma.c in gsl-1.9 appears to be 1996 to 2007. */

/* Their copyright: */

/* randist/gamma.c
 *
 * Copyright (C) 1996, 1997, 1998, 1999, 2000 James Theiler, Brian Gough
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/* New version based on Marsaglia and Tsang, "A Simple Method for
 * generating gamma variables", ACM Transactions on Mathematical
 * Software, Vol 26, No 3 (2000), p363-372.
 *
 * Implemented by J.D.Lamb@btinternet.com, minor modifications for GSL
 * by Brian Gough
 */

double
gjrand_gamma(struct gjrand *g, double shape, double scale)
{
	if (shape<=0.0) return 0.0;
	if (shape<1.0)
	{
		double u=gjrand_exponential(g);
		u = exp(-u/shape);
		scale *= u;
		shape += 1.0;
	}
	return gjrand_inte_ge1gamma(g, shape, scale);
}
