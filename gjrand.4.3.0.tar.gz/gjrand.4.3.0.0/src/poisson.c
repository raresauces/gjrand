/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <math.h>

int
gjrand_poisson(struct gjrand *state, double t)
{
	int x, lo, hi, from0=0;
	double px, plo, phi, p, tiny, rt;

	if (t>=32.0) return gjrand_inte_binomial(state, t*S48, 1.0/S48);
	x = (int)t;

	p = gjrand_drand(state);

	if (x <= 10)
	{
		if (p+t < 1.0) return 0;
		x = 0; px = -t; from0++;
	}
	else px = log(t)*x - gjrand_inte_logfac(x) - t;

	px = exp(px);
	p -= px;
	if (p <= 0.0) return x;

	tiny = S48;
	hi = x; phi = px;
	if (from0) goto hionly;
	tiny *= px;
	lo = x; plo = px; rt = 1.0/t;

	while (1)
	{
		plo *= lo;
		lo--;
		if (lo < 0) goto hionly;
		plo *= rt;
		p -= plo;
		if (plo<tiny) goto hionly;
		if (p <= 0.0) return lo;

		hi++;
		phi *= t;
		phi /= hi;
		p -= phi;
		if (p <= 0.0) goto rethi;
	}

	hionly:
	while (1)
	{
		hi++;
		phi *= t;
		phi /= hi;
		p -= phi;
		if (phi < tiny) break;
		if (p <= 0.0) break;
	}
	rethi:
	return hi;
}
