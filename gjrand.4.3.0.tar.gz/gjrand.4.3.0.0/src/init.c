/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_init(struct gjrand *s, uint32_t x)
{
	s->a = x; s->b = s->d = 0; s->c = 1000001ul;
	gjrand_inte_mixstate(s);
}
