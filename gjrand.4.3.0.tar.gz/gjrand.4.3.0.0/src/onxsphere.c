/* Part of gjrand random number library version 4.2.2.0 or later. */
/* Copyright (C) 2004-2016 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

static double
xnorm(int n, double *a)
{
	double r= -1.0, t=0.0, t2=0.0, t3=0.0, v, w;
	int j;

	/* Kahan's trick for almost quad precision sum. */
	/* But the multiply is not that good. */
	for (j=n-1; j>=0; j--)
	{
		double d, f, sq;

		d = a[j];
		f = (float)d;
		d -= f;

		sq = f*f; /* The neat thing, at least with ieee754, */
			/* is that this is exact. */
		v = r+sq; /* approximate sum */
		w = v-r; /* what was actually added */
		sq -= w; /* error term that still needs to be added. */
		r = v;
		t += sq;

		t2 += f*d; /* inexact, but so much smaller we don't care */
		t3 += d*d;
	}

	t2 *= 2.0; r += t3; r += t; r += t2;

	return r;
}

void
gjrand_onxsphere(struct gjrand *s, int n, double *a)
{
	double t, u, v;
	int j, k;

	if (n<=0) return;

	if (n==1)
	{	/* this case pointless, but done accurately. */
		t = 1.0;
		if ((gjrand_rand32(s)&1)!=0) t = -t;
		*a = t;
		return;
	}

	if (n<=3) gjrand_inte_smsphere(s, n, a, 1.0, 1);
	else gjrand_inte_lgsphere(s, n, a, 1.0);

	t = xnorm(n, a);

	if (t)
	{
		v = 1.0; k = -1;
		for (j=n-1; j>=0; j--)
		{
		    u = a[j];
		    u *= u; u -= t;
		    if (u<v && u>0.0) {k = j; v = u;}
		}
		if (k>=0)
		{
/* This line could be better for large n */		    if (v>S31) {v = fabs(a[k]); v -= 0.5*t/v;}
		    else v = sqrt(v);
		    if (a[k]<0.0) v = -v;
		    a[k] = v;
		}
	}
}
