#ifndef _GJRAND_H

#define _GJRAND_H 1

/* Part of gjrand random number library version 4.3.0.0 or later. */
/* Copyright (C) 2004-2018 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#ifdef __cplusplus
#define GJRAND_NO_ARGS
extern "C" {

#else /* not __cplusplus */
#define GJRAND_NO_ARGS void

#endif /* __cplusplus */

/* String representing library name, version, copyright, etc. */
extern const char gjrand_version_string[];

/* Numbers representing version. */
/* [0] major version number */
/* [1] minor version number */
/* [2] very minor version number */
/* [3] patch level */
extern const int gjrand_version_number[4];

#include <sys/types.h>

#include "my_int_types.h"

/* Please treat the data fields as private, as they are subject to change */
/* without notice. Do all access to struct gjrand objects with the */
/* function calls provided. */
struct gjrand {uint64_t a, b, c, d;};


/* --- seed the generator --- */

/* In gjrand version 4.* there are 2 ** 192 different starting points */
/* (not all reachable). Each starting point is in a cycle of length at */
/* least 2 ** 64 cranks. Different starting points are sometimes on the same */
/* cycle but if so are at least 2 ** 64 cranks apart. */
/* 8 bytes are available at each crank. */
/* (Each call that generates random data will advance at least one crank, */
/* or more than that if it needs more data.) */
/* gjrand_init() picks from 2 ** 32 different starting points. */
/* gjrand_init64() picks from 2 ** 64 different starting points. */
/* gjrand_init4() picks from 2 ** 128 different starting points. */
/* gjrand_inits() picks from 2 ** 128 different starting points. */
/* gjrand_initrand() (system dependent) different starting points. */
/* where each seeding function is not supposed to have any starting points */
/* in common with the others. */

/* Seed the generator with one number. */
void gjrand_init(struct gjrand *state, uint32_t);

/* Seed the generator with one number. */
void gjrand_init64(struct gjrand *state, uint64_t);

/* Seed the generator with 4 numbers. */
void gjrand_init4(struct gjrand *state, const uint32_t i[4]);

/* Seed the generator with an arbitrary chunk of data of length len bytes */
/* starting at *buf. The data is hashed so slightly differing data should */
/* usually result in very different cycles. The hash is not up */
/* to cryptographic quality, so it should be quite easy to engineer two */
/* different data chunks that result in the same seed. However this is */
/* unlikely to happen by accident. */
void gjrand_inits(struct gjrand *state, const unsigned char *buf, size_t len);

/* Seed the generator with data from the operating system. This should select */
/* a cycle that is not very easy to predict or repeat. However, it */
/* is not sufficiently unpredictable to be used for security related purposes */
/* such as key generation. */
void gjrand_initrand(struct gjrand *state);


/* --- save and restore state ---  */

/* return the size of a byte array needed to store gjrand state. */
int gjrand_statesize(GJRAND_NO_ARGS);

/* save state into buf. The number of bytes to be saved can be */
/* determined using gjrand_statesize. buf must point to a large */
/* enough buffer for that. Note that the bytes are not null terminated */
/* and can contain arbitrary byte values, including nulls */
void gjrand_savestate(const struct gjrand *state, char *buf);

/* restore state from buf. buf should be an array of bytes as obtained */
/* by gjrand_savestate() */
/* Return 0 for success, non-0 (probably -1 ?) for failure. */
/*	failure is most likely due to checksum non-agreement. */
/* state is probably unchanged on failure, best not to use it in that case. */
int gjrand_restorestate(struct gjrand *state, const char *buf);


/* --- generate random numbers: integer uniform --- */

/* update state and return a uniformly distributed 31 bit random integer in */
/* the range [0 .. (2**31) - 1 ] */
long gjrand_rand(struct gjrand *state);

/* update state and return a uniformly distributed 32 bit unsigned */
/* random integer in the range [0 .. (2**32) - 1 ] */
unsigned long gjrand_rand32(struct gjrand *state);

/* update state and write n uniformly distributed 32 bit unsigned */
/* random integers into the buffer starting at *v . v must point */
/* at a large enough memory area for that. */
void gjrand_rand32v(struct gjrand *state, int n, uint32_t *v);

/* update state and return a uniformly distributed 64 bit unsigned */
/* random integer in the range [0 .. (2**64) - 1 ] */
uint64_t gjrand_rand64(struct gjrand *state);

/* update state and write n uniformly distributed 64 bit unsigned */
/* random integers into the buffer starting at *v . v must point */
/* at a large enough memory area for that. */
void gjrand_rand64v(struct gjrand *state, int n, uint64_t *v);

/* update state and return a uniformly distributed random integer */
/* in the range [0 .. m - 1 ]. m may be any number representable */
/* as a 32 bit unsigned. */
uint32_t gjrand_rand32mod(struct gjrand *state, uint32_t m);

/* update state and write n uniformly distributed random integers */
/* in the range [0 .. m - 1 ] into the buffer starting at *v. v must point */
/* at a large enough memory area for that. */
void gjrand_rand32modv(struct gjrand *state, uint32_t m, int n, uint32_t *v);

/* update state and return a uniformly distributed random integer */
/* in the range [0 .. m - 1 ]. m may be any number representable */
/* as a 64 bit unsigned. */
uint64_t gjrand_rand64mod(struct gjrand *state, uint64_t m);

/* update state and write n uniformly distributed random unsigned bytes */
/* in the range [0 .. 255] into buffer starting at *b */
void gjrand_randbytes(struct gjrand *state, int n, unsigned char *b);


/* --- generate random numbers: integer non-uniform --- */

/* As a general note, for distributions that return type "int", */
/* the maximum possible value of int depends on your compiler, */
/* but is very often 2147483647 . For modern compilers, the actual */
/* maximum value should be INT_MAX , defined in <limits.h> . */
/* Starting at version 4.2.2.0 there is a move towards detecting */
/* integer overflow in returns, also more careful checking for valid */
/* arguments. If an argument is outside the allowed bounds, it will */
/* be moved to the nearest bound. If a return value should logically be */
/* greater than INT_MAX, instead INT_MAX will be returned. At this time, */
/* these changes might still be somewhat incomplete or untested. */

/* update state and toss n fair coins. Count how many come up heads, and */
/* return that. for large n time is now approximately constant. */
int gjrand_coins(struct gjrand *state, int n);

/* update state and toss n biased coins. prob is the probability for a coin */
/* to come up heads from one toss. this should be in the range [0.0 .. 1.0] */
/* Count how many come up heads, and return that. */
/* This is the binomial distribution. */
/* for large n time is now approximately constant. */
int gjrand_biased_coins(struct gjrand *state, double prob, int n);

/* update state and throw n fair s sided dice. These dice have sides numbered */
/* from 0 to s-1. Return the total of numbers on top of all dice. time is */
/* proportional to n */
/* Hint: if you want dice numbered 1 to s, use */
/* gjrand_dice(state, s, n) + n */
/* Note: best not to use n*s > 2e9 */
int gjrand_dice(struct gjrand *state, int s, int n);

/* update state. Run independent trials with probability p of success, */
/* repeating until one succeeds. Return the number of trials to get that */
/* first success (including the successful trial, ie, return always >= 1). */
/* Hint: carefully study description of the return value. Different */
/* textbooks give different definitions. */
/* Note: best not to use p < 3e-8 */
int gjrand_geometric(struct gjrand *state, double p);

/* update state. Run independent trials with probability p of success, */
/* repeating until there are n successes. Return the number of trials */
/* that fail before that. (ie, return could be as low as zero.) */
/* Above makes sense for integer n. For non-integer n, there is a sort of */
/* smooth interpolation, using gamma function instead of factorial */
/* to get the distribution. should have 0<p<1 , n>0 . */
/* Variously called Pascal, Pólya, or negative binomial distribution. */
/* Hint: carefully study description of the return value, and all parameters. */
/* Different textbooks give many different definitions. */
/* Note: The definition of return value does seem inconsistent with */
/* the one for gjrand_geometric. */
/* Note : best not to use n*(1-p)/p > 2e9  (even less for small n) */
int gjrand_polya(struct gjrand *state, double p, double n);

/* update state. Put n1 green things and n2 other things into a bag and */
/* mix well. Then remove s randomly chosen things from the bag. Return */
/* the number of removed things that are green. This is called the */
/* "hypergeometric distribution", or "sampling without replacement". */
/* for large s time is proportional to sqrt(s) . */
/* Hint: carefully study description of the parameters. Different */
/* textbooks give different definitions, especially for n2. */
int gjrand_hyperg(struct gjrand *state, int n1, int n2, int s);

/* update state. Events happen on average once per time interval. */
/* However, the timing of each individual event is random and independent */
/* of the timing of other events. Observe the events and return the number */
/* that occur in t time intervals. */
/* Note: t does not have to be a whole number, but return value does. */
/* For large t, time is now approximately constant. */
/* Note : best not to use t > 2e9 */
int gjrand_poisson(struct gjrand *state, double t);

/* --- generate random numbers: shuffles etc. --- */

/* update state. Write the integers 0 to n-1 inclusive in random order */
/* into a[]. Note that a must point to a memory area large enough for that. */
void gjrand_shuffle(struct gjrand *state, int n, int *a);

/* update state. We assume that a is an array with n elements, each of */
/* size size (as obtained eg from sizeof(a[0]) ). We assume the array */
/* is already initialised. Re-order the elements of a randomly. */
void gjrand_shuffledata(struct gjrand *state, int size, unsigned n, void *a);

/* optimised special cases of gjrand_shuffledata for size=1, 2, 4, 8 */
/* respectively where the data is known to be properly aligned. */
/* Hint: don't sweat too much to use these since gjrand_shuffledata */
/* usually calls these functions when appropriate. */
void gjrand_shuffled1(struct gjrand *state, unsigned n, char *a);
void gjrand_shuffled2(struct gjrand *state, unsigned n, int16_t *a);
void gjrand_shuffled4(struct gjrand *state, unsigned n, int32_t *a);
void gjrand_shuffled8(struct gjrand *state, unsigned n, int64_t *a);

/* an alternative shuffling interface based on returning numbers one at a */
/* time. This is based on an idea posted on USENET, i think by Bob Jenkins. */
/* This method allows shuffles too big to be expressed as type int, */
/* and shuffles too big to fit in an array in memory. It also allows a */
/* tolerably efficient way to do a hundred million random 32 bit integers */
/* with no repetitions without wasting space on a hash table. */
/* WARNING: current code is somewhat slow and is of unknown quality. */
/* It may be inferior to gjrand_shuffle(). In any case, for n<=32 */
/* it is actually a wrapper over gjrand_shuffle(). */
/* WARNING: this may make different sequences for the same seed */
/* in a future version if i think of a better method. */
struct gjrand_shufstate
{
	unsigned char smallshuf[32];
	uint64_t mask;
	uint64_t inc;
	uint64_t state;
	int64_t mod;
	int sh;
};

/* Update state. Inits shuf using data from state, ready for a shuffle of */
/* the integers in [ 0 n-1 ]. Note that after this returns, state is not */
/* used by gjrand_shuffle1() and can be deallocated or used for other */
/* purposes. shuf contains all the state needed for gjrand_shuffle1() . */
void gjrand_shuffleprep(struct gjrand *state, int64_t n,
	struct gjrand_shufstate *shuf);

/* Update shuf. */
/* Return a random integer in [ 0 n-1 ] that has not already been returned */
/* by this gjrand_shufstate object. If all possible valid values have already */
/* been returned, return -1. */
int64_t gjrand_shuffle1(struct gjrand_shufstate *shuf);

/* Update state. We assume src is an array of n elements each of size size */
/* bytes. Randomly choose k of those (without replacement, ie, each element */
/* is used at most once) and copy into a, (which must point at a large */
/* enough memory area to take k elements each of size size). These are */
/* written in random order. This only makes sense if k<=n . */
void gjrand_choose(struct gjrand *state, int size, unsigned n, const void *src,
	unsigned k, void *a);

/* optimised special cases of gjrand_choose for size=1, 2, 4, 8 */
/* respectively where the data is known to be properly aligned. */
void gjrand_choose1(struct gjrand *state, unsigned n, const char *src,
	unsigned k, char *a);
void gjrand_choose2(struct gjrand *state, unsigned n, const int16_t *src,
	unsigned k, int16_t *a);
void gjrand_choose4(struct gjrand *state, unsigned n, const int32_t *src,
	unsigned k, int32_t *a);
void gjrand_choose8(struct gjrand *state, unsigned n, const int64_t *src,
	unsigned k, int64_t *a);

/* Update state. We assume src is an array of n elements each of size size */
/* bytes. Randomly sample k of those (with replacement, ie, each element */
/* may be used any number of times) and copy into a, (which must point at a */
/* large enough memory area to take k elements each of size size). These are */
/* written in random order. */
void gjrand_sample(struct gjrand *state, int size, unsigned n, const void *src,
	unsigned k, void *a);

/* optimised special cases of gjrand_sample for size=1, 2, 4, 8 */
/* respectively where the data is known to be properly aligned. */
void gjrand_sample1(struct gjrand *state, unsigned n, const char *src,
	unsigned k, char *a);
void gjrand_sample2(struct gjrand *state, unsigned n, const int16_t *src,
	unsigned k, int16_t *a);
void gjrand_sample4(struct gjrand *state, unsigned n, const int32_t *src,
	unsigned k, int32_t *a);
void gjrand_sample8(struct gjrand *state, unsigned n, const int64_t *src,
	unsigned k, int64_t *a);

/* --- generate random numbers: floating point uniform --- */

/* update state. Return a uniform random number in (0.0 .. 1.0). */
/* number has approx 52 bits absolute. */
double gjrand_drand(struct gjrand *state);

/* update state. Write n uniform random numbers in (0.0 .. 1.0) into v[] . */
/* v must point to a large enough memory area for that. */
void gjrand_drandv(struct gjrand *state, int n, double *v);

/* update state. Write n uniform random numbers in [-1.0 .. 1.0] into a[] . */
/* They have approx 63 bits absolute or 53 bits relative whichever is less. */
/* -1, 0, 1 are all possible results, beware of singularities. */
void gjrand_drand_array(struct gjrand *state, int n, double *a);

/* update state. Write n uniform random numbers in (-1.0 .. 1.0) into a[] . */
/* They have a random sign bit and 31 random fraction bits, */
/* followed by a fixed one bit. */
/* Only use this if your application can tolerate the reduction of bits. */
/* This might be useful for avoiding singularities at the edge of */
/* the range for Monte-Carlo integration etc. */
/* Most gjrand functions (except gjrand_drand_array()) never make a variate */
/* right on the edge, but this one keeps a little further from the edge. */
/* Maybe that simplifies things if you need to rescale. */
void gjrand_drand_a32(struct gjrand *state, int n, double *a);

/* update state. Return a uniform random number in [0.0 .. 1.0]. */
/* This can occasionally return 1, and at least in principle, 0 . */
/* Number has 53 bits relative. Some people on the net think it should work */
/* this way. Actually it's slow, complicated to implement, and might */
/* occasionally cause subtle problems for application programmers, but i */
/* suppose its strange properties might be useful for something. Maybe. */
double gjrand_drand_strange(struct gjrand *state);

/* update state. Write n uniform random numbers in (0.0 .. 1.0) into v[] . */
/* v must point to a large enough memory area for that. */
/* numbers have 24 random bits absolute (followed by zero then one */
/* if there is enough precision to hold them). */
/* (This kind of assumes float is capable of 24 bit precision, as */
/* IEEE single precision is. If float has less precision than that, you */
/* may get less than 24 bits precision and 1.0 might occasionally show up */
/* due to roundoff. Such implementations should be very rare now.) */
void gjrand_frandv(struct gjrand *state, int n, float *v);

/* update state. Return a uniform random number in (0.0 .. 1.0). */
/* Return value has approx 126 bits absolute or whatever long double supports */
/* relative whichever is less. (Both ANSI C standards say long double */
/* has at least as much precision as double. For some compilers long double */
/* is the same as double. For others, it has more precision than double. */
/* Fairly commonly, long double is an IEEE extended precision, */
/* but IEEE extended itself cuts a lot of slack.) */
long double gjrand_ldrand(struct gjrand *state);


/* --- generate random numbers: floating point geometrical --- */

/* update state. Generate a point inside the n-dimensional unit sphere. */
/* (circle for n=2, sphere for n=3, hypersphere for n=4, etc.) */
/* Write the cartesian coordinates for the point into a[] */
void gjrand_insphere(struct gjrand *state, int n, double *a);

/* update state. Generate a point on the surface of the n-dimensional unit */
/* sphere. Write the cartesian coordinates for the point into a[]. Due to */
/* roundoff error, the point will usually not be exactly on the surface, */
/* but it should be very close. */
void gjrand_onsphere(struct gjrand *state, int n, double *a);

/* update state. Generate a point on the surface of the n-dimensional unit */
/* sphere. Write the cartesian coordinates for the point into a[]. Due to */
/* roundoff error, the point will usually not be exactly on the surface, */
/* but it should be very close. This usually gets closer to the surface */
/* of the sphere than the previous one, but only by a few ulp. */
/* Also this one is slower. */
void gjrand_onxsphere(struct gjrand *state, int n, double *a);

/* --- generate random numbers: floating point statistical --- */

/* update state. Return a normally distributed random number with mean 0.0 */
/* standard deviation 1.0 */
/* Also called the Gaussian distribution. */
/* Hint: for mean m and standard deviation sd, use */
/* gjrand_normal(s) * sd + m */
double gjrand_normal(struct gjrand *state);

/* update state. Write n normally distrubuted random numbers with mean 0.0 */
/* standard deviation 1.0 into v[] . */
/* v must point to a large enough memory area for that. */
/* Hint: runs faster if n is a multiple of 128. */
void gjrand_normalv(struct gjrand *state, int n, double *v);

/* update state. Return a T-distributed random number with f degrees */
/* of freedom. f should be >= 1 . (Time is now approx constant for large f.) */
/* This is the distribution associated with the "Student" T-tests. Note that */
/* f is one less than the sample size for some popular tests. This looks like */
/* a normal distribution with longer tails on both sides. Smaller f makes */
/* bigger tails. */
double gjrand_t(struct gjrand *state, int f);

/* update state. Return a chi-squared distributed random number with f */
/* degrees of freedom. f should be >= 1 . */
/* (time is now approximately constant for large f.) */
double gjrand_chisquared(struct gjrand *state, int f);

/* update state. Events happen on average once per time interval. */
/* However, the timing of each individual event is random and independent */
/* of the timing of other events. This is the same situation as the Poisson */
/* distribution. Here we ask a different question: how many time intervals */
/* do we wait for the next event? This is the Erlang distribution special */
/* cased to shape=1 and rate=1 (or scale=1). */
/* Return is a real number anywhere in (0 +inf). */
double gjrand_exponential(struct gjrand *state);

/* update state. As above, but events average once every scale time intervals */
/* and how long do we wait for shape events to happen. */
/* This is the Erlang distribution. */
/* Hint: carefully study description of the parameters. Some textbooks */
/* give scale and shape in reverse order. Some give rate = 1/scale instead */
/* of scale. */
double gjrand_erlang(struct gjrand *state, int shape, double scale);

/* update state. return a gamma distributed random variate. Gamma is a */
/* generalisation of Erlang, where shape does not have to be a whole number. */
/* Hint: as for Erlang. */
double gjrand_gamma(struct gjrand *state, double shape, double scale);

/* update state. Return a Weibull distributed random variate with scale and */
/* shape. scale and shape should be positive. Note this is the same as the */
/* Frechet distribution except shape is negated. Note scale=1 and shape=1 is */
/* the exponential distribution above, but otherwise this is not the same */
/* as the gamma distribution. */
/* Hint: as for Erlang. */
double gjrand_weibull(struct gjrand *state, double shape, double scale);

/* update state. Return a Pareto distributed random variate where m is the */
/* minimum value and a is the shape parameter or "Pareto index". m and a */
/* should be positive. For the classic Pareto 80-20 rule, a should be */
/* somewhere near 1.15 ? */
/* Occasionally called the Bradford distribution. */
double gjrand_pareto(struct gjrand *state, double a, double m);

/* --- generate random numbers: floating point physical --- */

/* The next four are associated with the analysis of ideal gases by Maxwell */
/* and Boltzmann. The idea is that the gas is modelled as a lot of identical */
/* molecules in a 3-D box behaving classically and colliding with each other */
/* and the box in a totally elastic way. */
/* In all these, the RMS speed of molecules in the gas is assumed to be 1. */

/* Update state and return a speed from the distribution */
/* of molecules in the gas. */
double gjrand_mb_speed(struct gjrand *state);

/* Update state and write a velocity (as a 3-vector) from the distribution */
/* of molecules in the gas into v[]. */
void gjrand_mb_velocity(struct gjrand *state, double v[3]);

/* Update state and return a speed from the distribution */
/* of gas molecules hitting a wall of the box. */
/* (This is a somewhat different distribution to the one throughout the gas */
/* because a fast molecule is more likely to hit the box than a slow one.) */
double gjrand_mbt_speed(struct gjrand *state);

/* Update state and write a velocity (as a 3-vector) from the distribution */
/* of gas molecules hitting a wall of the box, into v[]. */
/* v[0] is the velocity component perpendicular to the wall. It will always */
/* be positive. */
void gjrand_mbt_velocity(struct gjrand *state, double v[3]);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _GJRAND_H */
