/* Part of gjrand random number library version 4.0.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_onsphere(struct gjrand *s, int n, double *a)
{
	if (n<=3) gjrand_inte_smsphere(s, n, a, 1.0, 1);
	else gjrand_inte_lgsphere(s, n, a, 1.0);
}
