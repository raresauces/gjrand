/* Part of gjrand random number library version 4.3.0.0 or later. */
/* Copyright (C) 2004-2018 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include <limits.h>

int
gjrand_dice(struct gjrand *s, int sides, int n)
{
	uint64_t a, b, c, d, w=0;
	unsigned mask, shift;
	int r=0, k, t;

	if (n<=0 || sides<=1) return 0;

	mask = 1; shift = 0;
	do {mask <<= 1; shift++;} while (mask<(unsigned)sides);
	mask--;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	while (1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		w = a; k = 64-shift;
		do
		{
			t = w&mask; w >>= shift;
			if (t<sides)
			{
				r += t; if (r<0) goto overflow;
				n--; if (n==0) goto ret;
			}
			k -= shift;
		} while (k>=0);
	}

	overflow:
	r = INT_MAX;
	ret:
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
	return r;
}
