/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

uint64_t
gjrand_rand64mod(struct gjrand *s, uint64_t mod)
{
	uint64_t a, b, c, d;
	uint64_t big;

	if (mod<=1) return 0;
#define GJR_HUGE ((uint64_t)(-((int64_t)1)))
	big = GJR_HUGE - (GJR_HUGE%mod);
	GJRAND_INTE_LOADSTATE(s, a, b, c, d);
	do {GJRAND_INTE_CRANK(a, b, c, d);} while (a>=big);
	GJRAND_INTE_STORESTATE(s, a, b, c, d);

	return a%mod;
}
