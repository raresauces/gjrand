/* Part of gjrand random number library version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <math.h>
#include "gjrand.h"
#include "inte.h"

GJRAND_STATIC void
gjrand_inte_smsphere(struct gjrand *s, int n, double *a, double r, int doscale)
{
	double u;
	int j;

	if (n<=0) return;

	do
	{
		gjrand_drand_array(s, n, a);
		u = 0.0;
		j=n-1; do {double t=a[j]; u+=t*t; j--;} while (j>=0);
	} while (u>=1.0 || (doscale!=0 && u<S31));

	if (!doscale) return;

	u = r/sqrt(u);
	j = n-1; do {a[j] *= u; j--;} while (j>=0);
}
