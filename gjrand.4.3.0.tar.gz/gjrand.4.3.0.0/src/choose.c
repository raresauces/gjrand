/* Part of gjrand random number library version 4.0.2.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include <string.h>

void
gjrand_choose(struct gjrand *state, int size, unsigned n, const void *src,
		unsigned k, void *a)
{
	struct gjrand_shufstate sh;
	const char *s1;
	char *a1;

	if (k==0 || k>n) return;

	/* The next line is supposed to detect the special cases where */
	/* size is 1, 2, 4, or 8 ; */
	/* and if both src and a are aligned on a size boundary. */
	if (((((int)(intptr_t)src) | ((int)(intptr_t)a) | size | (~7))
		& (size-1))
		== 0)
	{
	    if (size==4)
	        gjrand_choose4(state, n, (const int32_t *)src, k, (int32_t *)a);
	    else if (size==8)
	        gjrand_choose8(state, n, (const int64_t *)src, k, (int64_t *)a);
	    else if (size==2)
	        gjrand_choose2(state, n, (const int16_t *)src, k, (int16_t *)a);
	    else /* (size==1) */
	        gjrand_choose1(state, n, (const char *)src, k, (char *)a);
	    return;
	}

	if (size<=0) return;
	gjrand_shuffleprep(state, (int64_t)n, &sh);
	s1 = (const char *)src;
	a1 = (char *)a;
	do
	{
		memcpy(a1, s1+gjrand_shuffle1(&sh)*size, size);
		a1 += size; k--;
	} while (k);
}
