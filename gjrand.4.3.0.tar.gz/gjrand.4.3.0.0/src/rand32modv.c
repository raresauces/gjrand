/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2018 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"
#include "config.h"

void
gjrand_rand32modv(struct gjrand *s, uint32_t m, int n, uint32_t *v)
{
	uint64_t a, b, c, d, w=0;
	uint32_t mask, shift, t;
	int k;

	if (n<=0) return;
	if (m<=0) return;

	shift = 0;
	t = m-1;
#if defined(__GNUC__) && __GNUC__>=4 && GJRAND_SIZEOFINT==4
	if (t) shift = 32 - __builtin_clz(t);
#else
	while (t>=63) {shift += 6; t >>= 6;}
	while (t) {shift++; t >>= 1;}
#endif
	mask = (((uint64_t)1)<<shift) - 1;

	GJRAND_INTE_LOADSTATE(s, a, b, c, d);

	while (1)
	{
		GJRAND_INTE_CRANK(a, b, c, d);
		w = a; k = 64-shift;
		do
		{
			t = w&mask; w >>= shift;
			if (t<m) {*v++ = t; if (--n==0) goto ret;}
			k -= shift;
		} while (k>=0);
	}

	ret:
	GJRAND_INTE_STORESTATE(s, a, b, c, d);
}
