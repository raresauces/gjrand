/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"

uint32_t
gjrand_rand32mod(struct gjrand *s, uint32_t mod)
{
	uint32_t r;

	gjrand_rand32modv(s, mod, 1, &r);
	return r;
}
