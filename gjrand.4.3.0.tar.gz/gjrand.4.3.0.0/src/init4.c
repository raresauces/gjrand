/* Part of gjrand random number library version 3.4.0.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include "gjrand.h"
#include "inte.h"

void
gjrand_init4(struct gjrand *s, const uint32_t x[4])
{
	s->a = (((uint64_t)x[3])<<32) | x[2];
	s->b = (((uint64_t)x[1])<<32) | x[0];
	s->c=5000001ul;
	s->d = 0;
	gjrand_inte_mixstate(s);
}
