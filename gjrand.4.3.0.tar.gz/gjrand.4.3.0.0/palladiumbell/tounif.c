/* Test software for gjrand random numbers version 3.2.3.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "../src/my_int_types.h"

/* The idea, although presumably old and obvious, is pinched from */
/* tests mentioned in Christopher Wallace's excellent FastNorm3 */
/* generator. Transforms 1 to 4 are also from there. */
/* (NB only the ideas, Wallace doesn't give source code for this.) */

/* Normal deviates are converted to uniform floating point in the */
/* range [ 0 1 ) and then to fixed point. The fixed point file */
/* should be uniform random bits, it can be tested using the tests */
/* in testunif/ or with other test suites such as Diehard or NIST. eg: */
/* ./blatnorm | ./tounif 48 4 | ../testunif/bin/rda 10000000 */

/* Alternatively, converts to uniform floats in [ 0 1 ) and writes them */
/* as binary doubles suitable for tests in testfunif */
/* ./blatnorm | ./tounif f 1 | ../testfunif/bin/dim155 100000000 */

void
usage(void)
{
	fprintf(stderr, "usage: tounif bits transform\n"
"bits, one of 8 16 32 48 f\n"
"transform, one of 1 to 5\n");
	exit(1);
}

void
crash(const char *s) {fprintf(stderr, "tounif crash [%s]\n", s); exit(1);}

#define S16 65536.0
#define S32 (S16*S16)
#define S48 (S16*S32)

#define MAX 1024

void
blatf(double a[], int n)
	{if (fwrite(a, sizeof(double), n, stdout)!=(size_t)n) crash("fwrite");}

void
blat8(double a[], int n)
{
	unsigned char b[MAX];
	int i;
	if (n>MAX) crash("blat8 n too big");
	for (i=0; i<n; i++) b[i] = (int)(256.0*a[i]);
	if (fwrite(b, sizeof(unsigned char), n, stdout)!=(size_t)n)
		crash("fwrite");
}

void
blat16(double a[], int n)
{
	unsigned short b[MAX];
	int i;
	if (n>MAX) crash("blat16 n too big");
	for (i=0; i<n; i++) b[i] = (int)(S16*a[i]);
	if (fwrite(b, sizeof(unsigned short), n, stdout)!=(size_t)n)
		crash("fwrite");
}

void
blat32(double a[], int n)
{
	uint32_t b[MAX];
	int i;
	if (n>MAX) crash("blat32 n too big");
	for (i=0; i<n; i++) b[i] = (uint32_t)(S32*a[i]);
	if (fwrite(b, sizeof(uint32_t), n, stdout)!=(size_t)n) crash("fwrite");
}

void
blat48(double a[], int n)
{
	unsigned short b[3*MAX];
	int i;
	if (n>MAX) crash("blat48 n too big");
	for (i=0; i<n; i++)
	{
		uint64_t j = (uint64_t)(S48*a[i]);
		b[3*i] = j>>16; b[3*i+1] = j>>32; b[3*i+2] = j;
	}
	if (fwrite(b, sizeof(unsigned short), 3*n, stdout)!=(size_t)(3*n))
		crash("fwrite");
}

void
trans1(double a[], int n)
	{int j; for (j=0; j<n; j++) a[j] = 0.5 * (1.0 + erf(a[j] * M_SQRT1_2));}

void
trans2(double a[], int n)
{
	double x, y;
	int j;
	for (j=0; j<n; j++)
		{x = a[2*j]; y = a[2*j+1]; a[j] = exp(-0.5 * (x*x + y*y));}
}

void
trans3(double a[], int n)
{
	double x, y, z;
	int j;
	for (j=0; j<n; j++)
	{
		x = a[3*j]; y = a[3*j+1]; z = a[3*j+2];
		a[j] = (x/sqrt(x*x+y*y+z*z) + 1.0) * 0.5;
	}
}

void
trans4(double a[], int n)
{
	double w, x, y, z;
	int j;
	for (j=0; j<n; j++)
	{
		w = a[4*j]; x = a[4*j+1]; y = a[4*j+2]; z = a[4*j+3];
		x = x*x+w*w;
		a[j] = x / (x + y*y + z*z);
	}
}

void
trans5(double a[], int n)
{
	double x, y;
	int j;
	for (j=0; j<n; j++)
		{x = a[2*j]; y = a[2*j+1]; a[j] = atan2(x,y)*(0.5/M_PI)+0.5;}
}

int
main(int argc, char **argv)
{
	double a[4*MAX];
	static const int n[6] = {0, 1, 2, 3, 4, 2};
	static void (* const tf[6])(double a[], int n)=
		{0, trans1, trans2, trans3, trans4, trans5};
	void (*bf)(double a[], int n)=0;
	int t, bits, f;

	if (argc!=3) usage();
	if (argv[1][0]=='f' && argv[1][1]==0) bf=blatf;
	else
	{
		if (sscanf(argv[1], "%d", &bits)!=1) usage();
		if (bits==8) bf=blat8;
		else if (bits==16) bf=blat16;
		else if (bits==32) bf=blat32;
		else if (bits==48) bf=blat48;
		else usage();
	}

	if (sscanf(argv[2], "%d", &t)!=1 || t<=0 || t>5) usage();

	while (1)
	{
		f = fread(a, n[t]*sizeof(double), MAX, stdin);
		if (f<0) crash("fread");
		if (f==0) return 0;
		tf[t](a, f);
		bf(a, f);
	}
}
