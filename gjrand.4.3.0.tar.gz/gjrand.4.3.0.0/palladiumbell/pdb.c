/* Test software for gjrand random numbers version 4.2.2.0 or later. */
/* Copyright (C) 2004-2016 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "../testcommon/pcombo.h"
#include "../testcommon/binom.h"
#include "../testcommon/chi2p.h"

#ifdef __cplusplus
#define GJRAND_NO_ARGS
#else
#define GJRAND_NO_ARGS void
#endif

static void
crash(const char *s) {fprintf(stderr,"pdb crashing: [%s]\n", s); exit(1);}

static double pvals[99];
static int pvalp=0;

static void
appendpv(double p)
{
	if (pvalp>90) crash("too many P values");
	pvals[pvalp++]=p;
}

#define SIZ (20*1024*1024)

static double buf[SIZ+5];

/* self-correlation */

/* self-correlation is currently quite slow, so we use a smaller data set */
#define CSIZ (80*1024)
#define CREP 25

static double rbuf[CSIZ+5], productbuf[2*CSIZ+10], accbuf[2*CSIZ+10];

#define MAXMEM (CSIZ*9+400)
static double memory[MAXMEM+3];
static double *memptr=memory;

static double *
memmark(int siz)
{
	double *r=memptr;

	memptr=r+siz;
if (memptr>memory+MAXMEM) crash("out of memory");

	return r;
}

static void
memrelease(double *mark)
{
	memptr=mark;
}


struct poly {int order; double *coef;};

static void
polysub2(double *ca, double *cr, int ord)
{
	int i=ord-2;

	do {cr[1+i]-=ca[1+i]; cr[i]-=ca[i]; i-=2;} while (i>=0);
}

static void
polyadd2(double *ca, double *cr, int ord)
{
	int i=ord-2;

	do {cr[1+i]+=ca[1+i]; cr[i]+=ca[i]; i-=2;} while (i>=0);
}

static void
polyadd3(double *ca, double *cb, double *cr, int ord)
{
	int i=ord-2;

	do {cr[1+i]=ca[1+i]+cb[1+i]; cr[i]=ca[i]+cb[i]; i-=2;} while (i>=0);
}

static void
polymul4(const double *ca, const double *cb, double *cr)
{
	cr[0] += ca[0]*cb[0];
	cr[1] += ca[0]*cb[1]+ca[1]*cb[0];
	cr[2] += ca[0]*cb[2]+ca[1]*cb[1]+ca[2]*cb[0];
	cr[3] += ca[0]*cb[3]+ca[1]*cb[2]+ca[2]*cb[1]+ca[3]*cb[0];
	cr[4] += ca[1]*cb[3]+ca[2]*cb[2]+ca[3]*cb[1];
	cr[5] += ca[2]*cb[3]+ca[3]*cb[2];
	cr[6] += ca[3]*cb[3];
}

static void
polymul2(double *ca, double *cb, double *cr, int ord)
{
	const int small=10;

	{
		int j;
		for (j=0; j<2*ord; j++) cr[j]=0;
	}

	if (ord<=4*small)
	{
		int j, k;

		for (j=4*(small-1); j>=0; j-=4) for (k=4*(small-1); k>=0; k-=4)
			polymul4(ca+j, cb+k, cr+j+k);

		return;
	}

	{
		struct poly t1, t3;

		t1.order=ord; t3.order=ord;
		t1.coef=memmark(ord);

		polymul2(ca, cb, t1.coef, ord/2);
		polyadd2(t1.coef, cr, ord);
		polysub2(t1.coef, cr+ord/2, ord);

		polymul2(ca+ord/2, cb+ord/2, t1.coef, ord/2);
		polyadd2(t1.coef, cr+ord, ord);
		polysub2(t1.coef, cr+ord/2, ord);

		polyadd3(ca, ca+ord/2, t1.coef, ord/2);
		polyadd3(cb, cb+ord/2, t1.coef+ord/2, ord/2);

		t3.coef=memmark(ord);
		polymul2(t1.coef, t1.coef+ord/2, t3.coef, ord/2);

		polyadd2(t3.coef, cr+ord/2, ord);

		memrelease(t1.coef);
	}
}

static void
cor_printstats(double p[], int order, int rep)
{
	int i, count, clow[3], chigh[3];
	double x, low[3], high[3];
	double s=0.0, ss=0.0;

	low[0]=low[1]=low[2]=1e38;
	high[0]=high[1]=high[2]= -1e38;

	for (i=order/4-1; i<order/2-1; i++)
	{
		x=p[i]/sqrt((double)i*rep);
		if (x>high[2])
		{
			high[2]=x; chigh[2]=i;
			if (x>high[1])
			{
				high[2]=high[1]; chigh[2]=chigh[1];
				high[1]=x; chigh[1]=i;
				if (x>high[0])
				{
					high[1]=high[0]; chigh[1]=chigh[0];
					high[0]=x; chigh[0]=i;
				}
			}
		}
		if (x<low[2])
		{
			low[2]=x; clow[2]=i;
			if (x<low[1])
			{
				low[2]=low[1]; clow[2]=clow[1];
				low[1]=x; clow[1]=i;
				if (x<low[0])
				{
					low[1]=low[0]; clow[1]=clow[0];
					low[0]=x; clow[0]=i;
				}
			}
		}
		s+=x; ss+=x*x;
	}

	for (i=0; i<3; i++) {chigh[i]=order/2-chigh[i]; clow[i]=order/2-clow[i];}

	count=order/4;

	printf("mean=%f\n", s/count);
	printf("sd  =%f\n", sqrt(ss/count-s*s/((double)count*(double)count)));
	printf("high=%f (%d) %f (%d) %f (%d)\n",
		high[0], chigh[0], high[1], chigh[1], high[2], chigh[2]);
	printf("low =%f (%d) %f (%d) %f (%d)\n",
		low[0], clow[0], low[1], clow[1], low[2], clow[2]);

	{
		double pv;

		pv = -low[0];
		if (high[0]>pv) pv=high[0];
		pv=erfc(M_SQRT1_2*pv)*0.5;
		pv = pco_scale(pv, order*0.5);

		printf("One sided p-value (very small numbers are bad):\n");
		printf("P = %.3g\n", pv);

		appendpv(pv);
	}
}

static void
selfcor(double buf[], int order, int rep)
{
	int i, j;
	printf("Self-correlation =====================\n");
	for (i=0; i<2*order; i++) accbuf[i] = 0;
	for (j=0; j<rep; j++)
	{
		for (i=0; i<order; i++) rbuf[order-i]=buf[order*j+i];
		polymul2(buf+order*j, rbuf, productbuf, order);
		for (i=0; i<2*order; i++) accbuf[i] += productbuf[i];
	}
	cor_printstats(accbuf, 2*order, rep);
	printf("End self-correlation =====================\n\n");
}

/* end self-correlation */

static void
multichis(const long bucket[65536], const double expect[65536], double pv[5])
{
	long tmp[8192];
	double texp[8192];
	double c, x, t;
	const long *bp=bucket;
	const double *xp=expect;
	int j, k, bc=65536;

	for (k=4; k>=0; k--)
	{
		c = 0;
		for (j=0; j<bc; j++) {x = xp[j]; t = bp[j]-x; c += t*t/x;}
		pv[k] = chi2p2(c, bc-1);
		printf("df = %5d ; chis = %12.2f (p = %.3g)\n", bc-1, c, pv[k]);

		bc >>= 3;
		for (j=0; j<bc; j++)
		{
			tmp[j] = bp[8*j]+bp[8*j+1]+bp[8*j+2]+bp[8*j+3]
				+bp[8*j+4]+bp[8*j+5]+bp[8*j+6]+bp[8*j+7];
			texp[j] = xp[8*j]+xp[8*j+1]+xp[8*j+2]+xp[8*j+3]
				+xp[8*j+4]+xp[8*j+5]+xp[8*j+6]+xp[8*j+7];
		}
		bp = tmp; xp = texp;
	}
}

/* lowbits test */

static void
ulb(long bucket[], double mul, double x)
{
	int j;

	x *= mul;
	x -= floor(x);
	j = (int)(x*65536.0);
	bucket[j&65535]++;
}

static void
lowbits(double buf[], int siz, int shift)
{
	long bucket[65536];
	double expect[65536], pv[5], mul=(double)(1<<shift), t;
	int j;

	memset(bucket, 0, sizeof(bucket));
	for (j=0; j<siz; j++) ulb(bucket, mul, buf[j]);
	for (j=0; j<65536; j++) expect[j] = siz/65536.0;

	printf("Low order bits %d =====================\n", shift);

	multichis(bucket, expect, pv);
	t = pcombo(pv, 5);
	printf("One sided p-value (very small numbers are bad):\n");
	printf("P = %.3g\n", t);
	appendpv(t);

	printf("End low order bits %d =====================\n\n", shift);
}

/* end lowbits */

/* moments */

static double moments[11];

static void
umoments(const double in[], const int count)
{
	int i, j;

	for (j=0; j<=10; j++) moments[j]=0.0;
	for (j=0; j<count; j++)
	{
		double x=in[j];
		double y=x;

		i=1;
		goto start;
		do {y*=x; start: moments[i]+=y; i++;} while (i<=10);
	}
}

static void
printmoments(GJRAND_NO_ARGS)
{
	double pv[11], pc, x, s;
	int i;

	printf("Moments =====================\n");

	umoments(buf, SIZ);

	x=1.0/(double)SIZ;
	s=sqrt((double)SIZ);
	for (i=1; i<=10; i++)
	{
		static const float y[] = {0, 1, 1.4142136, 3.873, 9.79, 30.741,
			100.5, 367.61, 1408, 5870, 25588};
		static const short m[] = {0, 0, 1, 0, 3, 0, 15, 0, 105, 0, 945};
		double z, z3;
		z = moments[i]*x;
		z3 = (z-m[i])*s/y[i];
		pv[i] = erfc(fabs(M_SQRT1_2*z3));
		printf("%2d: %15.8f %15.8f %.3g\n", i, z, z3, pv[i]);
	}

	pc=pcombo(pv+1, 10);

	printf("One sided p-value (very small numbers are bad):\n");
	printf("P = %.3g\n", pc);

	appendpv(pc);

	printf("End moments =====================\n\n");
}

/* end moments */

/* extrema */

static void
extrema(int n)
{
	double hi, lo, hihi= -999, lohi=999, hilo= -999, lolo=999, pv[4], pc, x, y;
	int i, j, k;

	printf("Extrema =====================\nhigh: ");

	for (i=0; i<SIZ; i+=n)
	{
		k=i+n; if (k>SIZ) k=SIZ;
		hi= -999;
		for (j=i; j<k; j++) if (buf[j]>hi) hi=buf[j];
		printf("%7.3f ",hi);
		if (hi>hihi) hihi=hi;
		if (hi<lohi) lohi=hi;
	}
	printf("\nlow : ");

	for (i=0; i<SIZ; i+=n)
	{
		k=i+n; if (k>SIZ) k=SIZ;
		lo=999;
		for (j=i; j<k; j++) if (buf[j]<lo) lo=buf[j];
		printf("%7.3f ",lo);
		if (lo>hilo) hilo=lo;
		if (lo<lolo) lolo=lo;
	}
	putchar('\n');

	printf("hi %9.3f %9.3f lo %9.3f %9.3f\n", lohi, hihi, lolo, hilo);
	lohi=erfc(M_SQRT1_2*lohi)*0.5; lohi=log1p(-lohi); lohi = exp(lohi*n);
	hihi=erfc(M_SQRT1_2*hihi)*0.5; hihi=log1p(-hihi); hihi = -expm1(hihi*n);
	lolo=erfc(-M_SQRT1_2*lolo)*0.5; lolo=log1p(-lolo); lolo = -expm1(lolo*n);
	hilo=erfc(-M_SQRT1_2*hilo)*0.5; hilo=log1p(-hilo); hilo = exp(hilo*n);
	printf("hi %9.6f %9.6f lo %9.6f %9.6f\n", lohi, hihi, lolo, hilo);

	x=((double)SIZ/n);
	y=pco_scale(lohi, x)*2.0; if (y>1.0) y=2.0-y; pv[0]=y;
	y=pco_scale(hihi, x)*2.0; if (y>1.0) y=2.0-y; pv[1]=y;
	y=pco_scale(lolo, x)*2.0; if (y>1.0) y=2.0-y; pv[2]=y;
	y=pco_scale(hilo, x)*2.0; if (y>1.0) y=2.0-y; pv[3]=y;
	printf("(pv %.3g %.3g %.3g %.3g)\n", pv[0], pv[1], pv[2], pv[3]);

	pc=pcombo(pv, 4);
	printf("One sided p-value (very small numbers are bad):\n");
	printf("P = %.3g\n", pc);
	appendpv(pc);

	printf("End extrema =====================\n\n");
}

/* end extrema */

/* bds */

static int
dcmp(const void *a, const void *b)
{
	double da=*(const double *)a;
	double db=*(const double *)b;
	if (da<db) return -1;
	if (da>db) return 1;
	return 0;
}

static void
bds(double lo, double hi, int n)
{
	int histo[256];
	double max= -1e30, rms=0.0, chis=0.0, t, pv;
	double ex=sqrt(2.0*M_PI), rex = -n/ex;
	int i, j, k, zeroes;

	printf("BDS =====================\n");

	j=0;
	for (i=0; i<n; i++)
	{
		double v=buf[i];
		if (v>lo && v<hi) buf[j++]=v;
	}

	qsort(buf, j, sizeof(double), dcmp);

	for (i=0; i<256; i++) histo[i]=0;
	zeroes=0;
	for (i=1; i<j; i++)
	{
		double l=buf[i-1], h=buf[i], g=h-l;
		zeroes+=(g==0.0);
		g*=exp(h*l*-0.5);
		if (g>max) max=g;
		rms+=g*g;

		g *= rex;
		k = (int)(exp(g)*256.0);
		if (k<0) k = 0; else if (k>255) k = 255; /* MUDFLAP */
		histo[k]++;
	}

	rms=sqrt(rms/(j-1));

	ex=j/256.0;
	for (i=0; i<256; i++) {t=histo[i]-ex; chis+=t*t;}
	chis/=ex;

	printf("max = %.4e\nrms = %.4e\nchis = %.4f\nzeroes = %d\n",
		max, rms, chis, zeroes);

	pv = chi2p1(chis, 255);

	printf("One sided p-value (very small numbers are bad):\n");
	printf("P = %.3g\n", pv);

	appendpv(pv);

	printf("End bds =====================\n\n");
}

/* end bds */

/* chisquared */

static double
normdens(double x) {return exp(x * x * -0.5);}

static const int chithres[9]
		= {0, 95775,135446,165886,191549,214158,234598,253395,270891};
static const short chisplit[9]
		= {0, 28053,  3445,   898,   259,    78,    24,     8,     2};
static double chimul[9]; /* chisplit[j] / (chithres[j]-chisthres[j-1]) */
static long chibucket[65536];
static const double CHIWID=1.0/65536.0;

static void
mkexpect(long samples, double buckets[65536])
{
	double x, base, wid;
	int j, k, n=0;

	for (k=0; k<8; k++)
	{
		base = chithres[k]*CHIWID;
		wid = CHIWID/chimul[k+1];
		for (j=0; j<chisplit[k+1]; j++)
		{
		x = gjrt_integrate(normdens, base+j*wid, base+(j+1)*wid, 5);
			buckets[n+32768] = buckets[n] = x; n++;
		}
	}

	x = gjrt_integ2(normdens, chithres[8]*CHIWID, 1.0/256.0, 1.0e-19, 8);
	buckets[65535] = buckets[32767] = x;

	x=0.0;
	for (j=0; j<65536; j++) x += buckets[j];
	x = samples/x;
	for (j=0; j<65536; j++) buckets[j] *= x;
}

static void
uchi(double x)
{
	int index=0, j;

	if (x<0) {index = 32768; x = -x;}

	x *= 65536.0;

	for (j=1; j<=8; j++)
	{
		if (x<chithres[j])
		{
			x -= chithres[j-1]; x *= chimul[j];
			index += (int)x;
			break;
		}
		index += chisplit[j];
	}

	chibucket[index]++;
}

static void
printchis(long count)
{
	double expect[65536], pv[5];
	int j;

	chimul[0] = 1;
	for (j=1; j<=8; j++)
		chimul[j] = (double)chisplit[j]/(chithres[j]-chithres[j-1]);
	memset(chibucket, 0, sizeof(chibucket));


	for (j=0; j<count; j++) uchi(buf[j]);

	mkexpect(count, expect);

	printf("Chisquare =====================\n");
	multichis(chibucket, expect, pv);
	for (j=0; j<5; j++) appendpv(pv[j]);
	printf("End chisquare =====================\n\n");
}

/* end chisquared */

/* nearest distance analysis. */

/* convert a normal variate to an integer 0 to 15 with equal probability */
static int
tohextile(double x)
{
	int s=0;
	if (x<0.0) {s=8; x= -x;}
	if (x<0.6744897501961370)
	{
		if (x<0.3186393639644102)
			{if (x>=0.1573106846101825) s++; return s;}
		else
			{s+=2; if (x>=0.4887764111147070) s++; return s;}
	}
	else
	{
		s+=4;
		if (x<1.1503493803761058)
			{if (x>=0.8871465590189737) s++; return s;}
		else
			{s+=2; if (x>=1.5341205443525574) s++; return s;}
	}
}

static double ndadc[49][16][16];
static long ndacount[49][16][16];
static long ndalast[16];

static void
ndainit(GJRAND_NO_ARGS)
{
	int i;
	memset(ndacount, 0, sizeof(ndacount));
	for (i=0; i<16; i++) ndalast[i]= -1;
}

static void
donibble(int n, long pos)
{
	int i;

	for (i=0; i<16; i++) if (ndalast[i]>=0)
	{
		long d=pos-ndalast[i];
		if (d>48) d=0;
		ndacount[d][i][n]++;
	}

	ndalast[n]=pos;
}

static double expectnda[49];

static void
mkexpectnda(long size)
{
	int i;
	double p=1.0, x;

	for (i=1; i<=48; i++)
	{
		x=p*(1.0/16.0);
		expectnda[i]=x;
		p-=x;
	}
	expectnda[0]=p;

	p=(double)size/16.0-1.0;
	for (i=0; i<=48; i++) expectnda[i]*=p;
}

static void
butterfly(double *x, double *y)
{
	double a, b;
	int siz=y-x;

	do
	{
		a = *x; b = *y;
		*x = a+b; *y = a-b;
		x++; y++;
		siz--;
	} while (siz>0);

	siz = y-x;
	if (siz>1)
	{
		x -= siz; y -= siz;
		siz >>= 1;
		butterfly(x, x+siz);
		butterfly(y, y+siz);
	}
}

static void
ndaan(GJRAND_NO_ARGS)
{
	double pvs[2];
	double t=0.0, pv, extreme;
	int i, j, k, exi, exj, exk, exd;

	t = 0.0; extreme = 999.0; exi=exj=exk = -1; exd = '?';
	for (i=0; i<16; i++) for (j=0; j<16; j++)
	{
		long tot=0;
		for (k=48; k>=0; k--) tot += ndacount[k][i][j];
		for (k=1; k<=48; k++)
		{
			long x=ndacount[k][i][j];
			double y=sumbino(tot, x, 1.0/16.0), z = tot*(1.0/16.0);

			if (y<extreme)
			{
				extreme=y; exi=i; exj=j; exk=k;
				if (x>z) exd='+'; else exd='-';
			}
			ndadc[k][i][j] = (x-z) / sqrt(z);
			tot-=x;
		}
	}
	pvs[0] = pco_scale(extreme, 16*16*48);
	printf("extreme = %.3g   (%d %d %d %c)  (p = %.3g)\n",
		extreme, exi, exj, exk, exd, pvs[0]);

	for (i=48; i>=0; i--) butterfly(&(ndadc[i][0][0]), &(ndadc[i][8][0]));
	extreme = -1.0;
	for (i=48; i>=0; i--) for (j=0; j<16; j++) for (k=0; k<16; k++)
	{
		t = fabs(ndadc[i][j][k]);
		if (t>extreme) {extreme = t; exi = i; exj = j; exk = k;}
	}

	extreme /= 16.0;
	printf("transform = %.3g   (%d %x %x)  ", extreme, exi, exj, exk);
	extreme = erfc(M_SQRT1_2*extreme);
	pvs[1] = pco_scale(extreme, 16*16*48);
	printf("(p = %.3g)\n", pvs[1]);

	pv = pcombo(pvs, 2);
	printf("One sided p-value (very small numbers are bad):\n");
	printf("P = %.3g\n", pv);

	appendpv(pv);
}

static void
nda(GJRAND_NO_ARGS)
{
	long pos=0;

	ndainit();

	printf("Nearest distance analysis =====================\n");
	for (pos=0; pos<SIZ; pos++) donibble(tohextile(buf[pos]), pos);

	mkexpectnda(SIZ);
	ndaan();
	printf("End nearest distance analysis =====================\n\n");
}

/* end nearest distance analysis */

/* Overall summary */
static void
printsum(GJRAND_NO_ARGS)
{
	int badness[23];
	double pc;
	int j, worse;

	fprintf(stdout, "\n\n=====================\ncompleted %d tests\n",
		pvalp);
	for (j=0; j<22; j++) badness[j]=0;
	for (j=0; j<pvalp; j++)
	{
		double d=pvals[j], b=0.1;
		int k=0;

		while (d<b && k<20) {b*=0.1; k++;}
		if (d==0.0) k=21;
		badness[k]++;
	}

	fprintf(stdout, "%d out of %d tests ok.\n", badness[0], pvalp);
	worse=pvalp-badness[0];

	for (j=1; j<22; j++) if (badness[j])
	{
		static const int badmax[7][2]=
		{
			{99, 99},
			{4, 10},
			{1, 3},
			{0, 1},
			{0, 1},
			{0, 1},
			{0, 1},
		};
		const char *msg;

		if (j>6 || worse>badmax[j][1]) msg="(SERIOUSLY BAD)";
		else if (worse>badmax[j][0]) msg="(slightly bad)";
		else msg="(probably ok)";

		fprintf(stdout, "%d grade %d failures %s.\n", badness[j], j, msg);

		worse-=badness[j];
	}

if (worse!=0) fprintf(stderr, "worse=%d huh?\n", worse);

	pc=pcombo(pvals, pvalp);
	fprintf(stdout,
"\n\nOverall summary one sided P-value (smaller numbers bad)\nP = %.3g\n",
pc);
}

/* end overall summary */


int
main(int argc, char **argv)
{
	if (argc!=1)
		crash("give no arguments. Numbers are read from stdin.");

	printf("*** pdb version 8 ***\n\n");

	if (fread(buf, sizeof(double), SIZ, stdin)!=(size_t)SIZ)
		crash("fread");

	selfcor(buf, CSIZ, CREP);

	lowbits(buf, SIZ, 2);
	lowbits(buf, SIZ, 12);
	lowbits(buf, SIZ, 22);
	lowbits(buf, SIZ, 32);

	printmoments();

	extrema(SIZ/8);

	printchis(SIZ);

	nda();

	bds(-4.0, 4.0, SIZ); /* must be last because it does damage. */

	printsum();

	return 0;
}
