/* Miscellaneous stuff for gjrand random numbers version 4.1.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "../../src/aanormaltab.c"

/* This is like blatnorm but with a different generator. */

/* This is a "Straw-man" that is supposed to fail some tests. */

/* Increasing N makes better quality at the expense of speed. */
/* gjrand_normal() in version 4.* is approximately the same as N 16 . */
#define N 4

void
usage(GJRAND_NO_ARGS)
{
	printf("usage:\n"
"x4\n"
"x4 integer_seed\n"
"Writes normal variates to standard output in (unportable) binary format.\n"
"Attempts to write forever.\n");

	exit(1);
}

static double mul;

double
straw(struct gjrand *g)
{
	unsigned char b[N];
	double r=0;
	int j;

	gjrand_randbytes(g, N, b);
	for (j=N-1; j>=0; j--)
		{r *= (1017.0/1024.0); r += gjrand_inte_normal_app[b[j]];}
	return r*mul;
}

int
main(int argc, char **argv)
{
	double t;
	long seed;
	struct gjrand g;
	int j;

	if (argc>1)
	{
		if (sscanf(argv[1], "%ld", &seed)!=1) usage();
		gjrand_init(&g, seed);
	}
	else gjrand_initrand(&g);

	mul = t = 1.0;
	for (j=1; j<N; j++)
	{
		t *= (1017.0/1024.0);
		mul += t*t;
	}
	mul = 1.0/sqrt(mul);

	while (1)
	{
		double b[1024];
		for (j=0; j<1024; j++) b[j]=straw(&g);
		if (fwrite(b, sizeof(double), 1024, stdout) <= 0) break;
	}

	return 0;
}
