/* Miscellaneous stuff for gjrand random numbers version 3.4.2.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

/* This is like blatnorm but with a different generator. */

/* This uses the "polar Box-Muller", but driven in this case by */
/* the library rand() function for uniform variates. rand() is often */
/* very bad. Let's see if it's enough to damage the normal variates. */

#include "../../src/gjrand.h"

static void
usage(GJRAND_NO_ARGS)
{
	printf("usage:\n"
"polarbad\n"
"polarbad integer_seed\n"
"Writes normal variates to standard output in (unportable) binary format.\n"
"Attempts to write forever.\n");

	exit(1);
}

void
normalv(int n, double *v)
{
	double x, y, w;

	if (n>0) while (1)
	{
		x = (rand()-(RAND_MAX*0.5)) * (2.0/(RAND_MAX+1.0));
		y = (rand()-(RAND_MAX*0.5)) * (2.0/(RAND_MAX+1.0));
		w = x*x+y*y;
		if (w < 1.0)
		{
			w += 1e-30;
			w = sqrt(log(w) / w * -2.0);
			*v = x*w; v++;
			n--; if (n<=0) return;
			*v = y*w; v++;
			n--; if (n<=0) return;
		}
	}
}

int
main(int argc, char **argv)
{
	unsigned seed;

	if (argc>1) {if (sscanf(argv[1], "%u", &seed)!=1) usage();}
	else seed = (unsigned)time(0);
	srand(seed);

	while (1)
	{
		double b[1024];
		normalv(1024, b);
		if (fwrite(b, sizeof(double), 1024, stdout) <= 0) break;
	}

	return 0;
}
