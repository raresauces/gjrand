/* Miscellaneous stuff for gjrand random numbers version 3.4.2.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* This is like blatnorm but with a different generator. */

/* This uses the "polar Box-Muller" approximately as in gjrand versions */
/* 1.1 to 2.4 . This is probably the most popular method. If the library */
/* log and sqrt functions are very accurate, this should give extremely */
/* high quality variates, and pass all tests (i hope). */

#include "../../src/gjrand.h"

static void
usage(GJRAND_NO_ARGS)
{
	printf("usage:\n"
"polar\n"
"polar integer_seed\n"
"Writes normal variates to standard output in (unportable) binary format.\n"
"Attempts to write forever.\n");

	exit(1);
}

#define SCALE (1.0/(((uint64_t)1)<<31))
#define TINY (SCALE*SCALE*SCALE*SCALE)

void
normalv(struct gjrand *s, int n, double *v)
{
	int32_t a[2];

	if (n>0) while (1)
	{
		gjrand_rand32v(s, 2, (uint32_t *)a);
		if ((uint64_t)((int64_t)a[1]*a[1])
			+(uint64_t)((int64_t)a[0]*a[0])
			< (((uint64_t)1)<<62))
		{
			double x=a[1]*SCALE, y=a[0]*SCALE, w = x*x + y*y + TINY;
			w = sqrt(log(w) / w * -2.0);
			*v = x*w; v++;
			n--; if (n<=0) return;
			*v = y*w; v++;
			n--; if (n<=0) return;
		}
	}
}

int
main(int argc, char **argv)
{
	long seed;
	struct gjrand g;

	if (argc>1)
	{
		if (sscanf(argv[1], "%ld", &seed)!=1) usage();
		gjrand_init(&g, seed);
	}
	else gjrand_initrand(&g);

	while (1)
	{
		double b[1024];
		normalv(&g, 1024, b);
		if (fwrite(b, sizeof(double), 1024, stdout) <= 0) break;
	}

	return 0;
}
