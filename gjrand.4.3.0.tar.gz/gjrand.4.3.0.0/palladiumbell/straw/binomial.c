/* Miscellaneous stuff for gjrand random numbers version 3.4.2.0 or later. */
/* Copyright (C) 2004-2011 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* This is like blatnorm but with a different generator. */

/* This is a "Straw-man" that is supposed to fail some tests. */

/* This one uses a binomial approximation to the normal distributon. */
/* It's better than straw4 which appeared in earlier versions, */
/* but it's still not very good. */

#include "../../src/gjrand.h"

void
usage(GJRAND_NO_ARGS)
{
	printf("usage:\n"
"binomial\n"
"binomial integer_seed\n"
"Writes normal variates to standard output in (unportable) binary format.\n"
"Attempts to write forever.\n");

	exit(1);
}

double
straw(struct gjrand *g)
{
	double r=gjrand_coins(g, 256)-128.5;
	return (r+gjrand_drand(g)) * 0.12491869917839092;
}

int
main(int argc, char **argv)
{
	long seed;
	struct gjrand g;

	if (argc>1)
	{
		if (sscanf(argv[1], "%ld", &seed)!=1) usage();
		gjrand_init(&g, seed);
	}
	else gjrand_initrand(&g);

	while (1)
	{
		double b[1024];
		size_t i;
		for (i=0; i<1024; i++) b[i]=straw(&g);
		if (fwrite(b, sizeof(double), 1024, stdout) <= 0) break;
	}

	return 0;
}
