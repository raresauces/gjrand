/* Miscellaneous stuff for gjrand random numbers version 3.2.3.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>

/* This is like blatnorm but with a different generator. */

/* This is a "Straw-man" that is supposed to fail some tests. */

/* This one is actually gjrand_normal() with some post-processing */
/* to try to get some correlations with short lags. It should fail */
/* the self-correlation. */

#include "../../src/gjrand.h"

void
usage(GJRAND_NO_ARGS)
{
	printf("usage:\n"
"correlation\n"
"correlation integer_seed\n"
"Writes normal variates to standard output in (unportable) binary format.\n"
"Attempts to write forever.\n");

	exit(1);
}

int
main(int argc, char **argv)
{
	long seed;
	struct gjrand g;

	if (argc>2)
	{
		if (sscanf(argv[2], "%ld", &seed)!=1) usage();
		gjrand_init(&g, seed);
	}
	else gjrand_initrand(&g);

	while (1)
	{
		double b[1<<14];
		int i;

		for (i=0; i<1<<14; i++)
		{
			double x=gjrand_normal(&g);
			if (i>1000 && (gjrand_rand32(&g)&127)==0)
				x=(x+b[i-42]-b[i-747]+b[i-999])*0.5;
			b[i]=x;
		}
		if (fwrite(b, sizeof(double), 1<<14, stdout) <= 0) break;
	}

	return 0;
}
