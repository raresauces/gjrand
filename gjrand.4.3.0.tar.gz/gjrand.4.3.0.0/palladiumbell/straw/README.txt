This directory contains various other normal distribution generators.
The programs operate similarly to blatnorm, but use different algorithms.
polar is probably ok. All the rest have known problems.
These can all be tested with Palladium Bell.
