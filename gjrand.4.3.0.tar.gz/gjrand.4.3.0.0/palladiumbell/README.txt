Palladium Bell is a set of tests for normally distributed random numbers.
There are three test programs: pdb bigpdb tounif . Each of the first
two read numbers in binary form as C type double from standard input and
analyses them. tounif converts the same kind of input to uniform random bits
which can then be tested by other programs.

The blatnorm program will create appropriate test files using the gjrand
library. You can test other generators by writing programs similar to
blatnorm that work with your generator of choice.

blatv is a slightly faster version. It takes a compulsory argument for block
size. 2048 or 4096 are likely to be fastest.

Note that binary double is not always the same format between different
CPUs, operating systems or compilers, so try to generate and use the
numbers on the same computer.

pdb will read and test 20 MEG of variates.

bigpdb will read to end of file with no arguments, or use a size arg as below.

tounif will read to end of file.

It is important to realise that a good random generator will on rare occasions
produce a surprising result.

Program pdb
===========

Invoke with no arguments. It reads from standard input.
eg:
./pdb < datafile
or
./blatnorm | ./pdb

The values assume SIZ = 10MEG unless noted.

Self-correlation =================
This measures self-correlation of first CSIZ (80k) numbers for all lags up to
CSIZ/2. This is then repeated CREP (25) times using new segments of data,
and the correlation coefficients accumulated.

(Numbers in brackets after highs and lows are the lags. Mostly these
are not interesting, but if you see the same lags appearing frequently
for different seeds it may say something about the structure of the generator
and how to fix it.)

High and low numbers too far from zero indicates there is too much
correlation between numbers with certain lags. This could be a serious problem
in some applications.

Low order bits (various shift counts) ==================
This takes the numbers as fixed point, shifts to the left by the shiftcount,
and then analyses the 16 bits immediately to the right of the binary point,
counting and doing a chisquared test for each of the 64K different possible
values. Values are then aggregated into a reduced number of buckets to
do more chisquared tests.

Moments ================
These are the mean, variance, skewness, and higher moments.
First column is the moment number, second is the raw moment,
third is the deviation from expectation in units of sigma,
and last is a P-value for this moment.

The final P value now reflects all 10 moments.

Extrema ===============
These are the highest and lowest values in each of the eighths of the data.
Tests are performed on the highest and lowest of the highs, and the highest
and lowest of the lows.

BDS ===================
This sorts the numbers and examines the differences between succesive
values in sorted order, to see if there are significant gaps where
numbers rarely or never occur. (This is quite slow.)
max should be 8.1e-06 to 1.4e-05
rms should be 8.443e-07 to 8.460e-07
zeroes should usually be 0, very rarely 1.
P-value is based on the chisquared only.

Chisquare ====================
The expected results for these chisquare tests do not depend much
on SIZ provided at least 5 or so fall in each bucket. It does depend
on the number of buckets.

The possible output range is divided into 64K buckets, and counts accumulated.
chis should be approximately the same as df, with large difference on either
side making a low P-value.

Failure on the high side suggests maybe the generator is not really normal, or
has the wrong mean or standard deviation.
Failure on the low side suggests the generator is filling the buckets more
accurately than expected and therefore might not really be random.

Values are then aggregated into a reduced number of buckets to
do more chisquared tests.

Expected bucket counts are calculated on the fly.

Nearest distance analysis ==================
Expected results don't depend much on SIZ.
This classifies the normal variates into 16 buckets that should be of
equal probability, then analyses the distance between value x and the most
recent previous value y for all values of x and y. The procedure is
inspired by Maurer's universal statistical test, and also the chi-squared
statistic. You'll have to read the source for more info.

Program bigpdb
==============

Invoke with no arguments. It reads from standard input.
eg:
./bigpdb < datafile
or
./blatnorm 20000000 | ./bigpdb

or with a size argument for a standard sized run eg:
./blatv 512 | ./bigpdb --small
size args are
--tiny		1M variates
--small		10M variates
--standard	100M variates
--big		1G variates
--huge		10G variates
--even-huger	100G variates
--tera		1T variates.
Some of the larger options are untested :-)

--progress (may be used with or without a size arg) causes progress reports
from time to time.

Bigpdb does some of the tests from pdb only. Unlike pdb it can handle
as much data as you want to throw at it up to many billion samples.
Counts less than about 10000 can lead to spurious high chisquare values
due to lots of almost empty buckets, so don't do that. Less than about
500000 might upset lowbits.

The self-correlation test is a bit different to in pdb. Only lags
up to 64 are calculated and all data except the first approx 1K is used.

All others expect the same as for pdb.

bigpdb now prints (very approximate) one-sided P-values for each test,
and a summary P-value at the bottom. P-values 0.1 to 1.0 are ok,
less than 0.1 somewhat suspicious, and the lower the worse, 0 totally broken.

In the low order bits tests, the P-value is based on the chi-squared only.

Program tounif
==============

This reads binary floating normal numbers from standard input and writes
hopefully uniform random bits to standard output. This allows testing of a
normal generator using test suites for uniform generators (such as the
programs in testunif, or the Diehard and NIST test suites.) Must have two args,
which are bits per sample (8, 16, 32, 48, f) and transform number (1 to 5).
eg:

./blatnorm 1000000 | ./tounif 16 2 | ../testunif/bin/metachi

If the first arg is "f", instead binary doubles uniform on [ 0 1 ) are
written. eg:

./blatnorm | ./tounif f 1 | ../testfunif/mcpf --standard
