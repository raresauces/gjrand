/* Test software for gjrand random numbers version 4.2.1.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "../src/gjrand.h"

void
usage(GJRAND_NO_ARGS)
{
	fputs("usage:\n"
"blatv blocksize\n"
"blatv blocksize count\n"
"blatv blocksize count integer_seed\n"
"'X' as the first char in blocksize forces alignment issues.\n"
"Writes normal variates to standard output in (unportable) binary format.\n"
"Without count, or negative count, writes forever.\n",
		stderr);

	exit(1);
}

void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

int
main(int argc, char **argv)
{
	double buf[4100];
	struct gjrand g;
	double *b=buf;
	int64_t count= -1;
	long seed;
	int blocksize;

	if (((uintptr_t)b)&15) b++;

	if (argc<2) usage();

	{
		char *a=argv[1];
		if (*a=='X') {b++; a++;}
		if (sscanf(a, "%d", &blocksize)!=1) usage();
	}
	if (blocksize<1 || blocksize>4096)
		crash("blocksize must be in the range 1 to 4096");

	if (argc>2)
	{
		double t;
		if (sscanf(argv[2], "%lf", &t)!=1) usage();
		count=(int64_t)t;
	}

	if (argc>3)
	{
		if (sscanf(argv[3], "%ld", &seed)!=1) usage();
		gjrand_init(&g, seed);
	}
	else gjrand_initrand(&g);

	while (count)
	{
		int c=blocksize;
		if (count>=0 && c>count) c=count;
		gjrand_normalv(&g, c, b);
		if (fwrite(b, sizeof(double), c, stdout)!=(size_t)c)
			crash("fwrite");
		if (count>0) count-=c;
	}

	return 0;
}
