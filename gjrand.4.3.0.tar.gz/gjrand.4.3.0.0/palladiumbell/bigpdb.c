/* Test software for gjrand random numbers version 4.2.3.0 or later. */
/* Copyright (C) 2004-2018 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include "../src/my_int_types.h"
#include "../testcommon/pcombo.h"
#include "../testcommon/binom.h"
#include "../testcommon/chi2p.h"

#ifdef __cplusplus
#define GJRAND_NO_ARGS
#else
#define GJRAND_NO_ARGS void
#endif

static void
crash(const char *s) {fprintf(stderr,"bigpdb crashing: [%s]\n", s); exit(1);}

static double pval[99];
static int pvalp=0, pchar;

static void
appendpv(double p) {if (pvalp>90) crash("too many P values"); pval[pvalp++]=p;}

static void
butterfly(double *x, double *y)
{
	double a, b;
	int siz=y-x;

	do
	{
		a = *x; b = *y;
		*x++ = a+b; *y++ = a-b;
		siz--;
	} while (siz>0);

	siz = y-x;
	if (siz>1)
	{
		x -= siz; y -= siz;
		siz >>= 1;
		butterfly(x, x+siz); butterfly(y, y+siz);
	}
}

#define BUCKETS (65536)
#define BUCKMASK (BUCKETS-1)
#define DBUCKETS ((double)BUCKETS)

static void
multichis(const int64_t bucket[BUCKETS], const double expect[BUCKETS], double pv[5])
{
	int64_t tmp[8192];
	double texp[8192], c, x, t;
	const int64_t *bp=bucket;
	const double *xp=expect;
	int j, k, bc=BUCKETS;

	for (k=4; k>=0; k--)
	{
		c = 0;
		for (j=0; j<bc; j++) {x = xp[j]; t = bp[j]-x; c += t*t/x;}
		pv[k] = chi2p2(c, bc-1);
		printf("df = %5d ; chis = %12.2f (p = %.3g)\n", bc-1, c, pv[k]);

		bc >>= 3;
		for (j=0; j<bc; j++)
		{
			tmp[j] = bp[8*j]+bp[8*j+1]+bp[8*j+2]+bp[8*j+3]
				+bp[8*j+4]+bp[8*j+5]+bp[8*j+6]+bp[8*j+7];
			texp[j] = xp[8*j]+xp[8*j+1]+xp[8*j+2]+xp[8*j+3]
				+xp[8*j+4]+xp[8*j+5]+xp[8*j+6]+xp[8*j+7];
		}
		bp = tmp; xp = texp;
	}
}

/* chisquared */

static double
normdens(double x) {return exp(x * x * -0.5);}

static const int chithres[9]
	= {0, 95775,135446,165886,191549,214158,234598,253395,270891};
static const short chisplit[9]
	= {0, 28053,  3445,   898,   259,    78,    24,     8,     2};
static double chimul[9]; /* chisplit[j] / (chithres[j]-chisthres[j-1]) */
static int64_t chibucket[BUCKETS];
static const double CHIWID=1.0/DBUCKETS;

static void
mkexpect(int64_t samples, double buckets[BUCKETS])
{
	double x, base, wid;
	int j, k, n=0;

	for (k=0; k<8; k++)
	{
		base = chithres[k]*CHIWID;
		wid = CHIWID/chimul[k+1];
		for (j=0; j<chisplit[k+1]; j++)
		{
		x = gjrt_integrate(normdens, base+j*wid, base+(j+1)*wid, 5);
			buckets[n+32768] = buckets[n] = x; n++;
		}
	}

	x = gjrt_integ2(normdens, chithres[8]*CHIWID, 1.0/256.0, 1.0e-19, 8);
	buckets[BUCKETS-1] = buckets[BUCKETS/2-1] = x;

	x=0.0;
	for (j=0; j<BUCKETS; j++) x += buckets[j];
	x = samples/x;
	for (j=0; j<BUCKETS; j++) buckets[j] *= x;
}

static void
uchi(double x)
{
	int index=0, j;

	if (x<0) {index = 32768; x = -x;}
	x *= 65536.0;
	for (j=1; j<=8; j++)
	{
		if (x<chithres[j])
		{
			x -= chithres[j-1]; x *= chimul[j];
			index += (int)x; break;
		}
		index += chisplit[j];
	}
	chibucket[index]++;
}

static void
printchis(int64_t count)
{
	double expect[BUCKETS], pv[5];
	int j;

	printf("Chisquare =====================\n");
	mkexpect(count, expect);
	multichis(chibucket, expect, pv);
	for (j=0; j<5; j++) appendpv(pv[j]);
	printf("End chisquare =====================\n\n");
}

/* end chisquared */

/* lowbits */

static int64_t lbucket3[BUCKETS], lbucket17[BUCKETS], lbucket31[BUCKETS];

static void
ulb(int64_t bucket[], double mul, double x)
{
	int j;
	x *= mul; x -= floor(x); j = (int)(x*DBUCKETS); bucket[j&BUCKMASK]++;
}

static void
printlow(const int64_t bucket[], int shift)
{
	double expect[BUCKETS], pv[5], t;
	int64_t tot=0;
	int j;

	printf("Low order bits %d =====================\n", shift);

	for (j=0; j<BUCKETS; j++) tot += bucket[j];
	t = tot*(1.0/DBUCKETS);
	for (j=0; j<BUCKETS; j++) expect[j] = t;

	multichis(bucket, expect, pv);
	t = pcombo(pv, 5);
	printf("One sided p-value (very small numbers are bad):\n"
		"%c = %.3g\n", pchar, t);
	appendpv(t);

	printf("End low order bits %d =====================\n\n", shift);
}

static void
printlows(GJRAND_NO_ARGS)
{
	printlow(lbucket3, 3);
	printlow(lbucket17, 17);
	printlow(lbucket31, 31);
}

/* end lowbits */

/* moments */

static double moments[11];

static void
umoments(double x)
{
	double y=x;
	int i;

	i=1;
	goto start;
	do
	{
		y*=x;
		start:
		moments[i]+=y;
		i++;
	} while (i<=10);
}

static void
printmoments(int64_t c)
{
	double pv[11], pc;
	double x, s;
	int i;

	printf("Moments =====================\n");

	x=1.0/(double)c;
	s=sqrt((double)c);
	for (i=1; i<=10; i++)
	{
		static const float y[] = {0, 1, 1.4142136, 3.873, 9.79, 30.741, 100.5,
			367.61, 1408, 5870, 25588};
		static const short m[] = {0, 0, 1, 0, 3, 0, 15, 0, 105, 0, 945};
		double z, z3;
		z = moments[i]*x;
		z3 = (z-m[i])*s/y[i];
		pv[i] = erfc(fabs(M_SQRT1_2*z3));
		printf("%2d: %15.8f %15.8f %.3g\n", i, z, z3, pv[i]);
	}

	pc=pcombo(pv+1, 10);

	printf("One sided p-value (very small numbers are bad):\n");
	printf("%c = %.3g\n", pchar, pc);

	appendpv(pc);

	printf("End moments =====================\n\n");
}

/* end moments */

/* nda */

static int
tohextile(double x)
{
	int s=0;
	if (x<0.0) {s=8; x= -x;}
	if (x<0.6744897501961370)
	{
		if (x<0.3186393639644102)
			{if (x>=0.1573106846101825) s++; return s;}
		else
			{s+=2; if (x>=0.4887764111147070) s++; return s;}
	}
	else
	{
		s+=4;
		if (x<1.1503493803761058)
			{if (x>=0.8871465590189737) s++; return s;}
		else
			{s+=2; if (x>=1.5341205443525574) s++; return s;}
	}
}

static double ndadc[49][16][16];
static int64_t ndacount[49][16][16];
static int64_t ndalast[16];

static void
donibble(int n, int64_t pos)
{
	int i;
	for (i=0; i<16; i++)
		{long d=pos-ndalast[i]; if (d>48) d=0; ndacount[d][i][n]++;}
	ndalast[n]=pos;
}

static void
mkexpectnda(int64_t size, double expectnda[])
{
	int i;
	double p=1.0, x;

	for (i=1; i<=48; i++) {x=p*(1.0/16.0); expectnda[i]=x; p-=x;}
	expectnda[0]=p;
	p=(double)size/16.0-1.0;
	for (i=0; i<=48; i++) expectnda[i]*=p;
}

static void
printnda(int64_t size)
{
	double expectnda[50], pvs[3];
	double t=0.0, pv, extreme;
	int i, j, k, exi, exj, exk, exd;

	printf("Nearest distance analysis =====================\n");

	mkexpectnda(size, expectnda);

	t = 0.0; extreme = 999.0; exi=exj=exk = -1; exd = '?';
	for (i=0; i<16; i++) for (j=0; j<16; j++)
	{
		uint64_t tot=0;
		for (k=48; k>=0; k--) tot += ndacount[k][i][j];
		for (k=1; k<=48; k++)
		{
			uint64_t x=ndacount[k][i][j];
			double y=sumbino(tot, x, 1.0/16.0), z = tot*(1.0/16.0);

			if (y<extreme)
			{
				extreme=y; exi=i; exj=j; exk=k;
				if (x>z) exd='+'; else exd='-';
			}
			ndadc[k][i][j] = (x-z) / sqrt(z);
			tot-=x;
		}
	}
	pvs[0] = pco_scale(extreme, 16*16*48);
	printf("extreme = %.3g   (%d %d %d %c)  (p = %.3g)\n",
		extreme, exi, exj, exk, exd, pvs[0]);

	for (i=48; i>=0; i--) butterfly(&(ndadc[i][0][0]), &(ndadc[i][8][0]));
	extreme = -1.0;
	for (i=48; i>=0; i--) for (j=0; j<16; j++) for (k=0; k<16; k++)
	{
		t = fabs(ndadc[i][j][k]);
		if (t>extreme) {extreme = t; exi = i; exj = j; exk = k;}
	}

	extreme /= 16.0;
	printf("transform = %.3g   (%d %x %x)  ", extreme, exi, exj, exk);
	extreme = erfc(M_SQRT1_2*extreme);
	pvs[1] = pco_scale(extreme, 16*16*48);
	printf("(p = %.3g)\n", pvs[1]);

	pv = pcombo(pvs, 2);
	printf("One sided p-value (very small numbers are bad):\n");
	printf("%c = %.3g\n", pchar, pv);

	appendpv(pv);

	printf("End nearest distance analysis =====================\n\n");
}

/* end nda */


/* self-correlation */

static double corr[64];

static void
docorr(double *p)
{
	double x= *p;
	int i;

	for (i= -64; i<0; i++) (corr+64)[i]+=p[i]*x;
}

static void
printcorr(int64_t size)
{
	int i, clow[3], chigh[3];
	double low[3], high[3], s=0.0, ss=0.0, pv;

	printf("Self correlation =====================\n");
	size-=1024;
	if (size<256) goto ret;

	low[0]=low[1]=low[2]=1e30;
	high[0]=high[1]=high[2]= -1e30;

	for (i=0; i<64; i++)
	{
		double x=corr[i]/sqrt((double)size);

		printf("%8.3f ", x);
		if ((i&7)==7) putchar('\n');

		if (x>high[2])
		{
			high[2]=x; chigh[2]=i;
			if (x>high[1])
			{
				high[2]=high[1]; chigh[2]=chigh[1];
				high[1]=x; chigh[1]=i;
				if (x>high[0])
				{
					high[1]=high[0]; chigh[1]=chigh[0];
					high[0]=x; chigh[0]=i;
				}
			}
		}
		if (x<low[2])
		{
			low[2]=x; clow[2]=i;
			if (x<low[1])
			{
				low[2]=low[1]; clow[2]=clow[1];
				low[1]=x; clow[1]=i;
				if (x<low[0])
				{
					low[1]=low[0]; clow[1]=clow[0];
					low[0]=x; clow[0]=i;
				}
			}
		}
		s+=x; ss+=x*x;
	}

	for (i=0; i<3; i++) {chigh[i]=64-chigh[i]; clow[i]=64-clow[i];}

	printf("\nmean=%f\n", s/64.0);
	printf("sd  =%f\n", sqrt(ss/64.0-s*s/4096.0));
	printf("high=%f (%d) %f (%d) %f (%d)\n",
		high[0], chigh[0], high[1], chigh[1], high[2], chigh[2]);
	printf("low =%f (%d) %f (%d) %f (%d)\n",
		low[0], clow[0], low[1], clow[1], low[2], clow[2]);

	pv = -low[0]; if (high[0]>pv) pv=high[0];
	pv=erfc(M_SQRT1_2*pv)*0.5;
	pv = pco_scale(pv, 128.0);

	printf("One sided p-value (very small numbers are bad):\n");
	printf("%c = %.3g\n", pchar, pv);

	appendpv(pv);

	ret:
	printf("End self correlation =====================\n\n");
}

/* end self-correlation */


/* blocks */

static double blockstat[10][4];

static const double sdstat[10][4]=
{
	{1.42, 3.3, 32, 370},
	{1.42, 3.0, 27, 280},
	{1.42, 2.9, 25, 220},
	{1.42, 2.8, 23, 180},
	{1.42, 2.8, 22, 160},
	{1.42, 2.8, 22, 150},
	{1.42, 2.8, 21, 140},
	{1.42, 2.8, 21, 139},
	{1.42, 2.8, 21, 139},
	{1.42, 2.8, 21, 139}
};

static void
block16(double b[16], double s[4])
{
	double x, t, s0=0.0, s1= -16.0, s2=0.0, s3= -48.0;
	int i;

	for (i=0; i<16; i++)
	{
		x=b[i]; s0+=x;
		t=x*x; s1+=t;
		t*=x; s2+=t;
		t*=x; s3+=t;
	}

	s[0]=s0; s[1]=s1; s[2]=s2; s[3]=s3;

	blockstat[0][0] += s0*s0;
	blockstat[0][1] += s1*s1;
	blockstat[0][2] += s2*s2;
	blockstat[0][3] += s3*s3;
}

static void
blockn(double b[], double s[4], int sz, int lv)
{
	double s2[4], t;

	lv--;
	if (lv<=0) {block16(b, s); block16(b+16, s2);}
	else
	{
		sz >>= 1;
		blockn(b, s, sz, lv); blockn(b+sz, s2, sz, lv);
	}
	lv++;
	t=s[0]+s2[0]; s[0]=t; blockstat[lv][0]+=t*t;
	t=s[1]+s2[1]; s[1]=t; blockstat[lv][1]+=t*t;
	t=s[2]+s2[2]; s[2]=t; blockstat[lv][2]+=t*t;
	t=s[3]+s2[3]; s[3]=t; blockstat[lv][3]+=t*t;
}

static void
blocks(double b[8192])
{
	double s[4];
	blockn(b, s, 8192, 9);
}

static void
printblocks(int64_t size)
{
	double tblockstat[10][4];
	double p[4], max[4], s, pc;
	int i, j, b;

	printf("Blocks =====================\n");

	size &= ~((int64_t)8191);
	s=1.0/size;

	for (i=0; i<10; i++) for (j=0; j<4; j++)
		tblockstat[i][j] = blockstat[i][j] * s;

	for (i=0; i<10; i++)
	{
		tblockstat[i][0]-=1.0; tblockstat[i][1]-=2.0;
		tblockstat[i][2]-=15.0; tblockstat[i][3]-=96.0;
	}

	s=sqrt((double)size)*0.25;
	for (i=0; i<10; i++)
	{
		for (j=0; j<4; j++) tblockstat[i][j] *= s;
		s*=M_SQRT1_2;
	}

	for (i=0; i<10; i++) for (j=0; j<4; j++) tblockstat[i][j]/=sdstat[i][j];

	printf("%4s  %12s %12s %12s %12s\n",
		"size", "mean", "variance", "3rd moment", "4th moment");
	b=16;
	for (i=0; i<10; i++)
	{
		printf("%4d  ", b); b+=b;
		for (j=0; j<4; j++) printf("%12.6f ", tblockstat[i][j]);
		putchar('\n');
	}

	for (j=0; j<4; j++)
	{
		s=fabs(tblockstat[0][j]);
		for (i=1; i<10; i++)
			{double t=fabs(tblockstat[i][j]); if (t>s) s=t;}
		max[j]=s;
	}
	printf("%4s  ", "max");
	for (j=0; j<4; j++) printf("%12.6f ", max[j]);
	putchar('\n');

	printf("%4s  ", "p");
	for (j=0; j<4; j++)
	{
		p[j] = pco_scale(erfc(M_SQRT1_2*max[j])*0.5, 10);
		printf("%12.3g ", p[j]);
	}
	putchar('\n');
	pc=pcombo(p, 4);
	printf("One sided p-value (very small numbers are bad):\n");
	printf("%c = %.3g\n", pchar, pc);
	appendpv(pc);

	printf("End blocks =====================\n\n");
}

/* end blocks */

static time_t tstart;

/* Overall summary */
static void
printsum(int64_t n, int final)
{
	time_t tm;
	int badness[23], j, worse;

	printf("\n=====================\ncompleted %d tests\n", pvalp);
	for (j=0; j<22; j++) badness[j]=0;
	for (j=0; j<pvalp; j++)
	{
		double d=pval[j], b=0.1;
		int k=0;

		while (d<b && k<20) {b*=0.1; k++;}
		if (d==0.0) k=21;
		badness[k]++;
	}

	printf("%d out of %d tests ok.\n", badness[0], pvalp);
	worse=pvalp-badness[0];

	for (j=1; j<22; j++) if (badness[j])
	{
		static const int badmax[7][2]=
		{
			{99, 99},
			{4, 10},
			{1, 3},
			{0, 1},
			{0, 1},
			{0, 1},
			{0, 1}
		};
		const char *msg;

		if (j>6 || worse>badmax[j][1]) msg="(SERIOUSLY BAD)";
		else if (worse>badmax[j][0]) msg="(slightly bad)";
		else msg="(probably ok)";

		printf("%d grade %d failures %s.\n", badness[j], j, msg);

		worse-=badness[j];
	}

	tm = time(0);
	printf("\nprocessed %.2g numbers in %.3g seconds. %s\n",
		(double)n, (double)(tm-tstart), ctime(&tm));

	if (!final) printf("progress ");

	printf("one sided P value (very small numbers are bad)\n");
	printf("%c = %.3g\n", "pP"[final], pcombo(pval, pvalp));
	if (!final) printf("------\n\n");
}

/* end overall summary */

static void
doan(int64_t count, int final)
{
	pvalp = 0;
	pchar = "pP"[final];

	printlows();
	printmoments(count);
	printchis(count);
	printnda(count);
	printcorr(count);
	printblocks(count);

	printsum(count, final);
}


static void
readstuff(int64_t max, int progress)
{
	static int64_t progsize[]=
	{
		1500000,
		2000000,
		3000000,
		5000000,
		7000000,
		10000000,
		0
	};
	int64_t r=0, nextp=progsize[0];
	double buffer[64+8192], * const b=buffer+64;
	int first=1, progi=0;

	while (max<0 || r<max)
	{
		int i;
		int c, t;
		t=8192; if (max>0 && t>max-r) t=max-r;
		c=fread(b, sizeof(double), t, stdin);
		if (c==0) break;
		if (c<0) crash("fread fails");

		for (i=0; i<c; i++)
		{
			double x = b[i];
			uchi(x);
			ulb(lbucket3, (double)(1<<3), x);
			ulb(lbucket17, (double)(1<<17), x);
			ulb(lbucket31, (double)(1<<31), x);
			umoments(x);
			donibble(tohextile(x), r+i);
		}

		if (!first) for (i=0; i<c; i++) docorr(b+i);
		for (i=0; i<64; i++) buffer[i]=(b+c-64)[i];
		first=0;

		if (c==8192) blocks(b);

		r+=c;

		if (progress && r>nextp)
		{
			doan(r, 0);
			progsize[progi++] *= 10;
			nextp = progsize[progi];
			if (nextp==0) {progi = 0; nextp = progsize[0];}
		}
	}

	if (max>0 && r<max)
		printf("Warning: expected %.0f variates, saw only %.0f\n\n",
			(double)max, (double)r);
	else printf("Successfully read %.0f variates.\n\n", (double)r);

	doan(r, 1);
}

static void
init(GJRAND_NO_ARGS)
{
	int i, j;

	for (i=0; i<64; i++) corr[i]=0.0;
	for (i=0; i<10; i++) for (j=0; j<4; j++) blockstat[i][j]=0.0;
	chimul[0] = 1;
	for (j=1; j<=8; j++)
		chimul[j] = (double)chisplit[j]/(chithres[j]-chithres[j-1]);
	memset(chibucket, 0, sizeof(chibucket));
	memset(lbucket3, 0, sizeof(lbucket3));
	memset(lbucket17, 0, sizeof(lbucket17));
	memset(lbucket31, 0, sizeof(lbucket31));
	for (i=0; i<=10; i++) moments[i] = 0.0;
	memset(ndalast, 0, sizeof(ndalast));
	memset(ndacount, 0, sizeof(ndacount));
}

static void
usage(GJRAND_NO_ARGS)
{
	crash("zero or one args. Variates are read from stdin.\n"
		  "--tiny          1M variates\n"
		  "--small         10M variates\n"
		  "--standard      100M variates\n"
		  "--big           1G variates\n"
		  "--huge          10G variates\n"
		  "--even-huger    100G variates\n"
		  "--tera          1T variates\n"
		  "otherwise read until end of file.\n");
}

#define K ((int64_t)1024)
#define M (K*K)
#define G (K*M)
#define TERA (K*G)

#define TINY (M)
#define SMALL (10*M)
#define STANDARD (100*M)
#define BIG (G)
#define REALLYHUGE (10*G)
#define HUGER (100*G)

int
main(int argc, char **argv)
{
	int64_t c=(int64_t)(-1);
	int progress=0, j;

	init();

	for (j=1; j<argc; j++)
	{
		if (strcmp(argv[j], "--tiny")==0) c=TINY;
		else if (strcmp(argv[j], "--small")==0) c=SMALL;
		else if (strcmp(argv[j], "--standard")==0) c=STANDARD;
		else if (strcmp(argv[j], "--big")==0) c=BIG;
		else if (strcmp(argv[j], "--huge")==0) c=REALLYHUGE;
		else if (strcmp(argv[j], "--even-huger")==0) c=HUGER;
		else if (strcmp(argv[j], "--tera")==0) c=TERA;
		else if (strcmp(argv[j], "--progress")==0) progress=1;
		else usage();
	}

	printf("*** bigpdb version 8");
	if (argc==2) printf(" %s", argv[1]);
	printf(" ***\n");

	tstart = time(0);
	printf("Starting at %s\n", ctime(&tstart));

	readstuff(c, progress);

	return 0;
}
