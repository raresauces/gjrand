#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Numerically integrate f from lo to hi. Romberg's method. */
/* Relies on f being "well-behaved". */

#define MUL (1<<3)
#define WID (1.0L/MUL)

static long double
f(long double x) {return expl(x * x * -0.5L);}

static long double
gjrt_integrate(long double lo, long double hi, int l)
{
        long double pt[257], app1[9], app2[9], *in=app1, *out=app2, *tp,
                sc, t, m1, m2;
        int j, k, c, s;

        if (l>8) l = 8;
        if (l<0) l = 0;

        c = 1<<l;
        sc = (hi-lo)/c;

        for (j=c; j>=0; j--) pt[j] = f(j*sc+lo);
        pt[0] = (pt[c]+pt[0]) * 0.5L;

        s = c;
        for (j=0; j<=l; j++)
        {
                t = 0.0;
                for (k=0; k<c; k+=s) t += pt[k];
                in[j] = t * s / c;
                s >>= 1;
        }

        sc = 4.0L;
        while (l>0)
        {
                m2 = 1.0L/(sc-1.0L); m1 = sc * m2;
                for (j=0; j<l; j++) out[j] = in[j+1]*m1 - in[j]*m2;
                tp = in; in = out; out = tp;
                sc *= 4.0L;
                l--;
        }

        return fabs(hi-lo) * in[0];
}

static long double
sum(long double lo, long double hi)
{
	long double r=0.0;
	int j;

	for (j=16*MUL; j>0; j--)
	{
		r += gjrt_integrate(lo+(j-1)*WID, hi+(j-1)*WID, 4);
		r += gjrt_integrate(lo-j*WID, hi-j*WID, 4);
	}

	return r;
}

long double sums[65536];

int
main()
{
	long double lo, hi;
	int j, k;

	for (j=65535; j>=0; j--)
	{
		lo = j*(WID/65536.0L);
		hi = (j+1)*(WID/65536.0L);
		sums[j] = sum(lo, hi);
	}

	lo = 1e30; hi = -1e30;
	for (j=65535; j>=0; j--)
	{
		if (sums[j]>hi) hi = sums[j];
		if (sums[j]<lo) lo = sums[j];
	}

	printf("lo = %.6g ; hi = %.6g ; diff = %.6g\n",
		(double)lo, (double)hi, (double)(hi-lo));

	for (j=0; j<8192; j++)
	{
		lo = 0.0L;
		for (k=8*j; k<8*j+8; k++) lo += sums[k];
		sums[j] = lo;
	}

	lo = 1e30; hi = -1e30;
	for (j=8191; j>=0; j--)
	{
		if (sums[j]>hi) hi = sums[j];
		if (sums[j]<lo) lo = sums[j];
	}

	printf("lo = %.6g ; hi = %.6g ; diff = %.6g\n",
		(double)lo, (double)hi, (double)(hi-lo));

	for (j=0; j<1024; j++)
	{
		lo = 0.0L;
		for (k=8*j; k<8*j+8; k++) lo += sums[k];
		sums[j] = lo;
	}

	lo = 1e30; hi = -1e30;
	for (j=1023; j>=0; j--)
	{
		if (sums[j]>hi) hi = sums[j];
		if (sums[j]<lo) lo = sums[j];
	}

	printf("lo = %.6g ; hi = %.6g ; diff = %.6g\n",
		(double)lo, (double)hi, (double)(hi-lo));

	for (j=0; j<128; j++)
	{
		lo = 0.0L;
		for (k=8*j; k<8*j+8; k++) lo += sums[k];
		sums[j] = lo;
	}

	lo = 1e30; hi = -1e30;
	for (j=127; j>=0; j--)
	{
		if (sums[j]>hi) hi = sums[j];
		if (sums[j]<lo) lo = sums[j];
	}

	printf("lo = %.6g ; hi = %.6g ; diff = %.6g\n",
		(double)lo, (double)hi, (double)(hi-lo));

	for (j=0; j<16; j++)
	{
		lo = 0.0L;
		for (k=8*j; k<8*j+8; k++) lo += sums[k];
		sums[j] = lo;
	}

	lo = 1e30; hi = -1e30;
	for (j=15; j>=0; j--)
	{
		if (sums[j]>hi) hi = sums[j];
		if (sums[j]<lo) lo = sums[j];
	}

	printf("lo = %.6g ; hi = %.6g ; diff = %.6g\n",
		(double)lo, (double)hi, (double)(hi-lo));


	return 0;
}
