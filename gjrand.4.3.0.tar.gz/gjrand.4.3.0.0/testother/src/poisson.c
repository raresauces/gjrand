/* Test software for gjrand random numbers version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"
#include "../../testcommon/lgamma.h"

/* Chi-squared test for gjrand_poisson. */

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

typedef int (fishfun)(struct gjrand *s, double t);
static fishfun fish;
static fishfun fakefish;

/* calculate poisson distribution using gjrand_exponential */
static int
fish(struct gjrand *s, double t)
{
	int r = -1;
	do {r++; t -= gjrand_exponential(s);} while (t>0.0);
	return r;
}

static long coins;

/* calculate approximate poisson distribution using gjrand_biased_coins */
/* Note that the test will likely fail for small coins and/or large count. */
/* Also coins really has to be greater than t. */
static int
fakefish(struct gjrand *s, double t)
	{return gjrand_biased_coins(s, t/coins, coins);}

#define MAX 50000
static int offset;
static long histo[MAX+1];
static double sum=0.0, ss=0.0, sc=0.0;

static void
dofish(long count, struct gjrand *s, double t, fishfun *ff)
{
	int i, j;

	for (i=0; i<=MAX; i++) histo[i]=0;
	do
	{
		double x, y;

		j = (*ff)(s, t);
		x = j-t; sum += x;
		y = x*x; ss += y;
		y *= x; sc += y;
		j -= offset;
		if ((unsigned)j>(unsigned)MAX) j = MAX;
		histo[j]++;
		count--;
	} while (count>0);
}

static double ex[MAX+1];

static void
mkexpect(long count, double t)
{
	double p, dc=count, lt=log(t), x;
	int j, jo;

	for (j=0; j<MAX; j++)
	{
		jo = j+offset;
		if (jo<0) x = 0.0; else x = exp(lt*jo - logfac(jo) - t) * dc;
		ex[j] = x;
	}
	p = 0;
	for (j=0; j<MAX; j++) p += ex[j];
	ex[MAX] = dc-p;
}

static int
aggregate(GJRAND_NO_ARGS)
{
	int j, df=0;
	double t=0.0;
	long tl=0;

	for (j=0; j<MAX; j++)
		if (ex[j]<5.0)
			{t += ex[j]; tl += histo[j]; ex[j] = 0.0; histo[j] = 0;}
		else df++;

	ex[MAX] += t;
	histo[MAX] += tl;

	return df;
}

static void
doan(long count, double t)
{
	int i, df;
	double r=0.0, p;

	mkexpect(count, t);
	df = aggregate();

for (i=0; i<MAX; i++) if (histo[i])
printf("%10d: %20.9f %10ld\n", i+offset, ex[i], histo[i]);
printf("         X: %20.9f %10ld\n", ex[MAX], histo[MAX]);

	if (ex[MAX]>0.5)
		r=(ex[MAX]-histo[MAX])*(ex[MAX]-histo[MAX])/ex[MAX];
	else {r=0.0; df--;}
	for (i=0; i<MAX; i++) if (ex[i]>0.1)
		r+=(ex[i]-histo[i])*(ex[i]-histo[i])/ex[i];
	p = chi2p1(r, df);
	printf("chis = %f     df = %d     P = %.3g\n\n", r, df, p);
	printf("mean discr = %f ; var = %f ; skew = %f\n",
		sum/count, ss/count, sc/ss);
}

int
main(int argc, char **argv)
{
	fishfun *ff=0;
	double t;
	long count, seed;
	struct gjrand s;
	int j=0;

	if (argc<4) crash(
"3 4 or 5 args:\n"
"	-[ep] interval count [ seed ]\n"
"	-c coins interval count [ seed ]\n"
);
	if (strcmp(argv[1], "-e")==0) ff = &fish;
	else if (strcmp(argv[1], "-p")==0) ff = &gjrand_poisson;
	else if (strcmp(argv[1], "-c")==0)
	{
		ff = &fakefish;
		if (sscanf(argv[2], "%ld", &coins)!=1)
			crash("coins not a number");
		j++;
	}
	else crash("arg 1 must be -e or -p or -c");
	if (sscanf(argv[j+2], "%lf", &t)!=1) crash("interval not a number");
	if (sscanf(argv[j+3], "%ld", &count)!=1) crash("count not a number");
	if (argc>j+4)
	{
		if (sscanf(argv[j+4], "%ld", &seed)!=1)
			crash("seed not a number");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	offset = t-MAX/2;

	dofish(count, &s, t, ff);
	doan(count, t);

	return 0;
}
