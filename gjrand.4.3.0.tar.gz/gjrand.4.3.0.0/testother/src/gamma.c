/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"
#include "../../testcommon/lgamma.h"
#include "../../testcommon/integ2.h"

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static int64_t histo[4];
static double expect[4];
static double mean, sd, split[3];

static double norm, expon;

/* Lower incomplete gamma function. */
/* This series spotted on wikipedia "Incomplete gamma function" March 2010 */
/* and referenced to */
/* http://algolist.manual.ru/maths/count_fast/gamma_function.php */
/* (which i didn't follow). It appears to be accurate and reasonably */
/* fast for small values of scale and x, unlike the numerical integration */
/* below which is useless for scale<0.3 . In the form given it is probably */
/* not much good for very large shape, or very large x. */
static double
lincgamma(double x, double shape, double scale, double prec)
{
	double term, r=0, j=shape;

	x /= scale; term = 1/j;
	while (1)
	{
		r += term;
		if (r*prec > term) return exp(log(x)*shape - x) * r;
		j++; term *= x/j;
	}
}

static double
myfun(double x) {return exp(log(x)*expon - x - norm);}

static void
mkexpect(double shape, double scale, double count)
{
	double prec = 0.01/count;
	int j;

	norm = lngamma(shape);
	if (shape>=1)
	{
		expon = shape-1;
		expect[1] = gjrt_integrate(myfun,
			split[0]/scale, split[1]/scale, 8);
		expect[2] = gjrt_integrate(myfun,
			split[1]/scale, split[2]/scale, 8);
		expect[3] = gjrt_integ2(myfun,
			split[2]/scale, shape/32/scale, prec, 8);
		expect[0] = 1 - expect[3] - expect[2] - expect[1];
		for (j=0; j<4; j++) expect[j] *= count;
	}
	else
	{
		norm = count / exp(norm);
		for (j=0; j<3; j++)
		    expect[j] = lincgamma(split[j], shape, scale, prec) * norm;
		expect[3] = count - expect[2];
		expect[2] -= expect[1];
		expect[1] -= expect[0];
	}
}

static void
doan(double shape, double scale, double count)
{
	double x, t, c=0, p, sig;
	double xmean = shape*scale;
	double xsd = shape*scale*scale;
	int j;
	xsd = sqrt(xsd);

	mkexpect(shape, scale, count);

	mean /= count;
	sd = sqrt(sd/count);

	for (j=0; j<4; j++)
	{
printf("expect = %12.5e    see = %12.5e", expect[j], (double)(histo[j]));
		if (j==3) putchar('\n');
		else printf("    upper = %12.5e\n", split[j]);
	}

	for (j=0; j<4; j++) {x = expect[j]; t = histo[j]-x; c += t*t/x;}
	p = chi2p2(c, 3);
	printf("chis = %.3f ; df = 3 ; p = %.3g\n", c, p);
	if (shape<0.01) printf(
"Ignore above, the probability calculation is all wrong when shape<0.01 .\n"
"Stuff below should be mostly ok?\n\n");

	sig = sqrt(count)*mean/xsd;
	p = erfc(fabs(M_SQRT1_2*sig));
	printf("mean = %.6f ; expect = %.6f ; %.3f sigma ; p = %.3g\n",
		mean+xmean, xmean, sig, p);

	printf("sdev = %.6f ; expect = %.6f\n", sd, xsd);
}

static void
dog(struct gjrand *g, int type, double shape, double scale, int64_t count)
{
	double xmean = shape*scale;
	double s=0, ss=0, x;
	int j, si=shape;

	memset(histo, 0, sizeof(histo));

	while (count>0)
	{
		x = (type=='e') ? gjrand_erlang(g, si, scale)
			: gjrand_gamma(g, shape, scale);
		j = (x>split[1])*2;
		j += x>split[j];
		histo[j]++;
		x -= xmean;
		s += x; ss += x*x;
		count--;
	}

	mean = s; sd = ss;
}

int
main(int argc, char **argv)
{
	struct gjrand s;
	double count, shape, scale, t;
	long seed;
	int j, type;

	if (argc<5) crash("4 or 5 args: type shape scale count [ seed ]");
	type = argv[1][0];
	if (type!='g' && type!='e')
		crash("type must be e for erlang or g for gamma");
	if (sscanf(argv[2], "%lf", &shape)!=1 || shape<=0)
		crash("shape must be a number > 0");
	if (sscanf(argv[3], "%lf", &scale)!=1 || scale<=0)
		crash("scale must be a number > 0");
	if (sscanf(argv[4], "%lf", &count)!=1 || count<=30)
		crash("count must be a number > 30");
	if (argc>5)
	{
		if (sscanf(argv[5], "%ld", &seed)!=1)
			crash("seed not a number");
		gjrand_init64(&s, seed);
	}
	else gjrand_initrand(&s);

	if (type=='e') shape = (int)(shape+0.5);

	for (j=0; j<3; j++) split[j] = gjrand_gamma(&s, shape, scale);
	if (split[1]<split[0])
		{t = split[1]; split[1] = split[0]; split[0] = t;}
	if (split[2]<split[1])
		{t = split[2]; split[2] = split[1]; split[1] = t;}
	if (split[1]<split[0])
		{t = split[1]; split[1] = split[0]; split[0] = t;}

	dog(&s, type, shape, scale, (int64_t)count);
	doan(shape, scale, count);

	return 0;
}
