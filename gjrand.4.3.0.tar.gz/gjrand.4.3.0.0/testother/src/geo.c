/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static uint64_t histo[1000];
static double expect[1000];

static void
dostuff(struct gjrand *s, double p, int64_t c)
{
	int64_t j;
	int k;

	for (j=0; j<c; j++)
	{
		k = gjrand_geometric(s, p);
		if (k<0) k = 0; else if (k>999) k = 999;
		histo[k]++;
	}
}

static void
mkexpect(double p, int64_t c)
{
	double t=c;
	int j;

	expect[0] = 0;
	for (j=1; j<999; j++) {expect[j] = t*p; t *= 1-p;}
	expect[999] = t;
}

static void
doan(double p, int64_t c)
{
	double x, t, ch, pv;
	uint64_t h;
	int j, max;

	mkexpect(p, c);
	for (j=0; j<1000; j++) if (histo[j] || expect[j]>0.9)
		printf("%3d : expect %15.2f ; get %12.0f\n",
			j, expect[j], (double)(histo[j]));
	if (histo[0]) crash("nonzero count for 0");

	h = histo[999]; x = expect[999];
	expect[0] = 999;
	for (max = 998; expect[max]<8; max--)
		{h += histo[max]; x += expect[max];}
	if (max<=1) crash("not enough data for chisquared");
	histo[max] = h; expect[max] = x;

	ch = 0;
	for (j=1; j<=max; j++) {x = expect[j]; t = x-histo[j]; ch += t*t/x;}
	max--;
	pv = chi2p2(ch, max);
	printf("chis = %.2f ; df = %d ; p = %.3g\n", ch, max, pv);
}

int
main(int argc, char **argv)
{
	struct gjrand s;
	double p, e;
	int64_t count;
	unsigned long seed;

	if (argc!=3 && argc!=4) crash("usage: geo count prob [ seed ]");
	if (sscanf(argv[1], "%lf", &e)!=1) crash("count not a number");
	count = e;
	if (sscanf(argv[2], "%lf", &p)!=1 || p<=0 || p>=1)
		crash("prob not a number or out of range (0 1)");
	if (argc==4)
	{
		if (sscanf(argv[3], "%lu", &seed)!=1)
			crash("seed not a number");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	memset(histo, 0, sizeof(histo));
	dostuff(&s, p, count);
	doan(p, count);

	return 0;
}
