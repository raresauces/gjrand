/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

#define DBG 1

/* Chi-squared test for gjrand_sample(). */

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

#define HSIZE (1<<24)
static int64_t histo[HSIZE];

static int
xtoi(int size, unsigned char a[], int k, unsigned char b[])
{
#ifdef DBG
	int ok=0;
#endif
	int r=0, i;

	k--;
	do
	{
		i = b[k*size];
		if (memcmp(b+k*size, a+i*size, size))
		{
			fprintf(stderr, "a[%d] vs b[%d]\n", i, k);
			crash("memory block copy trashed by gjrand_choose()");
		}
#ifdef DBG
		ok|=i;
#endif
		r=i+8*r;
		k--;
	} while (k>=0);

#ifdef DBG
	if ((ok & (~7))!=0) crash("bad a[] in xtoi");
	if ((r & (~(HSIZE-1))) !=0) crash("bad r in xtoi");
#endif

	return r;
}

static int
toi(int size, int a[])
{
#ifdef DBG
	int ok=0;
#endif
	int r=0, i;

	size--;
	do
	{
		i=a[size];
#ifdef DBG
		ok|=i;
#endif
		r = i+8*r;
		size--;
	} while (size>=0);

#ifdef DBG
	if ((ok & (~7))!=0) crash("bad a[] in toi");
	if ((r & (~(HSIZE-1))) !=0) crash("bad r in toi");
#endif

	return r;
}

static int64_t tot;

static double
leaf(int a[], int size, double e)
{
	int64_t x=histo[toi(size, a)];

	tot+=x;
	e-=x;
	return e*e;
}

static double
permute(int a[], int n, int k, int i, double e)
{
	int j;
	double r;

	if (i>=k) return leaf(a, k, e);

	r=0.0;
	for (j=0; j<n; j++)
	{
		a[i]=j;
		r+=permute(a, n, k, i+1, e);
	}

	return r;
}

static void
dochisquare(int n, int k, int64_t count)
{
	double e, cs, p;
	int j, df;
	int a[9]; /* MUDFLAP */

	df = 1;
	for (j=k; j>0; j--) df *= n;
	e = ((double)count)/df;
	if (e<10.0)
		fprintf(stderr, "warning counts quite low, don't trust chisquared\n");
	df--;
	tot=0;
	cs=permute(a, n, k, 0, e)/e;
	if (tot!=count) fprintf(stderr, "some missing numbers\n");
	p = chi2p2(cs, df);
	printf("chis = %f     df = %d     P = %.3g\n", cs, df, p);
}

static void
doshuffle(int size, int n, int k, int64_t count, struct gjrand *s)
{
	int64_t i;
	unsigned char a[16384], b[6144];

	memset(histo, 0, sizeof(histo));

	gjrand_randbytes(s, 16384, a);
	for (i=0; i<n; i++) a[i*size] = i;

	for (i=0; i<count; i++)
	{
		gjrand_sample(s, size, n, a, k, b);
		histo[xtoi(size, a, k, b)]++;
	}

	dochisquare(n, k, count);
}

int
main(int argc, char **argv)
{
	struct gjrand s;
	double dcount;
	int64_t repcount;
	int size, n, k, seed;

	if (argc<5) crash("4 or 5 args: incount outcount esize repcount [ seed ]");
	if (sscanf(argv[1], "%d", &n)!=1) crash("incount not a number");
	else if (n<2 || n>8) crash("must have 2 <= incount <= 8");
	if (sscanf(argv[2], "%d", &k)!=1) crash("outcount not a number");
	else if (k<2 || k>8) crash("must have 2 <= outcount <= 8");
	if (sscanf(argv[3], "%d", &size)!=1) crash("esize not a number");
	else if (size<1 || size>1024) crash("must have 1 <= size <= 1024");
	if (sscanf(argv[4], "%lf", &dcount)!=1) crash("repcount not a number");
	else if (dcount>9.1e18) crash("count too big");
	if (argc>5)
	{
		if (sscanf(argv[5], "%d", &seed)!=1) crash("seed not a number");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	repcount = (int64_t)dcount;
	doshuffle(size, n, k, repcount, &s);

	return 0;
}
