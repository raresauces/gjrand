/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static uint64_t histo[10];
static double bound[11];
static double money[10];

static void
doan(double count)
{
	double x=count*0.1, t, c=0, p, tm=0;
	int j;

	for (j=9; j>=0; j--) tm += money[j];
	tm *= 0.01;

	for (j=0; j<10; j++)
	    printf("%11.5g to %11.5g expect %11.0f see %11.0f %%money %8.4f\n",
		bound[j], bound[j+1], x, (double)(histo[j]), money[j]/tm);

	for (j=0; j<10; j++)
	{
		t = x-histo[j];
		c += t*t;
	}
	c /= x;
	p = chi2p1(c, 9);
	printf("\nchis = %.4f ; df = 9 ; p = %.3g\n", c, p);
}

static void
dostuff(struct gjrand *s, int64_t count, double min, double shape)
{
	double x;
	int j;

	do
	{
		x = gjrand_pareto(s, shape, min);
		if (x<bound[0]) crash("too low");
		if (x>=bound[10]) crash("too big");
		for (j=0; j<9; j++) if (x<bound[j+1]) break;
		histo[j]++; money[j] += x;
		count--;
	} while (count>0);
}

int
main(int argc, char **argv)
{
	double count, min, shape;
	unsigned long seed;
	struct gjrand s;
	int j;

	if (argc<4) crash("3 or 4 args: count min shape [ seed ]");
	if (sscanf(argv[1], "%lf", &count)!=1) crash("count not a number");
	if (sscanf(argv[2], "%lf", &min)!=1) crash("min not a number");
	if (min<=0) crash("min must be positive");
	if (sscanf(argv[3], "%lf", &shape)!=1) crash("shape not a number");
	if (shape<=0) crash("shape must be positive");
	if (argc>4)
	{
		if (sscanf(argv[4], "%lu", &seed)!=1)
			crash("seed not a number");
		gjrand_init(&s, (uint32_t)seed);
	}
	else gjrand_initrand(&s);

	memset(histo, 0, sizeof(histo));
	for (j=0; j<10; j++) money[j] = 0;
	bound[0] = min; bound[10] = 1e300;
	for (j=1; j<10; j++) bound[j] = pow((10-j)*0.1, -1.0/shape) * min;

	dostuff(&s, (int64_t)count, min, shape);
	doan(count);

	return 0;
}
