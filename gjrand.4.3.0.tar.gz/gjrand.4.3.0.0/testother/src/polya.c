/* Test software for gjrand random numbers version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"
#include "../../testcommon/lgamma.h"

/* Chi-squared test for gjrand_polya. */

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

#define MAX 10000
static long histo[MAX+1];
static double sum=0.0, ss=0.0;

static void
dostuff(long count, struct gjrand *s, double p, double n)
{
	double mean = n*(1.0-p)/p;
	int i, j;

	for (i=0; i<=MAX; i++) histo[i]=0;
	do
	{
		double x;

		j = gjrand_polya(s, p, n);
		x=j-mean; sum+=x;
		x=x*x; ss+=x;
		if (j>MAX) j=MAX;
		histo[j]++;
		count--;
	} while (count>0);
}

static double ex[MAX+1];

static void
mkexpect(long count, double p, double n)
{
	double q, dc=count, lft, lfnm1=logfac(n-1.0), lfk;
	double lpn=log(p)*n, l1mp=log1p(-p);
	int j, k;

	for (k=0; k<MAX; k++)
	{
		lft = logfac(k+n-1.0); lfk = logfac(k);
		ex[k] = exp(lft - lfnm1 -lfk + lpn + l1mp*k) * dc;
	}

	q = 0;
	for (j=0; j<MAX; j++) q += ex[j];
	ex[MAX] = dc-q;
}

static void
aggregate(int *lo, int *hi)
{
	int i, l, h;
	double t;
	long tl;

	for (l=0; l<MAX; l++) if (ex[l]>5.0) break;
	*lo=l;
	for (h=MAX; h>0; h--) if (ex[h-1]>5.0) break;
	*hi=h;
	if (*lo >= *hi) {fprintf(stderr, "counts too low\n"); exit(1);}

	t=ex[MAX];
	tl=histo[MAX];
	for (i=0; i<l; i++) {t+=ex[i]; tl+=histo[i];}
	for (i=h; i<MAX; i++) {t+=ex[i]; tl+=histo[i];}
	ex[MAX]=t; histo[MAX]=tl;
}

static void
doan(long count, double p, double n)
{
	int i, lo, hi, df;
	double r=0.0, pc;

	mkexpect(count, p, n);
	aggregate(&lo, &hi);

for (i=lo; i<hi; i++)
printf("%3d: %20.9f %10ld\n", i, ex[i], histo[i]);
printf("  X: %20.9f %10ld\n", ex[MAX], histo[MAX]);

	df=hi-lo;
	if (ex[MAX]>0.5)
		r=(ex[MAX]-histo[MAX])*(ex[MAX]-histo[MAX])/ex[MAX];
	else {r=0.0; df--;}
	for (i=lo; i<hi; i++) r+=(ex[i]-histo[i])*(ex[i]-histo[i])/ex[i];
	pc = chi2p1(r, df);
	printf("chis = %f     df = %d     P = %.3g\n\n", r, df, pc);
	printf("mean discr = %f   var = %f\n", sum/count, ss/count);
}

int
main(int argc, char **argv)
{
	double p, n;
	long count, seed;
	struct gjrand s;
	int j=0;

	if (argc<4) crash(
"3 or 4 args:\n"
"	prob nsuccess count [ seed ]\n"
);
	if (sscanf(argv[1], "%lf", &p)!=1) crash("prob not a number");
	if (p<=0.0 || p>=1.0) crash("prob should be in range (0 1)");
	if (sscanf(argv[2], "%lf", &n)!=1) crash("nsuccess not a number");
	if (p<=0.0) crash("nsuccess should be positive");
	if (sscanf(argv[3], "%ld", &count)!=1) crash("count not a number");
	if (argc>4)
	{
		if (sscanf(argv[j+4], "%ld", &seed)!=1)
			crash("seed not a number");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	dostuff(count, &s, p, n);
	doan(count, p, n);

	return 0;
}
