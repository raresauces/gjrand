/* Test software for gjrand random numbers version 3.2.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "../../src/gjrand.h"

static double
px(uint64_t edge, uint64_t mod, uint64_t count)
{
	double r;
	r = ((double)edge)/mod;
	r = log1p(-r);
	r *= count;
	return -expm1(r);
}

static void
domod(uint64_t mod, long count, int how, struct gjrand *s)
{
	uint32_t buf[1024];
	double t, mean=0.0, var=0.0, sig, p;
	double offset=(mod-1)*0.5;
	uint64_t min = -((uint64_t)1), max=0, l;
	long i;
	int k;

	if (how==64) for (i=0; i<count; i++)
	{
		l=gjrand_rand64mod(s, mod);
		if (l>max) max=l;
		if (l<min) min=l;
		t=l; mean+=t; t-=offset; var+=t*t;
	}
	else if (how==32) for (i=0; i<count; i++)
	{
		l=gjrand_rand32mod(s, mod);
		if (l>max) max=l;
		if (l<min) min=l;
		t=l; mean+=t; t-=offset; var+=t*t;
	}
	else
	{
		i = count;
		while (i>0)
		{
			k = 1024; if (k>i) k = i;
			gjrand_rand32modv(s, mod, k, buf);
			while (k>0)
			{
				l = buf[--k];
				if (l>max) max=l;
				if (l<min) min=l;
				t=l; mean+=t; t-=offset; var+=t*t;
			}
			i -= 1024;;
		}
	}

	printf("min = %.0f  (p = %.3g .. %.3g)\n", (double)min,
		px(min, mod, count), px(min+1, mod, count));
	printf("max = %.0f  (p = %.3g .. %.3g)\n", (double)max,
		px(mod-max-1, mod, count), px(mod-max, mod, count));
	mean/=count;
	sig = (mean-offset)*sqrt(count*12.0)/mod;
	p = erfc(fabs(M_SQRT1_2*sig));
	printf("mean = %f (%f sigma ; p = %.3g)\n", mean, sig, p);
	var /= ((double)mod)*mod*count;
	sig = (var-1.0/12.0) * sqrt(count/(1.0/80.0 - 1.0/72.0 + 1.0/144.0));
	p = erfc(fabs(M_SQRT1_2*sig));
	printf("scaled variance  = %f (%f sigma ; p = %.3g)\n", var, sig, p);
}

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

int
main(int argc, char **argv)
{
	double dmod;
	uint64_t mod;
	long count;
	int seed, how=0;
	struct gjrand s;

	if (argc<4) crash("3 or 4 args: how mod count [ seed ]\n"
		"how is one of 32 64 v");
	if (strcmp(argv[1], "32")==0) how = 32;
	else if (strcmp(argv[1], "64")==0) how = 64;
	else if (strcmp(argv[1], "v")==0) how = 0;
	else crash("invalid how : should be 32 64 or v");
	if (sscanf(argv[2], "%lf", &dmod)!=1) crash("mod not a number");
	mod = (uint64_t)dmod;
	if (sscanf(argv[3], "%ld", &count)!=1) crash("count not a number");
	if (argc>4)
	{
		if (sscanf(argv[4], "%d", &seed)!=1) crash("seed not a number");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	if (how!=64 && mod>0xfffffffful) crash("mod too big for 32 bit");

	domod(mod, count, how, &s);

	return 0;
}
