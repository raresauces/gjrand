/* Test software for gjrand random numbers version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "../../src/gjrand.h"

#define MAX 100000

static void
crash(const char *s) {fprintf(stderr,"crash [%s]\n", s); exit(1);}

static void
test(void (*fun)(struct gjrand *, int, double *),
		int dim, unsigned long count, struct gjrand *s)
{
	double point[MAX];
	double mean[MAX], msq[MAX];
	double yd, hi= -1e30, lo=1e30, ssq=0.0;
	unsigned long c;
	int i;

	for (i=0; i<MAX; i++) mean[i]=msq[i]=0.0;

	c=count;
	do
	{
		long double y= -1.0l;
		(*fun)(s, dim, point);
		i=dim-1;
		do
		{
			double x=point[i];
			mean[i]+=x;
			y += ((long double)x) * x;
			x*=x;
			msq[i]+=x;
			i--;
		} while (i>=0);

		yd = ((double)y)*0.5;
		if (yd>hi) hi = yd;
		if (yd<lo) lo = yd;
		ssq += yd*yd;
		c--;
	} while (c);

	printf("radius anomaly max = %12e   min = %12e   rms = %12e\n\n",
		hi, lo, sqrt(ssq/count));
	for (i=0; i<dim; i++)
		printf("%d  %15.12f  %15.12f\n",i,mean[i]/count,msq[i]/count);
}

int
main(int argc, char **argv)
{
	struct gjrand s;
	void (*fun)(struct gjrand *, int, double *);
	char **arg=argv;
	unsigned long seed, count;
	int dim;

	if (argc<3 || argc>5)
		crash("usage: onsphere [ -x ] dim count [ seed ]");

	fun = &gjrand_onsphere;

	if (strcmp(arg[1], "-x")==0)
	{
		fun = &gjrand_onxsphere;
		arg++; argc--;
	}

	if (sscanf(arg[1],"%d",&dim)!=1 || dim<=0)
		crash("arg dim should be a  positive integer");
	if (dim>=MAX) crash("arg dim is too big");
	if (sscanf(arg[2],"%lu",&count)!=1 || count<=0)
		crash("arg count should be an integer > 0");
	if (argc==4)
	{
		if (sscanf(arg[3],"%lu",&seed)!=1)
			crash("third arg seed should be an integer");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	test(fun, dim, count, &s);

	return 0;
}
