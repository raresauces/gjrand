/* Test software for gjrand random numbers version 4.2.0.0 or later. */
/* Copyright (C) 2004-2014 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static uint64_t histo[32*64];

static void
doan(double count)
{
	double x=count/(32*64), t, c=0, p;
	int j;

	for (j=0; j<32*64; j++) {t = histo[j]-x; c += t*t;}
	c /= x;
	p = chi2p1(c, 32*64-1);
	printf("chis = %.2f ; df = %d ; p = %.3g\n", c, 32*64-1, p);
}

static void
dostuff(void (*fun)(struct gjrand *, int, double *),
		int64_t count, struct gjrand *s)
{
	double v[3];
	int j, k;

	do
	{
		(*fun)(s, 3, v);
		j = v[0]*16.0 + 16.0;
		k = atan2(v[1], v[2]) * (32.0/M_PI) + 32.0;
		histo[(j&31)*64 + (k&63)]++;
		count--;
	} while (count>0);
}

int
main(int argc, char **argv)
{
	double count;
	void (*fun)(struct gjrand *, int, double *);
	char **arg=argv;
	unsigned long seed;
	struct gjrand s;

	if (argc<2 || argc>4) crash("usage: onsph3 [-x] count [ seed ]");

	fun = &gjrand_onsphere;

	if (strcmp(arg[1], "-x")==0)
	{
		fun = &gjrand_onxsphere;
		arg++; argc--;
	}
	if (sscanf(arg[1], "%lf", &count)!=1) crash("count not a number");
	if (argc>2)
	{
		if (sscanf(arg[2], "%lu", &seed)!=1) crash("seed not a number");
		gjrand_init(&s, (uint32_t)seed);
	}
	else gjrand_initrand(&s);

	memset(histo, 0, sizeof(histo));
	dostuff(fun, (int64_t)count, &s);
	doan(count);

	return 0;
}
