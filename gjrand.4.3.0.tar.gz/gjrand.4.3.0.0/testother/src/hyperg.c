/* Test software for gjrand random numbers version 4.0.1.0 or later. */
/* Copyright (C) 2004-2013 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static struct gjrand g;

#define MAX 4096
int64_t histo[MAX+4];
double expect[MAX+4];

static void
split(double from[], double to[], int n1, int n2, int sam)
{
	double x, p;
	int j;

	for (j=0; j<=sam; j++) to[j] = 0;
	for (j=0; j<sam; j++)
	{
		x = from[j];
		p = ((double)(n1-j)) / (n2-sam+1);
		to[j+1] += p*x; to[j] += (1-p)*x;
	}
}

static void
mkexpect(int64_t count, int n1, int n2, int sam)
{
	double tx[MAX+4], *pa=expect, *pb=tx, *pt;
	int j;

	n2 += n1;
	pa[0] = count;
	for (j=1; j<=sam; j++) pa[j] = 0;
	for (j=1; j<=sam; j++)
		{split(pa, pb, n1, n2, j); pt = pa; pa = pb; pb = pt;}
	if (pa!=expect) for (j=0; j<=sam; j++) expect[j] = pa[j];
}

static void
doan(int64_t count, int n1, int n2, int sam)
{
	double xa, x, t, c;
	int64_t ha;
	int hi, lo, j;

	mkexpect(count, n1, n2, sam);

for (j=0; j<=sam; j++) if (histo[j] || expect[j]>0.9)
printf("hg = %4d ; expect = %15.2f ; histo = %12.0f\n",
		j, expect[j], (double)histo[j]);

	xa = 0; ha = 0;
	hi = sam;
	while (expect[hi]<10)
	{
		if (hi<=0) crash("not enough data for chisquared");
		xa += expect[hi]; ha += histo[hi];
		hi--;
	}
	expect[hi] += xa; histo[hi] += ha;

	xa = 0; ha = 0;
	lo = 0;
	while (expect[lo]<10) {xa += expect[lo]; ha += histo[lo]; lo++;}
	expect[lo] += xa; histo[lo] += ha;

	c = 0;
	for (j=lo; j<=hi; j++) {x = expect[j]; t = x - histo[j]; c += t*t/x;}

	printf("chisquared = %.4f ; df = %d ; p = %.3g\n",
		c, hi-lo, chi2p2(c, hi-lo));
}

static void
dostuff(int64_t count, int n1, int n2, int sam)
{
	int j;

	do
	{
		j = gjrand_hyperg(&g, n1, n2, sam);
		if (j<0 || j>sam)
		{
			fprintf(stderr, "hyperg = %d  sam = %d\n", j, sam);
			exit(1);
		}
		histo[j]++;
		count--;
	} while (count>0);
}

int
main(int argc, char **argv)
{
	double e;
	int64_t count;
	unsigned long seed;
	int n1, n2, sam;

	if (argc!=5 && argc!=6)
		crash("usage: hyperg count n1 n2 sam [ seed ]");
	if (sscanf(argv[1], "%lf", &e)!=1) crash("count not a number");
	count = (uint64_t)e;
	if (sscanf(argv[2], "%d", &n1)!=1 || n1<1)
		crash("n1 not a positive number");
	if (sscanf(argv[3], "%d", &n2)!=1 || n2<1)
		crash("n2 not a positive number");
	if (sscanf(argv[4], "%d", &sam)!=1 || sam<1)
		crash("sam not a positive number");
	if (sam>MAX) crash("sam too big (MAX=4096)");
	if (sam>=n1+n2) crash("sam >= n1+n2");
	if (argc==6)
	{
		if (sscanf(argv[5], "%lu", &seed)!=1)
			crash("seed not a number");
		gjrand_init(&g, seed);
	}
	else gjrand_initrand(&g);

	memset(histo, 0, sizeof(histo));
	dostuff(count, n1, n2, sam);
	doan(count, n1, n2, sam);

	return 0;
}
