/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

static double dfm1, offset;

static double
fun(double x)
	{if (x<1e-99) x = 1e-99; return exp(log(x)*dfm1 - x*x*0.5 - offset);}

static void
mkexpect(int f, int64_t n, double base, double inc, double ex[23])
{
	double t, u;
	int j;

	dfm1 = f-1;
	t = sqrt((double)f);
	offset = log(t)*dfm1 - t*t*0.5;

	t = sqrt(base+inc);
	ex[0] = gjrt_integ2(&fun, t, -inc/t, 0.01/n, 8);

	for (j=1; j<22; j++)
	{
		t = sqrt(base+inc*j); u = sqrt(base+inc*j+inc);
		ex[j] = gjrt_integrate(&fun, t, u, 8);
	}

	t = sqrt(base+inc*22);
	ex[22] = gjrt_integ2(&fun, t, inc/t, 0.01/n, 8);

	/* normalise */
	t = 0.0; for (j=0; j<23; j++) t += ex[j];
	t = n/t; for (j=0; j<23; j++) ex[j] *= t;
}

static int64_t hist[23];

static void
anchi(int f, int64_t n, double base, double inc)
{
	double ex[23], t, x, c, p;
	int j;

	mkexpect(f, n, base, inc, ex);
	c = 0;
printf("%16.4f to %16.4f exp %12.0f obs %12.0f\n",
		0.0, base+inc, ex[0], (double)hist[0]);
for (j=1; j<22; j++)
printf("%16.4f to %16.4f exp %12.0f obs %12.0f\n",
		base+inc*j, base+inc*j+inc, ex[j], (double)hist[j]);
printf("%16.4f to %16.4f exp %12.0f obs %12.0f\n\n",
		base+22*inc, 1e10, ex[22], (double)hist[22]);

	for (j=0; j<23; j++) {x = ex[j]; t = hist[j]-x; c += t*t/x;}

	p = chi2p2(c, 22);

	printf("chis = %.3f ; df = 22 ; p = %.3g\n\n", c, p);
}

static void
mean(int f, double m, int64_t size)
{
	double msd=sqrt(2.0*f), sig, p;

	sig = (m-f)*sqrt((double)size)/msd;
	p = erfc(fabs(M_SQRT1_2*sig));
	printf("%6s %14.6f %14.6f %14.6f %.3g\n", "mean", (double)f, m, sig, p);
}

static void
var(int f, double v, int64_t size)
{
	static const float sd[] =
		{0, 7.47, 11.3, 17.9, 30.0, 53.0, 98.5, 189.4, 370, 733, -1};
	double msd, sig, p;
	int i, j;
	msd = sqrt(8)*f;
	for (i=1, j=1; sd[j]>0.0; i++, j += j) if (j>=f)
	{
		int k=j>>1;
		msd = ((sd[i-1]*(j-f)) + (sd[i]*(f-k))) / (j-k);
		break;
	}
	sig = (v-2.0*f)*sqrt((double)size)/msd;
	p = erfc(fabs(M_SQRT1_2*sig));
	printf("%6s %14.6f %14.6f %14.6f %.3g\n", "var", 2.0*f, v, sig, p);
}

static void
skew(int f, double s, int64_t size)
{
	static const short di[]=
		{0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 16, 32, 64, 128, -1};
	static const float ds[]=
		{0, 27.2, 16.1, 12.3, 10.3, 9.26, 8.38, 7.78, 7.37, 6.72,
		 5.70, 4.83, 4.37, 4.12};
	double x=sqrt(8.0/f);
	double msd, sig, p;
	int j;

	s /= sqrt(8.0*f*f*f);
	msd = 4.0;
	for (j=1; di[j]>0; j++) if (di[j]>=f)
	{
		int k=di[j], l=di[j-1];
		msd = ((ds[j-1]*(k-f)) + (ds[j]*(f-l))) / (k-l);
		break;
	}
	sig = (s-x)*sqrt((double)size)/msd;
	p = erfc(fabs(M_SQRT1_2*sig));
	printf("%6s %14.6f %14.6f %14.6f %.3g\n", "skew", x, s, sig, p);
}

static void
testchi(int f, int64_t n)
{
	struct gjrand g;
	int64_t i;
	double t, s1=0, s2=0, s3=0, inc=sqrt(f/32.0), ii=1/inc, base=f-inc*6;
	int j;

	memset(hist, 0, sizeof(hist));

	gjrand_initrand(&g);

	for (i=0; i<n; i++)
	{
		t = gjrand_chisquared(&g, f);
		j = (t-base)*ii;
		if (j<0) j = 0; else if (j>22) j = 22;
		hist[j]++;
		s1 += t; t -= f; s2 += t*t; s3 += t*t*t;
	}

	anchi(f, n, base, inc);

	printf("%6s %14s %14s %14s %s\n",
		"stat", "expect", "seen", "sigma", "pval");
	mean(f, s1/n, n); var(f, s2/n, n); skew(f, s3/n, n);
}

int
main(int argc, char **argv)
{
	double dc;
	int f;

	if (argc!=3 || sscanf(argv[1], "%d", &f)!=1
		|| sscanf(argv[2], "%lf", &dc)!=1)
	{
		fprintf(stderr, "usage: testchi degrees-of-freedom count\n");
		exit(1);
	}
	testchi(f, (int64_t)dc);
	return 0;
}
