/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"
#include "../../testcommon/lgamma.h"

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

int64_t histo[8];
double mean, sd, octile[7];

void
doan(double shape, double scale, double count)
{
	double x=count/8, t, c=0, p, sig;
	double xmean = exp(lngamma(1+1/shape))*scale;
	double xsd = exp(lngamma(1+2/shape))*scale*scale - xmean*xmean;
	int j;
	xsd = sqrt(xsd);

	mean /= count;
	sd = sqrt(sd/count);
	for (j=0; j<8; j++) {t = histo[j]-x; c += t*t;}
	c /= x;
	p = chi2p2(c, 7);
	printf("chis = %.3f ; df = 7 ; p = %.3g\n", c, p);
	sig = sqrt(count)*mean/xsd;
	p = erfc(fabs(M_SQRT1_2*sig));
	printf("mean = %.6f ; expect = %.6f ; %.3f sigma ; p = %.3g\n",
		mean+xmean, xmean, sig, p);
	printf("sdev = %.6f ; expect = %.6f\n", sd, xsd);
}

void
dowb(struct gjrand *g, double shape, double scale, int64_t count)
{
	double xmean = exp(lngamma(1+1/shape))*scale;
	double s=0, ss=0, x;
	int j;

	memset(histo, 0, sizeof(histo));
	while (count>0)
	{
		x = gjrand_weibull(g, shape, scale);
		j = (x>octile[3])*4;
		j += (x>octile[j+1])*2;
		j += x>octile[j];
		histo[j]++;
		x -= xmean;
		s += x; ss += x*x;
		count--;
	}
	mean = s; sd = ss;
}

int
main(int argc, char **argv)
{
	struct gjrand s;
	double count, shape, scale;
	long seed;
	int j;

	if (argc<4) crash("3 or 4 args: shape scale count [ seed ]");
	if (sscanf(argv[1], "%lf", &shape)!=1 || shape<=0)
		crash("shape must be a number > 0");
	if (sscanf(argv[2], "%lf", &scale)!=1 || scale<=0)
		crash("scale must be a number > 0");
	if (sscanf(argv[3], "%lf", &count)!=1 || count<=15)
		crash("count must be a number > 15");
	if (argc>4)
	{
		if (sscanf(argv[4], "%ld", &seed)!=1)
			crash("seed not a number");
		gjrand_init64(&s, seed);
	}
	else gjrand_initrand(&s);

	for (j=0; j<7; j++) octile[j] = scale * pow(log(8.0/(7-j)), 1/shape);
	dowb(&s, shape, scale, (int64_t)count);
	doan(shape, scale, count);

	return 0;
}
