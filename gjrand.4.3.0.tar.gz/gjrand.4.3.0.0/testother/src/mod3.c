/* Test software for gjrand random numbers version 3.2.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

/* Chi-squared test for gjrand_rand32mod, using triples of values. */

#define MAX 32

static long histo[MAX][MAX][MAX];

static void
dochisquare(int mod, long count)
{
	int df=mod*mod*mod;
	double e=((double)count)/df, cs=0.0;
	int i, j, k;

	for (i=0; i<mod; i++) for (j=0; j<mod; j++) for (k=0; k<mod; k++)
		{double d=histo[i][j][k]-e; cs+=d*d;}
	cs /= e;
	df--;
	e = chi2p2(cs, df);
	printf("chis = %f     df = %d     P = %.3g\n", cs, df, e);
}

static void
domod(int mod, long count, int how, struct gjrand *s)
{
	uint32_t buf[1024];
	long i;
	int j, k;
	int old=gjrand_rand32mod(s, mod);
	int old2=gjrand_rand32mod(s, mod);

	for (i=0; i<mod; i++) for (j=0; j<mod; j++)
		for (k=0; k<mod; k++) histo[i][j][k]=0;

	if (how==32) for (i=0; i<count; i++)
	{
		j=gjrand_rand32mod(s, mod);
		histo[old][old2][j]++;
		old=old2; old2=j;
	}
	else if (how==64) for (i=0; i<count; i++)
	{
		j=gjrand_rand64mod(s, mod);
		histo[old][old2][j]++;
		old=old2; old2=j;
	}
	else
	{
		i = count;
		while (i>0)
		{
			k = 1024; if (k>i) k = i;
			gjrand_rand32modv(s, mod, k, buf);
			while (k>0)
			{
				j = buf[--k];
				histo[old][old2][j]++;
				old=old2; old2=j;
			}
			i -= 1024;
		}
	}

	dochisquare(mod, count);
}

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

int
main(int argc, char **argv)
{
	long count;
	int mod, seed, how=0;
	struct gjrand s;

	if (argc<3) crash("3 or 4 args: how mod count [ seed ]"
			"  how is one of 32 64 v");
	if (strcmp(argv[1], "32")==0) how = 32;
	else if (strcmp(argv[1], "64")==0) how = 64;
	else if (strcmp(argv[1], "v")==0) how = 0;
	else crash("invalid how : should be 32 64 or v");
	if (sscanf(argv[2], "%d", &mod)!=1) crash("mod not a number");
	if (sscanf(argv[3], "%ld", &count)!=1) crash("count not a number");
	if (argc>4)
	{
		if (sscanf(argv[4], "%d", &seed)!=1) crash("seed not a number");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	if (mod<2 || mod >MAX) crash("must have 2 <= mod <= 32");

	domod(mod, count, how, &s);

	return 0;
}
