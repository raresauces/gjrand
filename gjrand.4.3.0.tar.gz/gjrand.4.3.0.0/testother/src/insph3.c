/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static uint64_t histo[8][16][32];

static void
doan(double count)
{
	double x=count/(8*16*32), t, c=0, p;
	int i, j, k;

	for (i=0; i<8; i++) for (j=0; j<16; j++) for (k=0; k<32; k++)
		{t = histo[i][j][k]-x; c += t*t;}
	c /= x;
	p = chi2p1(c, 8*16*32-1);
	printf("chis = %.2f ; df = %d ; p = %.3g\n", c, 8*16*32-1, p);
}

static void
dostuff(struct gjrand *s, int64_t count)
{
	double v[3], rs, r;
	int j, k, l;

	do
	{
		gjrand_insphere(s, 3, v);
		rs = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
		r = sqrt(rs);
		j = rs*r*8.0;
		k = v[0]*(8.0/r)+8.0;
		l = atan2(v[1], v[2]) * (16.0/M_PI) + 16.0;
		histo[j&7][k&15][l&31]++;
		count--;
	} while (count>0);
}

int
main(int argc, char **argv)
{
	double count;
	unsigned long seed;
	struct gjrand s;

	if (argc<2) crash("1 or 2 args: count [ seed ]");
	if (sscanf(argv[1], "%lf", &count)!=1) crash("count not a number");
	if (argc>2)
	{
		if (sscanf(argv[2], "%lu", &seed)!=1)
			crash("seed not a number");
		gjrand_init(&s, (uint32_t)seed);
	}
	else gjrand_initrand(&s);

	memset(histo, 0, sizeof(histo));
	dostuff(&s, (int64_t)count);
	doan(count);

	return 0;
}
