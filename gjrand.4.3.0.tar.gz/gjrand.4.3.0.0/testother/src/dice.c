/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"
#include "../../testcommon/chi2p.h"

/* Chi-squared test for gjrand_dice. */
/* First arg is number of dice. */
/* Second arg is number of sides per die. */
/* Third arg is number of trials. */
/* Fourth optional arg is random seed. */

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

#define MAX 1000000
static uint64_t histo[MAX];
static double ex1[MAX], ex2[MAX];

static void
dodice(int n, int sides, int64_t count, struct gjrand *s)
{
	int i;
	for (i=0; i<n*sides; i++) histo[i]=0;
	do {histo[gjrand_dice(s, sides, n)]++; count--;} while (count>0);
}

static double *
mkexpect(int n, int sides, double count)
{
	double x, p = 1.0/sides, *exa=ex1, *exb=ex2, *t;
	int j, k, m;

	exa[0] = count;
	for (j=1; j<n*sides; j++) exa[j] = 0.0;
	for (k=0; k<n; k++)
	{
		t = exa; exa = exb; exb = t;
		for (j=0; j<n*sides; j++) exa[j] = 0.0;
		for (j=0; j<n*sides; j++)
			{x = exb[j]*p; for (m=0; m<sides; m++) exa[j+m] += x;}
	}

	return exa;
}

static void
doan(int n, int sides, double count)
{
	double r, p, *ex, x;
	int64_t a;
	int j, max=n*(sides-1), df, c, l, h;

	ex = mkexpect(n, sides, count);

	c = max/2;
	if (ex[c]<10.0)
	{
		printf("not enough data for a chisquared.\n");
		return;
	}
	l = c;
	while (l>0 && ex[l]>9.0) l--;
	x = 0.0;
	for (j=0; j<=l; j++) x += ex[j];
	ex[l] = x;
	a = 0;
	for (j=0; j<=l; j++) a += histo[j];
	histo[l] = a;
	h = c;
	while (h<max && ex[h]>9.0) h++;
	x = 0.0;
	for (j=h; j<=max; j++) x += ex[j];
	ex[h] = x;
	a = 0;
	for (j=h; j<=max; j++) a += histo[j];
	histo[h] = a;

	r = 0.0;
	for (j=l; j<=h; j++) r += (ex[j]-histo[j])*(ex[j]-histo[j])/ex[j];

	df = h-l;
	p = chi2p2(r, df);

	printf("chis = %f     df = %d     P = %.3g\n", r, df, p);
}

int
main(int argc, char **argv)
{
	struct gjrand s;
	double count;
	long seed;
	int n, sides;

	if (argc<4) crash("3 or 4 args: dice sides count [ seed ]");
	if (sscanf(argv[1], "%d", &n)!=1) crash("number of dice not a number");
	if (sscanf(argv[2], "%d", &sides)!=1) crash("sides not a number");
	if (sscanf(argv[3], "%lf", &count)!=1) crash("count not a number");
	if (argc>4)
	{
		if (sscanf(argv[4], "%ld", &seed)!=1)
			crash("seed not a number");
		gjrand_init64(&s, seed);
	}
	else gjrand_initrand(&s);

	if (n<1) crash("number of dice not positive");
	if (sides<2) crash("sides on each dice less than 2");
	if (n*(uint64_t)sides>MAX) crash("too many dice or sides");

	dodice(n, sides, (int64_t)count, &s);
	doan(n, sides, count);

	return 0;
}
