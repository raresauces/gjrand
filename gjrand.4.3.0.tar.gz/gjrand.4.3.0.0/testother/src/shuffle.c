/* Test software for gjrand random numbers version 3.0.0.0 or later. */
/* Copyright (C) 2004-2009 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../../src/gjrand.h"

/* Basic sanity check for gjrand_shuffle. */
/* This just checks that all the right numbers are there once each. */

#define MAX 3000000

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static int shuf1=0;

static void shuffle1(struct gjrand *s, int n, int a[])
{
	struct gjrand_shufstate shuf;
	int j;

	gjrand_shuffleprep(s, (int64_t)n, &shuf);
	for (j=0; j<n; j++) a[j] = gjrand_shuffle1(&shuf);
	if (gjrand_shuffle1(&shuf)>=0)
		crash("gjrand_shuffle1 sequence too long");
}

/* return 1 if basic sanity checks all pass, else return 0 */
static int
chk(int size, int a[])
{
	static int b[MAX+3];
	int i, j;

	for (i=0; i<size; i++) b[i]=0;
	for (i=0; i<size; i++)
		{j=a[i]; if ((unsigned)j >= (unsigned)size) return 0; b[j]++;}
	for (i=0; i<size; i++) if (b[i]!=1) return 0;

	return 1;
}

static void
doshuffle(int size, int count, struct gjrand *s)
{
	static int a[MAX+3];
	int i, ok=0;

	for (i=0; i<count; i++)
	{
		if (shuf1) shuffle1(s, size, a);
		else gjrand_shuffle(s, size, a);
		ok+=chk(size, a);
	}
	printf("%d ok out of %d\n", ok, count);
	if (ok!=count) printf("=== %d BAD !!! ===\n", count-ok);
}

int
main(int argc, char **argv)
{
	int size, count, seed;
	struct gjrand s;

	if (argc<4) crash("3 or 4 args: -[1a] size count [ seed ]");
	if (strcmp(argv[1], "-1")==0) shuf1 = 1;
	else if (strcmp(argv[1], "-a")==0) shuf1 = 0;
	else crash("arg 1 must be -1 or -a");
	if (sscanf(argv[2], "%d", &size)!=1) crash("size not a number");
	if (sscanf(argv[3], "%d", &count)!=1) crash("count not a number");
	if (size<2 || size>MAX) crash("count out of range");
	if (argc>4)
	{
		if (sscanf(argv[4], "%d", &seed)!=1) crash("seed not a number");
		gjrand_init(&s, seed);
	}
	else gjrand_initrand(&s);

	doshuffle(size, count, &s);

	return 0;
}
