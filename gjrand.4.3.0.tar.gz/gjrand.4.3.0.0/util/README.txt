This is little test programs i wrote, sometimes to try out new ideas, or to
help calibrate various tests, or to generate data tables used in generators
or tests. Handle with care.
