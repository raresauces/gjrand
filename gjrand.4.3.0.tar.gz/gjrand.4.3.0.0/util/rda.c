/* Test software for gjrand random numbers version 3.3.4.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "../src/my_int_types.h"
#include "../testcommon/pcombo.h"
#include "../testcommon/binom.h"
#include "../testcommon/chi2p.h"


/* "Kendall and Babington-Smith Gap Test" on double precision values. */

/* For each number read, calculate the distance since the same number */
/* value was last seen and collect a histogram of these distances. */
/* Finally do a chi-square test on the histogram. */

#define REPEAT 2500
#define DATALEN 1000000

static int errorlevel=0;
static void seterr(int e) {if (errorlevel<e) errorlevel=e;}

#define MULT 6827
#define MAXLAG 20000
#define DF 13535

static int64_t dc[3][MAXLAG];
static int64_t pos64[MULT];

static void
mkexpect(double expect[MAXLAG], int64_t pos)
{
	double c=(double)pos, e=c/MULT;
	int i;

	for (i=1; i<MAXLAG; i++) {expect[i]=e; c-=e; e *= (MULT-1.0)/MULT;}
	expect[0]=c;
}


static double
doan1(const char *note, int64_t pos, int j, int df, double pvs[2])
{
	double expect[MAXLAG];
	double e, t=0.0, x, extreme;
	int64_t tot;
	int i, exi, exd;

	mkexpect(expect, pos);

	for (i=0; i<MAXLAG; i++)
	{
		e=expect[i];
		x=(double)dc[j][i]-e;
		t+=x*x/e;
	}
	return t;

	pvs[0] = chi2p1(t, df);

	extreme=999.0; exi= -1; exd='?';
	tot=pos;
	for (i=1; i<MAXLAG; i++)
	{
		int64_t k=dc[j][i];
		x=sumbino(tot, k, 1.0/MULT);
		if (x<extreme)
		{
			extreme=x; exi=i;
			if (k*MULT>tot) exd='+'; else exd='-';
		}
		tot-=k;
	}
	pvs[1]=pco_scale(extreme, df+1);
	printf("extreme = %.3g (%d %c) (p = %.3g)\n\n", extreme, exi, exd, pvs[1]);
}

static double
doan(int64_t pos)
{
	double pvs[6];
	int64_t p;
	int j;

	p = 0;
	for (j=0; j<MAXLAG; j++) p += dc[2][j];
	return doan1("fromzero", p, 2, DF, pvs+4);
}

static void
dobuf(const double *buf, int64_t p, int n)
{
	int64_t j;
	const double * const bend=buf+n;
	int i, ch, k;

	i = -n;
	do
	{
		ch = bend[i]*MULT;

		j = p-pos64[ch];
		if (j>=MAXLAG) j = 0;
		dc[0][j]++;

		j = p-pos64[ch>>1];
		if (j>=MAXLAG) j = 0;
		dc[1][j]++;

		if (ch==0)
		{
			for (k=MULT-1; k>=0; k--)
			{
				j = p-pos64[k];
				if (j>=MAXLAG) j = 0;
				dc[2][j]++;
			}
		}

		pos64[ch] = p; p++; i++;
	}
	while (i<0);
}

static double
readstuff(int64_t max)
{
#define MYBUFSIZ 1024
	double buf[MYBUFSIZ];
	int64_t p=0;
	int j;

	for (j=0; j<MULT; j++) pos64[j]= -1-j;
	memset(dc, 0, sizeof(dc));

	while (max<=0 || p<max)
	{
		j=fread(buf, sizeof(double), MYBUFSIZ, stdin);
		if (j<=0) break;
		if (max>0 && j>max-p) j=max-p;
		dobuf(buf, p, j);
		p+=j;
	}

	if (max>0 && p<max)
	{
		fprintf(stderr, "Warning, expected %.0f, saw only %.0f\n",
			(double)max, (double)p);
		seterr(1);
	}

	return doan(p);
}

static double score[REPEAT];

void
ntile(double n, double r[REPEAT])
{
	double f, p;
	int i=n*REPEAT+0.5;

	if (i<0) i=0; else if (i>=REPEAT) i=REPEAT-1;
	f = r[i];
	p = 1.0 - chi2p1(f, DF);

	printf("%10.5f %10.5f %10.5f\n", n, f, p);
}

static double
mean(double r[REPEAT])
{
	double m=0.0;
	int i;
	for (i=0; i<REPEAT; i++) m+=r[i];
	m/=REPEAT;
	printf("%10s %10.5f\n", "mean", m);
	return m;
}

static double
sdev(double mean, double r[REPEAT])
{
	double s=0.0, d;
	int i;
	for (i=0; i<REPEAT; i++) {double t=r[i]-mean; s+=t*t;}
	d = sqrt(s/REPEAT);
	printf("%10s %10.5f\n", "sdev", d);
	return d;
}

static void
skew(double mean, double sd, double r[REPEAT])
{
	double s;
	int j;

	s = 0;
	for (j=0; j<REPEAT; j++) {double t = (r[j]-mean)/sd; s += t*t*t;}
	s /= REPEAT;
	printf("%10s %10.5f\n", "skew", s);
}

static int
dcmp(const void *a, const void *b)
{
	double da= * (const double *) a;
	double db= * (const double *) b;

	if (da<db) return -1; if (da==db) return 0; return 1;
}

static void
dostats(double sc[REPEAT])
{
	double m, sd;

	qsort(sc, REPEAT, sizeof(double), dcmp);

	ntile(0.001, sc);
	ntile(0.01, sc);
	ntile(0.1, sc);
	ntile(0.2, sc);
	ntile(0.3, sc);
	ntile(0.5, sc);
	ntile(0.7, sc);
	ntile(0.8, sc);
	ntile(0.9, sc);
	ntile(0.99, sc);
	ntile(0.999, sc);

	m=mean(sc);
	sd=sdev(m, sc);
	skew(m, sd, sc);
}

int
main(int argc, char **argv)
{
	int j;
	for (j=0; j<REPEAT; j++) score[j] = readstuff(DATALEN);
	dostats(score);
	return errorlevel;
}
