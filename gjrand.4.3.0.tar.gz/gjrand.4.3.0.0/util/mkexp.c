#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int
main()
{
	long double x, t;
	int j;

	x = 0; t = 1;
	for (j=0; j<8; j++) {x += t*t; t *= (1017.0/1024.0);}
	printf("%.22Lf\n", 0.5/x);

	return 0;
}
