/* Test software for gjrand random numbers version 3.3.0.0 or later. */
/* Copyright (C) 2004-2010 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* A test for gjrand_shuffle(). This simulates a very simplified version */
/* of the game of poker. */

/* In this simplified version, there are 10 players and a deck of 52 cards. */
/* The cards consist of 4 suits each with 13 different numbers 1 to 13. */
/* A game consists of a number of hands (specified on command line). */
/* For each hand, each player is dealt 5 cards (and 2 cards remain unused). */
/* The player with the best hand wins. There are various tie-breaks so */
/* ties never happen. I just made these up, so if you play poker, you may be */
/* used to slightly different tie-breaks. */
/* There is no betting. We just count how often each player wins. */

/* Hands that are worth something (in decreasing order): */
/* 8. Straight flush (any hand that qualifies as both straight, and flush). */
/* 7. Four of a kind (4 cards have the same number). */
/* 6. Full house (3 cards have the same number, and 2 another same number.) */
/* 5. Flush (all 5 cards are from the same suit). */
/* 4. Straight (All 5 cards have consecutive numbers. 1 counts as 14 */
/*	if it helps.) */
/* 3. Three of a kind (3 cards have the same number). */
/* 2. Two pairs (2 cards have the same number, and 2 another same number). */
/* 1. One pair (2 cards have the same number). */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

static void
crash(const char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

static int
isflush(int hand[5])
{
	int s=hand[0] & 0x3;
	return (s==(hand[1]&0x3) && s==(hand[2]&0x3)
		&& s==(hand[3]&0x3) && s==(hand[4]&0x3));
}

static void
dosort(int hand[5])
{
	int i, j, k;

	for (i=1; i<5; i++)
	{
		k=hand[i];
		for (j=i-1; j>=0 && hand[j]>k; j--) hand[j+1]=hand[j];
		hand[j+1]=k;
	}
}

/* Has the side effect of sorting the hand. This is relied on */
/* by some functions called afterwards. */
static int
isstraight(int hand[5])
{
	int i, k;

	/* Aces usually high */
	for (i=0; i<5; i++) if (hand[i]<4) hand[i]+=52;

	dosort(hand);

	/* Ace low if it helps make a straight */
	if ((hand[0]>>2)==1 && (hand[1]>>2)==2 && (hand[2]>>2)==3
		&& (hand[3]>>2)==4 && (hand[4]>>2)==13)
	{
		k=hand[4]-52;
		for (i=4; i>0; i--) hand[i]=hand[i-1];
		hand[0]=k;
	}

	for (i=1; i<5; i++) if ((hand[i]>>2)!=(hand[i-1]>>2)+1) return 0;

	return 1;
}

/* assumes sorted already by isstraight. */
/* looks for 2, 3, 4 of a kind, 2 pair, full house. */
/* re-sorts if necessary for correct tiebreak. */
static void
numbers(int hand[5], char eval[11])
{
	int st=5, le=1, i, r=0;

	/* mark each card if it is part of a pair, triple or quad */
	for (i=1; i<5; i++)
	{
		if ((hand[i]>>2)==(hand[i-1]>>2))
			{if (le==1) st=i-1; le++;}
		else if (le>1)
			{while (st<i) {hand[st]|=le<<8; st++;} st=5; le=1;}
	}
	if (le>1) {while (st<5) {hand[st]|=le<<8; st++;} st=5; le=1;}

	/* re-sort putting number duplicates at high positions. */
	/* this is what we want for tiebreak. */
	dosort(hand);

	/* nothing hand */
	le=hand[4]>>8;
	if (le == 0) goto ret;

	/* if here, there is at least a pair */
	/* check if it is not better than that */
	if (le == 2)
	{
		r=1;
		if (hand[2]>>8 == 0) goto ret; /* 1 pair */
		r=2; /* 2 pair */
		goto ret;
	}

	/* at least a triple */
	if (le == 3)
	{
		r=3;
		if (hand[1]>>8 == 0) goto ret; /* 3 of a kind */
		r=6; /* full house. */
		goto ret;
	}

	if (le == 4) r=7; /* 4 of a kind */
	else crash("numbers ?");

	ret:
	/* remove marks from cards */
	for (i=0; i<5; i++) hand[i]&=255;

	eval[0]=r;

	return;
}

static void
tiebreak(int hand[5], char eval[11])
{
	eval[1]=hand[4]>>2; eval[2]=hand[3]>>2;
	eval[3]=hand[2]>>2; eval[4]=hand[1]>>2;
	eval[5]=hand[0]>>2; eval[6]=hand[4]&0x3;
	eval[7]=hand[3]&0x3; eval[8]=hand[2]&0x3;
	eval[9]=hand[1]&0x3; eval[10]=hand[0]&0x3;
}

static void
classify(int hand[5], char eval[11])
{
	int f=isflush(hand), s=isstraight(hand);

	if (s) {eval[0]=4; if (f) eval[0]=8;}
	else if (f) eval[0]=5;
	else numbers(hand, eval);
	tiebreak(hand, eval);
}

static int64_t hands[10];

int
main(int argc, char **argv)
{
	int i, cards[5], a, b, c, d, e;
	long count=0;
	char eval[11];

	for (a=0; a<48; a++)
	for (b=a+1; b<49; b++)
	for (c=b+1; c<50; c++)
	for (d=c+1; d<51; d++)
	for (e=d+1; e<52; e++)
	{
		cards[0]=a; cards[1]=b; cards[2]=c; cards[3]=d; cards[4]=e;
		classify(cards, eval);
		hands[(int)(eval[0])]++;
		count++;
	}

	printf("static const long count=%ld;\n", count);
	printf("static const long xi[9]={\n");
	for (i=0; i<8; i++) printf("%ld,\n", hands[i]);
	printf("%ld };\n", hands[8]);

	return 0;
}
