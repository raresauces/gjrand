/* Various stuff included with gjrand random numbers version 3.3.0.0 . */
/* Copyright (C) 2004-2009 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "../src/gjrand.h"

#include "aanormaltab.c"

#define MULT (1017.0/1024.0)

static void
adj(void)
{
	int j;
	long double t, m, s;

	s = 0;
	for (j=0; j<256; j++) {t = gjrand_inte_normal_app[j]; s += t*t;}
	s *= (1.0/256.0);
	t = 0; m = 1;
	for (j=0; j<16; j++) {t += m*m; m *= MULT;}
	t *= s;

	t = sqrtl(1/t);
printf("#define GJRAND_INTE_NORM_ADJ (%.18Lf)\n\n", t);
}

int
main(int argc, char **argv)
{
	adj();
	return 0;
}
