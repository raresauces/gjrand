#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static long double
simple(int n)
{
	long double r=1.0;
	int j;
	for (j=2; j<=n; j++) r *= j;
	return logl(r);
}

int
main(int argc, char **argv)
{
	int j;
	printf("static const double simple[32]={\n");
	for (j=0; j<=30; j++) printf("%.20Lf,\n", simple(j));
	printf("%.20Lf\n};\n", simple(31));
	return 0;
}
