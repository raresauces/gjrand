/* Misc stuff included with gjrand random numbers version 4.3.0.0 or later. */
/* Copyright (C) 2004-2018 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* This was done on a machine where long double is 80 bit IEEE extended. */
/* Just to be on the safe side, i suggest using some type which is */
/* more accurate than double, so you don't have to worry about roundoff. */
/* Though i doubt it really matters. Spotting inaccuracies of the order */
/* 1e-15 needs a bigger sample size than most end-users will want :-) */
typedef long double bigfloat;
#define bigsqrt(x) sqrtl(x)
#define bigerfc(x) erfcl(x)

/* number of moments you want to optimise. */
/* they will be 2, 4, 6, etc (the odd ones are always perfect). */
#define NMOMENTS 3

/* In the least squares thing below, there are effectively NMOMENTS */
/* equations. Therefore i want NMOMENTS unknowns so i can just do */
/* Gaussian elimination instead of actually thinking. */
/* So the elements of the table (64 of them) get partitioned */
/* into NMOMENTS subsets that each get tuned as a unit. */
/* Subset j goes from segments[j] to segments[j+1]-1 . */
static const int subsets[NMOMENTS+1]={0, 53, 63, 64};

#if 0
static const int subsets[NMOMENTS+1]={0, 56, 61, 62, 63, 64};
#endif

static double tab[64];

static void
crash(const char *s)
{
	fprintf(stderr, "crash [%s]\n", s?s:"?");
	exit(1);
}

static bigfloat xmoments[18], cmoments[18];

static bigfloat
powi(bigfloat x, int p)
{
	bigfloat r=1.0;

	if (!p) return r;
	if (p&1) return powi(x, p-1) * x;
	r = powi(x, p>>1);
	return r*r;
}

static void
mkcmoments(void)
{
	bigfloat x, y, t;
	int j, k;

	for (j=0; j<18; j++) cmoments[j] = 0.0;

	for (j=2; j<=16; j++)
	{
		t = 0.0;
		for (k=0; k<64; k++)
		{
			x = tab[k];
			y = powi(x, j);
			t += y;
			cmoments[j] = t * (1.0/64.0);
		}
	}
}

/* The section in which we do non-linear least squares optimisation. */

/* [subset][moment] */
static bigfloat deriv[NMOMENTS][NMOMENTS], momerr[NMOMENTS], adj[NMOMENTS];

static void
mkderiv(void)
{
	bigfloat t;
	int j, k, first, end, p, n;

	for (j=0; j<NMOMENTS; j++)
	{
		first = subsets[j]; end = subsets[j+1];
		for (k=0; k<NMOMENTS; k++)
		{
			p = 2*k+2;
			t = 0.0;
			for (n=first; n<end; n++) t += powi(tab[n], p);
			deriv[j][k] = t*p;
		}
	}
}

static void
mkerror(void)
{
	int j, p;
	mkcmoments();
	for (j=0; j<NMOMENTS; j++)
	{
		p = 2*j+2;
		momerr[j] = xmoments[p]-cmoments[p];
	}
}

#ifdef DBG
static void
showeqn(void)
{
	int j, k;
	for (j=0; j<NMOMENTS; j++)
	{
		for (k=0; k<NMOMENTS; k++)
			fprintf(stderr, "%12.5g", (double)(deriv[j][k]));
		fprintf(stderr, " ;%12.5g\n", (double)(adj[j]));
	}
}
#endif

static void
solveadj(void)
{
	bigfloat x, y, t, p;
	int j, k, n, bestp;

	for (j=0; j<NMOMENTS; j++) adj[j] = momerr[j];
#ifdef DBGEQN
showeqn();
fprintf(stderr, "eqns init\n");
#endif

	for (j=0; j<NMOMENTS-1; j++)
	{
		/* find best pivot */
		bestp = -1; p = -1.0;
		for (k=j; k<NMOMENTS; k++)
		{
			t = deriv[k][j]; t *= t; y = t;
			for (n=k+1; n<NMOMENTS; n++)
				{x = deriv[k][n]; y += x*x;}
			x = adj[k]; y += x*x;
			t /= y;
			if (t>p) {p = t; bestp = k;}
		}
		if (p<=0.0)
		{
#ifdef DBG
showeqn();
fprintf(stderr, "pivot %d\n", j);
#endif
			crash("pivot not found");
		}

		if (bestp!=j)
		{
			t = adj[bestp]; adj[bestp] = adj[j]; adj[j] = t;
			for (k=j; k<NMOMENTS; k++)
			{
				t = deriv[bestp][k];
				deriv[bestp][k] = deriv[j][k];
				deriv[j][k] = t;
			}
		}

		/* eliminate the column */
		for (k=j+1; k<NMOMENTS; k++)
		{
			p = deriv[k][j]/deriv[j][j];
			deriv[k][j] = 0.0;
			for (n=j+1; n<NMOMENTS; n++)
				deriv[k][n] -= deriv[j][n] * p;
			adj[k] -= adj[j] * p;
		}
#ifdef DBGEQN
showeqn();
fprintf(stderr, "eqns after %d\n", j);
#endif
	}

	/* back substitution */
	for (j=NMOMENTS-1; j>=0; j--)
	{
		if (deriv[j][j]==0.0) crash("zero on diagonal");
		adj[j] /= deriv[j][j];
		deriv[j][j] = 1.0;
		for (k=j-1; k>=0; k--)
		{
			adj[k] -= adj[j] * deriv[k][j];
			deriv[k][j] = 0.0;
		}
	}
#ifdef DBGEQN
showeqn();
fprintf(stderr, "eqns after backsub\n");
#endif
}

static void
mkadj(void)
{
	/* The adjustments within each subset are proportional to the */
	/* current value of each element. */
	bigfloat mul;
	int j, k, first, end;

	for (j=0; j<NMOMENTS; j++)
	{
		first = subsets[j]; end = subsets[j+1];
		mul = adj[j]* -1.0 + 1.0;
		for (k=first; k<end; k++) tab[k] *= mul;
	}
}

static void
improve(void)
{
	mkderiv();
	mkerror();
	solveadj();
	mkadj();
}

/* End of least squares thing. */

static void
mkxmoments(void)
{
	bigfloat r=1.0;
	int j;

	xmoments[0] = 0.0;
	for (j=1; j<=16; j+=2) {r *= j; xmoments[j] = 0.0; xmoments[j+1] = r;}
}

static bigfloat
inverfc(bigfloat x, bigfloat lo, bigfloat hi)
{
	bigfloat mid=(lo+hi)*0.5, y;

	y = bigerfc(mid);
	if (y==x) return mid;
	if (y<x)
	{
		if (mid<=lo) return lo;
		if (mid>=hi) return lo;
		return inverfc(x, lo, mid);
	}
	/* else y>x */
	if (mid>=hi) return hi;
	if (mid<=lo) return hi;
	return inverfc(x, mid, hi);
}

static void
inita(void)
{
	bigfloat x;
	int j;

	for (j=63; j>=0; j--)
	{
		x = 63.5 - j;
		x *= (1.0/64);
		tab[j] = inverfc(x, 0.0, 8.0);
	}
}

static void
normalise(void)
{
	int j;
	bigfloat s=0.0, t;

	for (j=0; j<64; j++) {t = tab[j]; s += t*t;}
	s /= 64.0;
	s = bigsqrt(s);
	for (j=0; j<64; j++) tab[j] /= s;
}

static void
moments(void)
{
	int j;
	bigfloat s=0.0, p=1.0, r;

	for (j=2; j<=16; j+=2)
	{
		int k;
		s = 0.0;
		for (k=0; k<64; k++) s += powi(tab[k], j);
		s /= 64.0;
		r = s/p;
		fprintf(stderr, "%16.12f (error %.3g)\n",
			(double)r, (double)((s-xmoments[j])/xmoments[j]));
		p = s;
	}
	fputs("\n", stderr);
}

static void
printtab(void)
{
	int j;

	fputs(
"/* Part of gjrand random number library version 4.3.0.0 or later. */\n"
"/* Copyright (C) 2004-2018 G. Jones. */\n"
"/* Licensed under the GNU General Public License version 2 or 3. */\n\n"
"#include \"gjrand.h\"\n"
"#include \"inte.h\"\n\n"
"const GJRAND_STATIC double gjrand_inte_normal_app[128]={\n" ,
		stdout);

	for (j=0; j<63; j++) printf("%.19f, %.19f,\n", tab[j], -tab[j]);

	printf("%.19f, %.19f}\n", tab[63], -tab[63]);
}

int
main()
{
	int j, k;

	mkxmoments();

	inita();

	normalise();

	moments();

	k = 0;
	for (j=1; j<=128; j++)
	{
		improve();
//		normalise();
		if (j>=2*k)
		{
			fprintf(stderr, "\n=======\niteration %d\n", j);
			moments();
			k = j;
		}
	}

	printtab();

	return 0;
}
