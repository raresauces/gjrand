/* Misc software for gjrand random numbers version 3.0.1.0 or later. */
/* Copyright (C) 2004-2009 G. Jones. */
/* Licensed under the GNU General Public License version 2 or 3. */

/* This one looks for trouble in 155 dimensions. It is only likely to catch */
/* the grossest ugliness, but should be good enough for a lagged */
/* Fibonacci with both lags less than about 155. */

/* This one is to correctly calibrate the "counts". */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "../src/my_int_types.h"
#include "../testcommon/pcombo.h"

#define SIZ (15<<20)
#define REPS 100

double results[REPS];

static int errorlevel=0;
static void seterr(int e) {if (errorlevel<e) errorlevel=e;}

static void crash(char *s) {fprintf(stderr, "crash [%s]\n", s); exit(1);}

#define DIM 22
#define DIM7 (7*DIM)
#define DIMSIZE (1<<DIM)
#define DIMMASK (DIMSIZE-1)

/* [0]=count [1]=tot [2]=totsq */
static double stats[DIMSIZE][1];

void
init(void) {int i; for (i=0; i<DIMSIZE; i++) stats[i][0]=0.0;}

static unsigned
cmp7(const double b[7])
	{return 0.75*((b[0]+b[2])+(b[4]+b[5])) > (b[1]+b[3]+b[6]);}

static void
dobuf(double b[], int s)
{
	unsigned in0=0, in1=0, in2=0, in3=0, in4=0, in5=0, in6=0;
	int i;

	for (i= -DIM7; i<-7; i+=7) in0 = cmp7(b+i) + 2*in0;
	for (i= 1-DIM7; i<-6; i+=7) in1 = cmp7(b+i) + 2*in1;
	for (i= 2-DIM7; i<-5; i+=7) in2 = cmp7(b+i) + 2*in2;
	for (i= 3-DIM7; i<-4; i+=7) in3 = cmp7(b+i) + 2*in3;
	for (i= 4-DIM7; i<-3; i+=7) in4 = cmp7(b+i) + 2*in4;
	for (i= 5-DIM7; i<-2; i+=7) in5 = cmp7(b+i) + 2*in5;
	for (i= 6-DIM7; i<-1; i+=7) in6 = cmp7(b+i) + 2*in6;

	for (i=0; i<s; i++)
	{
		in0 = (cmp7(b+i-7) + 2*in0) & DIMMASK;
		stats[in0][0]++;
		i++; if (i>=s) break;

		in1 = (cmp7(b+i-7) + 2*in1) & DIMMASK;
		stats[in1][0]++;
		i++; if (i>=s) break;

		in2 = (cmp7(b+i-7) + 2*in2) & DIMMASK;
		stats[in2][0]++;
		i++; if (i>=s) break;

		in3 = (cmp7(b+i-7) + 2*in3) & DIMMASK;
		stats[in3][0]++;
		i++; if (i>=s) break;

		in4 = (cmp7(b+i-7) + 2*in4) & DIMMASK;
		stats[in4][0]++;
		i++; if (i>=s) break;

		in5 = (cmp7(b+i-7) + 2*in5) & DIMMASK;
		stats[in5][0]++;
		i++; if (i>=s) break;

		in6 = (cmp7(b+i-7) + 2*in6) & DIMMASK;
		stats[in6][0]++;
	}
}

int64_t
dostuff(int64_t max)
{
	double buf[DIM7+512];
	int64_t r=0;
	int i, j;

	if (fread(buf, sizeof(double), 512, stdin)!=512)
		crash("fread failed 1");
	dobuf(buf+DIM7, 512-DIM7);
	r = j = 512-DIM7;

	while (max<0 || r<max)
	{
		for (i=0; i<DIM7; i++) buf[i]=buf[j+i];
		j=512;
		if (max>=0 && j>max-r) j=max-r;
		j=fread(buf+DIM7, sizeof(double), j, stdin);
		if (j<=0) break;
		dobuf(buf+DIM7, j);
		r+=j;
	}

	if (max>=0 && r<max)
	{
		fprintf(stderr, "warning expected %.0f samples saw only %.0f\n",
			(double)max, (double)r);
		seterr(1);
	}

	return r;
}

double
doan(int64_t s)
{
	double x, t, e;
	int i;

	e=((double)s)/((double)DIMSIZE);
	t=0.0;
	for (i=0; i<DIMSIZE; i++) {x=stats[i][0]-e; t+=x*x;}
	t/=e;
	t-=DIMMASK;
	t/=sqrt(2.0*DIMMASK);

	return t;
}

void
dometaan(void)
{
	double x, y, z;
	int j;

	x = 0;
	for (j=0; j<REPS; j++) x += results[j];
	x /= REPS;
	printf("mean = %10.5f\n", x);

	y = 0;
	for (j=0; j<REPS; j++) {z = results[j]; y += z*z;}
	y /= REPS; y = sqrt(y);
	printf("sd   = %10.5f\n", y);
}

int
main(int argc, char ** argv)
{
	int64_t r, count;
	double dc;
	int j;

	if (argc>=2)
	{
		if (sscanf(argv[1], "%lf", &dc)!=1 || dc<1.0)
			crash("1 optional arg: point-count");
		count=(int64_t)dc-DIM;
	}
	else count= -1;

	for (j=0; j<REPS; j++) {init(); r=dostuff(SIZ); results[j]=doan(r);}
	dometaan();

	return errorlevel;
}
